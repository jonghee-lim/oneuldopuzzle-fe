import axios, { type AxiosInstance, type AxiosRequestConfig } from "axios";
import { coreT } from "./locale.ts";

/*
 * 웹 로그인 세션 클라이언트(1.23.0, 로그인 공통화 P3). 앱 세션(./native-session)과 짝을 이루는 쿠키 세션이다.
 * 7개 앱이 따로 들고 있던 sessionClient.ts의 같은 부분을 한 곳에 둔다:
 * 세션 잠금(탭 사이 navigator.locks, 설치형 앱은 한 줄 큐), exchange → refresh 검증 → 받아들이기, refresh(SESSION_REFRESH_BUSY 재시도·끝난 세션이면 만료 처리),
 * logout(오프라인이어도 의도를 먼저 저장), restore(시작·복귀, 옛 저장값 이전), activity(사용 기록 연장·탭 사이 공유), policy(짧은 세션으로 바꾸기),
 * 탭 사이 로그인·로그아웃 알림, 세대(epoch) 검사로 늦게 온 응답 버리기.
 * 앱 차이(앱 세션 요청, 캐시·알림 정리, 로그아웃 전 정리, 옛 저장값, 프로필 보강, 서버에 닿지 못할 때 정책, 문구)는 옵션으로 받는다.
 *
 * 규칙(2026-10-24 U1-b, 오늘Do클래스에서 먼저 고침, 여기서 모든 앱의 기본): 로그인된 것이 없을 때는 만료 처리·로그아웃 표시 복원에서 세대를 올리지 않는다.
 * 올리면 진행 중이던 공개 요청(간편 로그인 완료·초대 링크)이 '세션 바뀜'으로 취소된다.
 */
export type SessionPolicy = { sessionId: string; version: number; remember: boolean; idleExpiresAt: string; absoluteExpiresAt: string; serverNow: string };
export type SessionUser = { id: string; serviceCode?: string };
export type SessionLogin<TUser extends SessionUser = SessionUser> = { user: TUser; accessToken: string; session?: SessionPolicy };
export type SessionStatus = "loading" | "ready" | "unavailable";
/** 앱 authStore(zustand)의 상태 모양. login·logout은 상태 안의 동작이다(useAuthStore.getState().login). */
export type SessionStoreState<TUser extends SessionUser> = {
  user: TUser | null; accessToken: string | null; epoch: number; status: SessionStatus; session: SessionPolicy | null;
  /** 로그인 상태 넣기(status ready, 안내 지움). */
  login: (user: TUser, accessToken: string) => void;
  /** 로그인 상태 비우고 세대(epoch)를 올린다. status를 받는 저장소(스파클)는 그 값으로, 아니면 ready. */
  logout: (status?: SessionStatus) => void;
};
/** 앱 useAuthStore를 그대로 넘긴다. */
export type SessionStore<TUser extends SessionUser> = {
  getState: () => SessionStoreState<TUser>;
  setState: (patch: Partial<{ session: SessionPolicy | null; serverOffset: number; status: SessionStatus; sessionNotice: string | null }>) => void;
};
export type NativeSessionBridge<TUser extends SessionUser> = {
  /** 설치형 앱 세션을 쓸지(iOS·Android). */
  enabled: () => boolean;
  /** ./native-session createNativeSession().request를 앱 설정으로 감싼 것. */
  request: (client: AxiosInstance, action: string, body: unknown, config: AxiosRequestConfig | undefined, check: () => void, expectedUser?: string) => Promise<{ data: SessionLogin<TUser> }>;
  clearCredential: () => Promise<void>;
  /** 이 기기에 앱 로그인이 저장되어 있는지. startWithoutSession을 쓰는 앱만 필요하다. */
  hasCredential?: () => Promise<boolean>;
};
export type WebSessionOptions<TUser extends SessionUser> = {
  /** withCredentials·X-Session-Request를 붙인 앱 axios 인스턴스. */
  transport: AxiosInstance;
  /** 쿠키 세션 API 경로. 예: /api/dallhythm/auth/session */
  path: string;
  /** 응답 사용자가 이 서비스가 아니면 거절한다. null이면 사용자 id만 본다(워크스페이스). */
  serviceCode: string | null;
  /** 저장 키: 로그아웃 의도(localStorage), 탭 사이 알림, 사용 기록 공유, 잠금 이름. */
  keys: { logout: string; event: string; activity: string; lock: string };
  store: SessionStore<TUser>;
  /**
   * 로그인 상태·조회 캐시·알림 구독을 모두 비운다(앱 src/auth/authSession.ts). 사용자가 바뀔 때·로그인 완료·로그아웃에 부른다.
   * userId가 있으면 같은 계정 재로그인이라 알림 구독은 유지한다. status는 비운 뒤 상태(로그인 완료 중에는 loading, 비회원 화면을 잠깐 보이지 않게).
   */
  clearAuthSession: (userId?: string, status?: SessionStatus) => void;
  /** 세션 만료(끝난 세션) 때 비울 것: 조회 캐시·앱 선택. 알림 구독은 거두지 않는다(다시 로그인하면 그대로 쓴다). */
  onExpire?: () => void;
  native?: NativeSessionBridge<TUser>;
  /** 서버에 닿지 못했을 때 로그인 없이 열어도 되는지(설치형 앱 '계정 없이 사용'). 기본 false → unavailable(다시 시도). */
  startWithoutSession?: () => boolean;
  /** 쿠키 세션 전 저장값(sessionStorage 등) 이전: SESSION_EXPIRED인데 옛 로그인이 남아 있으면 그것으로 교환한다. read는 복원 시작 때, clear는 로그인·끝난 세션 때 부른다. */
  legacy?: { read: () => SessionLogin<TUser> | null; clear: () => void };
  /** 로그아웃 요청 전에 할 일(알림 구독 해제·오프라인 시작 표시). 실패해도 로그아웃은 계속한다. */
  beforeLogout?: () => Promise<void> | void;
  /** 로그인 완료 뒤(오프라인 시작 표시 지우기 등). */
  afterLogin?: () => void;
  /** 복원이 끝난 세션(쿠키 없음)으로 끝났을 때(설치형 앱 오프라인 시작 표시 등). */
  onSignedOut?: () => void;
  /** 받아들이기 전에 사용자 정보를 보강한다(스파클 프로필 조회). check()는 같은 세대인지 확인한다. */
  enrich?: (result: SessionLogin<TUser>, check: () => void) => Promise<SessionLogin<TUser>>;
  /** 문구(앱 다국어). 없으면 app-core 사전(ko·en·ja). */
  notices?: Partial<{ expired: string; wrongService: string; mismatch: string }>;
};

const TERMINAL = ["SESSION_EXPIRED", "SESSION_REFRESH_REUSED", "SESSION_ACCOUNT_DISABLED", "SESSION_SERVICE_MISMATCH"];

/** 서버 세션 오류 code(응답 본문 code, 또는 앱 세션이 만든 SESSION_* code). */
export function sessionCode(error: unknown): string | undefined {
  if (!axios.isAxiosError(error)) return undefined;
  const code = error.response?.data?.code;
  if (typeof code === "string") return code;
  return error.code?.startsWith("SESSION_") ? error.code : undefined;
}
/** 끝난 세션(다시 로그인해야 함). */
export const isTerminalSessionError = (error: unknown) => TERMINAL.includes(sessionCode(error) ?? "");

type Nav = { locks?: { request: (name: string, action: () => Promise<unknown>) => Promise<unknown> }; clearAppBadge?: () => Promise<void> };

export function createWebSession<TUser extends SessionUser>(options: WebSessionOptions<TUser>) {
  const { transport, path, store, keys } = options;
  const nav = (): Nav => (typeof navigator === "undefined" ? {} : (navigator as unknown as Nav));
  const text = (key: "expired" | "wrongService" | "mismatch") => options.notices?.[key] ?? coreT(`appCore.session.${key}`);
  const isNative = () => options.native?.enabled() === true;
  const matches = (user: SessionUser | undefined) => (options.serviceCode ? user?.serviceCode === options.serviceCode : typeof user?.id === "string" && user.id.length > 0);

  let refreshing: Promise<void> | undefined;
  let booting: Promise<void> | undefined;
  let refreshEpoch = -1;
  let bootEpoch = -1;
  let activityPending: Promise<void> | undefined;
  // 설치형 앱은 보안 저장소 접근을 한 줄로 세운다(navigator.locks 대신).
  let nativeQueue: Promise<unknown> = Promise.resolve();

  function assertEpoch(epoch: number) {
    if (store.getState().epoch !== epoch) throw new axios.CanceledError("Session changed");
  }
  async function locked<T>(action: () => Promise<T>): Promise<T> {
    if (isNative()) {
      const pending = nativeQueue.then(action);
      nativeQueue = pending.catch(() => {});
      return pending;
    }
    const locks = nav().locks;
    if (locks) return locks.request(keys.lock, action) as Promise<T>;
    return action();
  }
  /** 설치형 앱은 앱 전용 세션(보안 저장소), 웹·웹앱은 쿠키 세션으로 보낸다. */
  function sessionRequest(action: string, body: unknown = null, config?: AxiosRequestConfig, epoch = store.getState().epoch, expectedUser?: string) {
    if (isNative() && options.native) return options.native.request(transport, action, body, config, () => assertEpoch(epoch), expectedUser);
    return transport.post<SessionLogin<TUser>>(path + "/" + action, body, config);
  }
  function announce(type: "login" | "logout") {
    localStorage.setItem(keys.event, JSON.stringify({ type, nonce: crypto.randomUUID() }));
  }
  function acceptPolicy(policy?: SessionPolicy) {
    if (!policy) return;
    const current = store.getState().session;
    if (current?.sessionId === policy.sessionId && Date.parse(policy.serverNow) < Date.parse(current.serverNow)) return;
    store.setState({ session: policy, serverOffset: Date.parse(policy.serverNow) - Date.now() });
  }
  /** 서버가 준 로그인 결과를 상태로 받아들인다. 사용자가 바뀌면 옛 계정 자료를 먼저 비운다(cleared=true면 부른 쪽이 이미 비웠다). */
  async function accept(result: SessionLogin<TUser>, epoch: number, cleared = false) {
    assertEpoch(epoch);
    if (!matches(result.user)) throw new Error(text("wrongService"));
    if (options.enrich) { result = await options.enrich(result, () => assertEpoch(epoch)); assertEpoch(epoch); }
    if (!cleared && store.getState().user?.id !== result.user.id) options.clearAuthSession(result.user.id, "loading");
    store.getState().login(result.user, result.accessToken);
    acceptPolicy(result.session);
  }
  /** 끝난 세션: 로그인 상태와 조회 캐시를 비운다. 로그인된 것이 없으면 세대는 올리지 않는다(U1-b). */
  function expireSession() {
    if (isNative()) void locked(() => options.native!.clearCredential()).catch(() => {});
    const state = store.getState();
    const restoring = state.status === "loading";
    const wasAuthenticated = Boolean(state.user);
    if (!wasAuthenticated && !state.accessToken) { store.setState({ status: restoring ? "loading" : "ready" }); return; }
    options.onExpire?.();
    store.getState().logout(restoring ? "loading" : "ready");
    if (wasAuthenticated) store.setState({ sessionNotice: text("expired") });
    if (restoring) store.setState({ status: "loading" });
    const badge = nav().clearAppBadge;
    if (badge) void badge.call(nav()).catch(() => {});
  }
  function refreshSession(): Promise<void> {
    const epoch = store.getState().epoch;
    if (refreshing && refreshEpoch === epoch) return refreshing;
    refreshEpoch = epoch;
    const pending = locked(async () => {
      assertEpoch(epoch);
      if (localStorage.getItem(keys.logout)) throw new axios.CanceledError("Logged out");
      for (let attempt = 0; ; attempt++) {
        try {
          const foreground = typeof document === "undefined" || document.visibilityState === "visible" ? "1" : "0";
          const { data } = await sessionRequest("refresh", null, { headers: { "X-Session-Foreground": foreground } }, epoch);
          await accept(data, epoch);
          return;
        } catch (error) {
          assertEpoch(epoch);
          if (sessionCode(error) === "SESSION_REFRESH_BUSY" && attempt < 3) { await new Promise((r) => setTimeout(r, 350 * (attempt + 1))); continue; }
          if (isTerminalSessionError(error)) expireSession();
          throw error;
        }
      }
    }).finally(() => { if (refreshing === pending) refreshing = undefined; });
    refreshing = pending;
    return pending;
  }
  /**
   * 로그인 응답(짧은 접근 토큰)을 이 기기의 세션으로 바꾼다. 교환 뒤 refresh로 쿠키 왕복을 검증하고 사용자·서비스가 맞을 때만 받아들인다.
   * user가 없는 응답(워크스페이스 공통 로그인)은 교환 응답의 사용자를 기준으로 삼는다. rememberLogin=true면 브라우저를 닫아도 유지한다.
   */
  async function completeLogin(result: { accessToken: string; user?: TUser }, expectedEpoch = store.getState().epoch, rememberLogin = false) {
    await locked(async () => {
      assertEpoch(expectedEpoch);
      // 오프라인 로그아웃이 남아 있으면 새 로그인 전에 먼저 보낸다.
      if (localStorage.getItem(keys.logout)) await sessionRequest("logout", null, undefined, expectedEpoch);
      assertEpoch(expectedEpoch);
      const expectedUser = result.user?.id;
      const { data } = await sessionRequest("exchange", { rememberLogin }, { headers: { Authorization: "Bearer " + result.accessToken } }, expectedEpoch, expectedUser);
      assertEpoch(expectedEpoch);
      const verified = await sessionRequest("refresh", null, { headers: { "X-Session-Foreground": "1" } }, expectedEpoch, expectedUser);
      assertEpoch(expectedEpoch);
      const id = expectedUser ?? data.user?.id;
      if (typeof id !== "string" || !id || data.user?.id !== id || verified.data.user?.id !== id || !matches(data.user) || !matches(verified.data.user)) throw new Error(text("mismatch"));
      options.clearAuthSession(id, "loading");
      await accept(verified.data, store.getState().epoch, true);
      options.legacy?.clear();
      localStorage.removeItem(keys.logout);
      options.afterLogin?.();
      announce("login");
    });
  }
  async function logoutSession() {
    const token = store.getState().accessToken;
    // 오프라인이어도 다시 열 때 쿠키가 되살아나지 않게 의도를 먼저 저장한다.
    localStorage.setItem(keys.logout, "1");
    try { await options.beforeLogout?.(); } catch { /* 정리 실패는 로그아웃을 막지 않는다 */ }
    options.clearAuthSession();
    announce("logout");
    await locked(async () => {
      await sessionRequest("logout", null, { headers: token ? { Authorization: "Bearer " + token } : undefined });
      // 로그아웃 표시는 다음 로그인 성공 때까지 둔다.
    });
  }
  async function unreachableStatus(): Promise<SessionStatus> {
    if (!options.startWithoutSession?.()) return "unavailable";
    if (!isNative() || !options.native?.hasCredential) return "ready";
    return (await options.native.hasCredential()) ? "unavailable" : "ready";
  }
  /** 시작·복귀 때 로그인 상태 확인. 끝난 세션이면 로그인 전 상태(ready), 서버에 닿지 못하면 unavailable(또는 정책에 따라 ready). */
  function restoreSession(): Promise<void> {
    const epoch = store.getState().epoch;
    if (booting && bootEpoch === epoch) return booting;
    bootEpoch = epoch;
    const pending = (async () => {
      store.setState({ status: "loading" });
      if (localStorage.getItem(keys.logout)) {
        const s = store.getState();
        if (s.user || s.accessToken) s.logout(); else store.setState({ status: "ready" });
        void locked(() => sessionRequest("logout")).catch(() => {});
        return;
      }
      let legacy: SessionLogin<TUser> | null;
      try { legacy = options.legacy?.read() ?? null; } catch { legacy = null; }
      try {
        await refreshSession();
        options.legacy?.clear();
      } catch (error) {
        if (axios.isCancel(error)) return;
        if (isTerminalSessionError(error)) {
          if (legacy?.accessToken && sessionCode(error) === "SESSION_EXPIRED") {
            try { await completeLogin(legacy); return; } catch (migration) {
              if (!isTerminalSessionError(migration)) { store.setState({ status: await unreachableStatus() }); return; }
            }
          }
          options.legacy?.clear();
          options.onSignedOut?.();
          store.setState({ status: "ready" });
        } else {
          store.setState({ status: await unreachableStatus() });
        }
      }
    })().finally(() => { if (booting === pending) booting = undefined; });
    booting = pending;
    return pending;
  }
  function acceptActivityEvent(raw: string) {
    try {
      const policy = JSON.parse(raw) as SessionPolicy;
      const current = store.getState().session;
      if (current?.sessionId === policy.sessionId && Date.parse(policy.serverNow) > Date.parse(current.serverNow)) acceptPolicy(policy);
    } catch { /* 서버 검증이 기준이다. */ }
  }
  if (typeof window !== "undefined") {
    window.addEventListener("storage", (event) => {
      if (event.key === keys.activity && event.newValue) { acceptActivityEvent(event.newValue); return; }
      if (event.key !== keys.event || !event.newValue) return;
      // 다른 탭이 쿠키를 바꿨다. 로그아웃이면 상태만 비우고(요청은 그 탭이 보냈다), 로그인이면 복원이 끝날 때까지 비회원 화면을 보이지 않는다.
      if (localStorage.getItem(keys.logout)) options.clearAuthSession();
      else { store.setState({ status: "loading" }); expireSession(); void restoreSession(); }
    });
  }
  /**
   * 화면 복귀(visibilitychange)·온라인 복귀 때 로그인 확인. 이미 로그인된 화면이면 status를 loading으로 바꾸지 않고 뒤에서 갱신만 한다.
   * restoreSession은 확인하는 동안 화면을 가려(SessionGate) 입력 중이던 단계가 처음으로 돌아갔다(인증번호 받으러 다른 앱에 다녀오면 이메일 변경이 처음부터, 오늘Do클래스 2026-10-25).
   * 끝난 세션이면 refreshSession이 expireSession으로 로그인 전 상태로 돌리고, 서버에 닿지 못하면 지금 화면을 그대로 둔다. 확인 중·다시 시도 상태는 restoreSession과 같다.
   * 1.26.1: 로그인 전(비회원·로그인 화면)도 화면을 가리지 않는다. 로그아웃 표시가 있으면 확인할 것이 없어 아무것도 하지 않고, 없으면 다른 곳에서 로그인했을 수 있어 뒤에서만 확인한다(계정 없이 쓰는 앱이 복귀마다 깜빡이던 문제, 오늘DoEat).
   */
  function resumeSession(): Promise<void> {
    const s = store.getState();
    if (s.status !== "ready") return restoreSession();
    if (localStorage.getItem(keys.logout)) return s.user ? restoreSession() : Promise.resolve();
    return refreshSession().catch(() => {});
  }
  /** 사용 기록 연장(웹만; 앱은 항상 로그인 유지라 없다). 접근 토큰이 만료였으면 한 번 갱신하고 다시 보낸다. */
  function recordSessionActivity(): Promise<void> {
    if (isNative()) return Promise.resolve();
    if (activityPending) return activityPending;
    const epoch = store.getState().epoch;
    const pending = (async () => {
      for (let attempt = 0; attempt < 2; attempt++) {
        assertEpoch(epoch);
        const token = store.getState().accessToken;
        if (!token) return;
        try {
          const { data } = await transport.post<SessionPolicy>(path + "/activity", null, { headers: { Authorization: "Bearer " + token } });
          assertEpoch(epoch); acceptPolicy(data);
          localStorage.setItem(keys.activity, JSON.stringify(data));
          return;
        } catch (error) {
          assertEpoch(epoch);
          if (attempt === 0 && sessionCode(error) === "SESSION_EXPIRED") { await refreshSession(); continue; }
          if (isTerminalSessionError(error)) expireSession();
          throw error;
        }
      }
    })().finally(() => { if (activityPending === pending) activityPending = undefined; });
    activityPending = pending;
    return pending;
  }
  /** 로그인 유지 세션을 짧은 세션으로 바꾼다(이 기기에서 로그인 유지 해제). */
  async function chooseShortSession() {
    const epoch = store.getState().epoch;
    await locked(async () => {
      assertEpoch(epoch);
      const { data } = await sessionRequest("policy", null, undefined, epoch);
      await accept(data, epoch); announce("login");
    });
  }
  /** 진행 중인 로그인 확인(시작·갱신)이 끝날 때까지 기다린다(간편 로그인 완료 화면). 없으면 바로 끝난다. */
  const sessionSettled = () => Promise.allSettled([booting, refreshing].filter(Boolean)).then(() => {});

  return { sessionCode, expireSession, refreshSession, completeLogin, logoutSession, restoreSession, resumeSession, recordSessionActivity, chooseShortSession, sessionSettled, acceptPolicy };
}
export type WebSession<TUser extends SessionUser = SessionUser> = ReturnType<typeof createWebSession<TUser>>;
