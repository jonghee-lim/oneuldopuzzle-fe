import { App } from "@capacitor/app";
import { isIosApp, isNativeApp } from "./runtime.ts";

/**
 * Android 하드웨어·제스처 뒤로가기(1.27.0, 공통 지침 '화면 공통 기준': 뒤로가기가 대화상자·시트를 먼저 닫는다).
 * Capacitor는 backButton 리스너가 있으면 기본 동작(웹 기록 뒤로·앱 종료)을 하지 않으므로 순서를 여기서 정한다.
 * 1. 열린 MUI 창(Dialog·Drawer·Menu·Popover — 모두 Modal)이 있으면 맨 위 창에 Esc를 보내 그 창의 onClose로 닫는다.
 *    진행 중이라 Esc 닫기를 막아 둔 창(disableEscapeKeyDown)은 그대로 두고 화면도 넘기지 않는다.
 * 2. 열린 창이 없으면 웹 기록 뒤로(canGoBack), 더 갈 곳이 없으면 앱을 닫는다(Android 기본과 같다).
 * 창마다 코드를 붙이지 않고 한 곳에서 처리한다. iOS·웹에서는 아무 일도 하지 않는다.
 */

/** 열린 MUI 창 가운데 맨 위(문서 순서상 마지막) 것. 닫히는 중·닫힌 창(MuiModal-hidden)은 뺀다. */
export function topOpenModal(doc: Document = document): HTMLElement | null {
  const list = doc.querySelectorAll<HTMLElement>(".MuiModal-root:not(.MuiModal-hidden)");
  return list.length ? list[list.length - 1] : null;
}

/** 창 안(포커스가 있으면 그 요소)에서 Esc를 보내 MUI가 맨 위 창의 onClose를 부르게 한다. */
export function closeModal(modal: HTMLElement, doc: Document = document): void {
  const active = doc.activeElement;
  const target = active instanceof HTMLElement && modal.contains(active) ? active : modal;
  target.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true, cancelable: true }));
}

export type BackButtonOptions = {
  /** 앱 정책 값(Android 앱만 true). false면 아무 일도 하지 않는다. */
  enabled: boolean;
  /** 창 닫기보다 먼저 볼 앱 고유 처리. true를 돌려주면 처리한 것으로 보고 멈춘다. */
  onBack?: () => boolean;
};

/** 앱 시작 때 한 번 부른다. 해제 함수를 돌려준다. */
export function installAndroidBackButton({ enabled, onBack }: BackButtonOptions): () => void {
  if (!enabled || !isNativeApp() || isIosApp()) return () => {};
  let handle: Promise<{ remove: () => Promise<void> } | null> = Promise.resolve(null);
  try {
    handle = App.addListener("backButton", ({ canGoBack }) => {
      if (onBack?.()) return;
      const modal = topOpenModal();
      if (modal) { closeModal(modal); return; }
      if (canGoBack) window.history.back();
      else void App.exitApp();
    }).catch(() => null);
  } catch {
    /* 브리지가 없는 환경(E2E)에서는 기본 동작에 맡긴다. */
  }
  return () => { void handle.then((h) => h?.remove()); };
}
