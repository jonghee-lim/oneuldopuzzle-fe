import { isIosApp, isNativeApp } from "./runtime.ts";

/**
 * 익명 사용 통계 공통 모듈(2026-10-29, 콘솔 모듈 ANONYMOUS_USAGE). 로그인 없는 앱이 날짜별 횟수만 공통 API로 보낸다.
 * 기기 ID·계정·IP를 만들거나 보내지 않는다. 서버(POST /api/usage/{앱})는 받은 숫자를 날짜·플랫폼·항목별로 더하기만 한다.
 *
 * - 앱은 createUsage 하나를 만들고 시작 때 start(), 순간마다 track("start:sudoku:hard")만 부른다.
 * - active: 그날 처음 연 기기만 1(하루 접속 기기 수), new: 이 기기에서 처음 연 때 1번(신규 기기 수).
 * - 숫자는 이 기기 localStorage에 한국 날짜별로 모은다. 열 때·돌아올 때(30분에 1번까지)와 내릴 때(10초에 1번까지) 보낸다.
 *   보낸 만큼만 빼고(보내는 사이에 센 것은 남음), 서버가 받지 않는 내용(400·404)은 버리고, 연결 실패·5xx·429는 다음에 다시 보낸다.
 *   7일 지난 날은 보내지 않고 버린다(서버도 7일 전까지만 받음).
 * - 사용자가 끄면(enabled() false) 세지도 보내지도 않고, clear()로 쌓인 것을 지운다.
 */

export type UsagePlatform = "web" | "ios" | "android";
export type UsageReport = { day: string; counts: Record<string, number> };
/** days: 한국 날짜별 보낼 횟수, seen: new를 셌음, activeDay: active를 센 마지막 날, lastSentAt: 마지막으로 보낸 시각. */
export type UsageState = { days: Record<string, Record<string, number>>; seen: boolean; activeDay: string; lastSentAt: number };

export const USAGE_KEEP_DAYS = 7;
export const USAGE_MAX_ITEMS = 60;
export const USAGE_MAX_COUNT = 500;
export const USAGE_RESUME_MS = 30 * 60 * 1000;
export const USAGE_HIDE_MS = 10 * 1000;
const DAY = 24 * 60 * 60 * 1000;
const KST = 9 * 60 * 60 * 1000;

export const emptyUsage = (): UsageState => ({ days: {}, seen: false, activeDay: "", lastSentAt: 0 });

/** 한국 날짜(YYYY-MM-DD). 서버도 한국 날짜로 받는다. */
export function usageDay(now: number): string {
  return new Date(now + KST).toISOString().slice(0, 10);
}

export function usagePlatform(): UsagePlatform {
  if (!isNativeApp()) return "web";
  return isIosApp() ? "ios" : "android";
}

/** 기기에 남은 상태를 읽는다. 모양이 이상하면 빈 상태. */
export function normalizeUsage(raw: unknown): UsageState {
  if (!raw || typeof raw !== "object") return emptyUsage();
  const r = raw as Partial<UsageState>;
  const days: UsageState["days"] = {};
  if (r.days && typeof r.days === "object") {
    for (const [day, counts] of Object.entries(r.days)) {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(day) || !counts || typeof counts !== "object") continue;
      const clean: Record<string, number> = {};
      for (const [metric, n] of Object.entries(counts)) if (typeof n === "number" && n > 0) clean[metric] = Math.floor(n);
      if (Object.keys(clean).length) days[day] = clean;
    }
  }
  return {
    days,
    seen: r.seen === true,
    activeDay: typeof r.activeDay === "string" ? r.activeDay : "",
    lastSentAt: typeof r.lastSentAt === "number" ? r.lastSentAt : 0,
  };
}

/** 7일보다 오래된 날을 버린다. */
export function pruneUsage(state: UsageState, now: number): UsageState {
  const oldest = usageDay(now - USAGE_KEEP_DAYS * DAY);
  const days = Object.fromEntries(Object.entries(state.days).filter(([day]) => day >= oldest));
  return { ...state, days };
}

export function trackUsage(state: UsageState, metric: string, now: number, amount = 1): UsageState {
  const day = usageDay(now);
  const counts = { ...(state.days[day] ?? {}) };
  counts[metric] = Math.min((counts[metric] ?? 0) + amount, USAGE_MAX_COUNT);
  return { ...state, days: { ...state.days, [day]: counts } };
}

/** 앱을 열거나 돌아왔을 때: 그날 처음이면 active 1, 이 기기에서 처음이면 new 1. 이미 셌으면 그대로. */
export function openUsage(state: UsageState, now: number): UsageState {
  const day = usageDay(now);
  let next = state;
  if (state.activeDay !== day) next = { ...trackUsage(next, "active", now), activeDay: day };
  if (!state.seen) next = { ...trackUsage(next, "new", now), seen: true };
  return next;
}

/** 보낼 묶음: 오래된 날부터, 한 번에 USAGE_MAX_ITEMS 항목까지. */
export function pendingUsage(state: UsageState, now: number): UsageReport[] {
  const out: UsageReport[] = [];
  let items = 0;
  for (const day of Object.keys(pruneUsage(state, now).days).sort()) {
    const counts: Record<string, number> = {};
    for (const [metric, n] of Object.entries(state.days[day])) {
      if (items >= USAGE_MAX_ITEMS) break;
      counts[metric] = n;
      items++;
    }
    if (Object.keys(counts).length) out.push({ day, counts });
    if (items >= USAGE_MAX_ITEMS) break;
  }
  return out;
}

/** 보낸 만큼 뺀다(보내는 사이에 더 센 것은 남는다). */
export function removeSent(state: UsageState, sent: UsageReport[]): UsageState {
  const days = { ...state.days };
  for (const { day, counts } of sent) {
    const left = { ...(days[day] ?? {}) };
    for (const [metric, n] of Object.entries(counts)) {
      const rest = (left[metric] ?? 0) - n;
      if (rest > 0) left[metric] = rest;
      else delete left[metric];
    }
    if (Object.keys(left).length) days[day] = left;
    else delete days[day];
  }
  return { ...state, days };
}

type UsageStorage = Pick<Storage, "getItem" | "setItem" | "removeItem">;
type UsageDoc = Pick<Document, "visibilityState" | "addEventListener" | "removeEventListener">;

export type UsageOptions = {
  /** 콘솔 앱 코드(예: ONEULDOPUZZLE). */
  service: string;
  /** 공통 API 주소(예: https://api.smartinfol.com). 비우면 아무것도 보내지 않는다. */
  apiBase: string;
  storageKey: string;
  /** 사용자 설정 '익명 사용 통계 보내기'. */
  enabled: () => boolean;
  platform?: () => UsagePlatform;
  storage?: UsageStorage;
  doc?: UsageDoc;
  fetch?: typeof fetch;
  now?: () => number;
};

export type Usage = {
  /** 앱 시작 때 한 번: 오늘 접속을 세고 보낸 뒤, 돌아올 때·내릴 때 보내기를 건다. 돌려준 함수로 끈다. */
  start: () => () => void;
  track: (metric: string, amount?: number) => void;
  /** 쌓인 것을 지금 보낸다(throttle 무시는 force). */
  flush: (force?: boolean) => Promise<void>;
  /** 쌓인 것과 '처음 연 기기' 표시를 지운다(설정에서 끌 때). */
  clear: () => void;
};

export function createUsage(options: UsageOptions): Usage {
  const now = options.now ?? (() => Date.now());
  const storage = (): UsageStorage | null => {
    try {
      return options.storage ?? globalThis.localStorage ?? null;
    } catch {
      return null;
    }
  };
  const read = (): UsageState => {
    try {
      return normalizeUsage(JSON.parse(storage()?.getItem(options.storageKey) ?? "null"));
    } catch {
      return emptyUsage();
    }
  };
  const write = (state: UsageState) => {
    try {
      storage()?.setItem(options.storageKey, JSON.stringify(pruneUsage(state, now())));
    } catch {
      /* 저장소를 못 쓰면 이번 숫자는 버린다 */
    }
  };
  let sending: Promise<void> | null = null;

  const flush = (force = false, minGap = USAGE_RESUME_MS): Promise<void> => {
    if (sending || !options.enabled() || !options.apiBase) return sending ?? Promise.resolve();
    const state = read();
    const t = now();
    if (!force && t - state.lastSentAt < minGap) return Promise.resolve();
    const reports = pendingUsage(state, t);
    if (!reports.length) return Promise.resolve();
    const send = options.fetch ?? globalThis.fetch;
    write({ ...state, lastSentAt: t });
    sending = send(`${options.apiBase.replace(/\/$/, "")}/api/usage/${encodeURIComponent(options.service)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ platform: (options.platform ?? usagePlatform)(), reports }),
      keepalive: true,
      credentials: "omit",
    })
      .then((res) => {
        // 받았거나(2xx) 서버가 받지 않는 내용(400·404·413)이면 뺀다. 429·5xx는 남겨 다음에 보낸다.
        if (res.ok || res.status === 400 || res.status === 404 || res.status === 413) write(removeSent(read(), reports));
      })
      .catch(() => {})
      .finally(() => {
        sending = null;
      });
    return sending;
  };

  const open = () => {
    if (!options.enabled()) return;
    const before = read();
    const after = openUsage(before, now());
    if (after !== before) {
      write(after);
      void flush(true);
    } else void flush();
  };

  return {
    start() {
      open();
      const doc = options.doc ?? (typeof document === "undefined" ? null : document);
      if (!doc) return () => {};
      const onVisibility = () => {
        if (doc.visibilityState === "visible") open();
        else if (options.enabled()) void flush(false, USAGE_HIDE_MS);
      };
      doc.addEventListener("visibilitychange", onVisibility);
      return () => doc.removeEventListener("visibilitychange", onVisibility);
    },
    track(metric, amount = 1) {
      if (!options.enabled()) return;
      write(trackUsage(read(), metric, now(), amount));
    },
    flush: (force = false) => flush(force),
    clear() {
      try {
        storage()?.removeItem(options.storageKey);
      } catch {
        /* 무시 */
      }
    },
  };
}
