# @smartinfolab/app-core

앱 버전(웹·웹앱·iOS·안드로이드) 처리 로직 가운데 앱마다 같은 것을 모은 공유 패키지(공통 지침 #25 APP_SHARED_CORE).
앱마다 다른 값(서비스 코드, URL 스킴, API 경로, 저장 키)은 설정으로 넘기고, 앱 저장소에서 패키지 코드를 고치지 않는다.

| 경로 | 내용 | 앱 설정 |
|---|---|---|
| `./runtime` | 웹·웹앱·앱·iOS 판별 | 없음 |
| `./layout` | 화면 폭 구간, 본문 최대 너비·여백, 안전 영역 전체 높이, 앱 틀 높이, MUI 구간, 채우기(한 줄 더보기) | 앱 고유 줄 높이·칸은 앱 layout.ts에서 더한다 |
| `./app-events` | 앱 복귀 감지, 외부 링크(스토어) 열기 | 없음 |
| `./app-version` | 현재 앱 버전·플랫폼, 업데이트 ‘나중에’ 7일 기억 | 웹 빌드 버전, 저장 키 |
| `./native-return` | 카카오·Apple 앱 복귀, 선택적 Google 복귀·Android 처리 | URL 스킴, 대기 state 확인, providers·android opt-in |
| `./google-auth` | Google 로그인·연결·재인증·해제와 일회용 완료 처리 | 앱 axios, 서비스 코드, 저장 키, client·open |
| `./social-auth` | 카카오·Apple 로그인 클라이언트 `createKakaoAuth`·`createAppleAuth`(google-auth와 같은 모양): PKCE, 시작 주소·state 검사, 대기 정보(sessionStorage·예비 localStorage·설치형 앱 보안 저장소)·유효 시간·시작 계정 검사, 로그인·가입·연결·재인증 완료(kind), 카카오 가입 확인(pendingSignup·signup), 완료는 진행 중 중복만 합치고 끝나면 비움, `isPending(state)`(앱 복귀) | 앱 axios, 앱 이름(카카오)·API 경로(Apple), 저장 키, open, client, persistence·context(설치형 앱), reauthMode(스파클) |
| `./native-session` | 앱 전용 로그인 세션(refresh token 키체인 저장, native-session API) | 서비스 코드, 키체인 앞붙임, 설치 키, API 경로, API 주소 |
| `./web-session` | 웹 쿠키 세션 클라이언트 `createWebSession`: exchange → refresh 검증 → 받아들이기, refresh(BUSY 재시도·끝난 세션 만료 처리), logout(오프라인 의도 저장), restore(옛 저장값 이전·서버에 닿지 못할 때 정책), activity·policy, 탭 사이 알림·잠금, 세대(epoch) 검사, U1-b(로그인 전에는 세대를 올리지 않음) | 앱 axios, API 경로, 서비스 코드(null이면 id만), 저장 키, authStore, clearAuthSession·onExpire, native(설치형 앱 세션), startWithoutSession, legacy, beforeLogout·afterLogin·onSignedOut, enrich(스파클 프로필), notices |
| `./signup` | 회원가입 부품: `EmailVerificationField`(이메일 + 인증번호 받기·확인, 중복 확인 선택, 60초 재요청 제한, 카카오 인증 이메일 건너뛰기), `PasswordFields`(비밀번호·확인 + 규칙 ✓ 목록), `RememberLoginChoice`(이 기기에서 로그인 유지); 순수 계산은 `./signup-model`(`normalizeSignupEmail`·`codeDigits`·`isDuplicateEmailError`·`signupPasswordError`) | 앱 axios로 감싼 checkEmail?·start·confirm |
| `./account-model`·`./email-validation` | 비밀번호 규칙 `passwordRuleError`·`passwordChecks`, 복구 요청 본문 `recoveryBody`, 이메일 형식 검사 `emailValidation`(앱 사본 대신) | - |
| `./account-action` | 내 계정 로그인 수단 연결·해제·이메일 변경의 재인증 왕복 기억, 마지막 수단·재인증 수단 판정, 오류 code·message | 저장 키(예: `dallhythm-account-action`) |
| `./account-ui` | 내 계정 로그인 수단 공통 MUI 부품: `useLoginMethods`(조회·연결·해제·재인증 이어가기·이메일 변경 상태), `LoginMethodDialogs`(연결·해제 확인, 이메일 변경) | 저장 키, 쿼리 키, 앱 API 함수(카카오·Apple 시작·해제, 계정 조회·이메일 변경) |
| `./social-availability` | 로그인 화면 간편 로그인 표시 상태 표준 `useSocialAvailability`: 공통 API `/api/auth/social/config` 한 번으로 카카오·Apple·Google을 받아 세 버튼을 함께 켠다. 마지막 응답을 기기에 기억, 확인 중엔 자리만(누르기 불가·문구 없음), 꺼진 수단은 자리 없음 | 앱 axios, 서비스 코드 |
| `./social-complete` | 간편 로그인 완료 화면 표준 `SocialCompletePage`: 한 번만 처리, 주소의 인증 값 읽고 지우기, 확인 중·실패 화면, 실패 안내 규칙(`socialCompleteMessage`: 서버 안내 그대로 → 연결 안내 → 앱 Error 문구 → 기본 문구), 공급자 취소·만료 문구(`socialReturnError`) | 수단, 완료 처리 run, 실패 정리 onError, 로그인 여부, 로그인·내 계정 주소, 라우터 Link |
| `./social-login` | 로그인 화면 간편 로그인 버튼 `SocialLoginButtons`: 세로(큰 버튼)·가로(아이콘+이름), 카카오→Apple→Google 순서·각 회사 버튼 규정 고정 | 앱 정책 `socialLoginLayout`, 수단별 onClick·disabled·hint |
| `./social-login-start` | 간편 로그인 시작·‘로그인 중’ 표준 `useSocialLoginStart`: 누르면 세 수단이 함께 막히고 "{수단}로 이동 중…", 창을 연 뒤에도 유지, 로그인하지 않고 돌아오면(앱 복귀·창 닫힘·탭 복귀·bfcache) 풀림, 시작 실패 문구 규칙(서버 안내 → 연결·서버 장애 → 앱 문구 → 기본). `items(availability)`로 `SocialLoginButtons` items 생성. 돌아옴 신호 `onLoginWindowReturn`(./app-events)·`onLoginWindowReturnWeb` | 수단별 시작 함수, 설치형 앱은 onReturn, 앱 다국어 문구(선택) |
| `./login-layout` | 로그인 화면 공통 틀 `LoginLayout`: 로고·제목·안내 → 계정 없이 사용 → 로그인 유지 → 안내 → 간편 로그인 → ‘이메일로 로그인’ 구분선 → 이메일 폼 → 찾기·가입 한 줄, 카드 밖 footer. 간격·구분선·카드·정렬만 맡는다(순서는 `loginSections`로 테스트) | 앱이 슬롯(ReactNode)으로 기존 버튼·폼·안내를 넘긴다 |
| `./withdrawal-complete` | 회원 탈퇴 완료 공통 화면 `WithdrawalComplete`: 제목·본문·이동 버튼(로그인 화면으로/홈으로), 앱 고유 한 줄은 `note` | 앱 이름, 버튼(to+Link 또는 href 또는 onClick), note, logo |
| `./withdrawal-notice` | 회원 탈퇴 안내 공통 문구 `withdrawalNotice`·`useWithdrawalNotice`: 연결된 간편 로그인 수단에 맞는 "계정 자체는 삭제되지 않음" + "다시 가입하면 새 계정" | 로그인 수단 조회 결과(`kakao`·`apple`·`google`) |
| `./account-layout` | 내 계정 공통 틀 `AccountLayout`: 제목 → 프로필 카드(별명·로그인 방식 자동 표시·이메일·별명 대화상자) → 로그인 수단(`useLoginMethods`·`LoginMethodDialogs`) → 앱 칸 → 계정(이메일 변경, 이메일 계정만 비밀번호 재설정) → 로그아웃(앱 primary 연한 바탕 + 확인) → 회원 탈퇴 링크. 헤더 아이콘 `AccountHeaderButton` | 계정 정보, 로그인 수단 컨트롤러, providers, 별명 저장 함수, appSections, 재설정 client·serviceCode·onDone, 로그아웃 문구, 탈퇴 주소·Link |
| `./settings-list` | 설정·내 계정 묶음 목록 `SettingsGroup`·`SettingsRow`(달 리듬 모양) | 앱 라우터 `linkComponent` |
| `./password-reset`(1.24.0: `purpose` FIND_ID 아이디 찾기, 페이지형 `PasswordResetForm`, 로그인 화면 링크 줄 `AccountRecoveryLinks`) | 공통 `/api/auth/recovery/*` 3단계 비밀번호 재설정 `PasswordResetDialog` | 앱 axios client, 서비스 코드, 끝난 뒤 처리, 앱 고유 안내 문구(선택) |
| `./mui-shape` | MUI 모서리 표준: `radius` 토큰(card 16px·item 12px·control 10px·small 8px·pill), `standardShape`, 테마에 펼쳐 넣는 `radiusComponents` | 없음(테마에 펼쳐 넣기만) |
| `./locale` | 다국어 기반(의존성 없음): 지원 언어 ko·en·ja, 언어 결정 `resolveLanguage`, app-core 문구 `coreT`·화면 언어 `getCoreLanguage`·`setCoreLanguage`, 공통 오류 `errorKind`·`commonErrorMessage`·`localizedServerError`·`serverCodeMessage`(ko만 서버 한국어 안내, en·ja는 code·종류 문구), 한국 공휴일 판정 `usesKoreanHolidays`·`koreanHoliday` | 없음(언어를 안 정하면 ko) |
| `./i18n` | 앱 다국어 초기화 `createAppI18n`(i18next·react-i18next, 선택 peer): app-core 사전(common·appCore) + 앱 사전 합치기, 저장값 > 기기 언어 > en, 빠진 번역은 en → ko(`fixed:"ko"`면 ko), `fixed:"ko"`, 선택 저장·`<html lang>`·app-core 문구 함께 전환, `useLanguageChoice`. `./locale` 내용도 다시 내보낸다 | 앱 사전, 저장 키, 지원 언어, 고정 언어 |
| `./language-picker` | 언어 선택 MUI 부품 `LanguageSettingsRow`(설정 한 줄)·`LanguageDialog`: 기기 설정 따르기·한국어·English·日本語 | 선택 값·바꾸는 함수 |
| `./date-format` | 날짜·월·요일·기간 표시(Intl). ko는 공통 지침 기간 표준을 그대로(`26.10.12 ~ 10.18`, `11.02`, `27.01.25`, `2026-10-15 09:00 ~ 10-20 18:00`), en·ja는 각 언어 형식 | 언어(기본 화면 언어), 시간대 |
| `./i18n-check` | 빠진 번역 검사 `checkTranslations(ko, {en, ja})`: 빠진 키·남는 키·`{{값}}` 차이·빈 값. 앱 사전 테스트에도 쓴다 | 없음 |
| `./testing/fake-ios` | E2E 가짜 설치형 앱(사용자 지정 플랫폼 ios·android, 메모리 키체인, App·Browser 브리지) | 플랫폼, 키체인 값, 설치 키, 앱 정보 |

## 쓰는 법

- 앱은 `src/platform/*`, `src/auth/native*.ts`, `src/theme/layout.ts` 같은 얇은 파일에서 이 패키지를 설정해 다시 내보낸다. 화면·컴포넌트는 지금처럼 앱 파일만 가져온다.
- 패키지는 원본(TypeScript)을 그대로 내보낸다. 앱의 Vite·tsc가 컴파일한다(`allowImportingTsExtensions`).
- 앱 단위 테스트는 패키지 import를 이 폴더 원본으로 돌린다(`tests/personal-core-loader.mjs`). Node는 node_modules 안 .ts를 실행하지 않기 때문이다.

## 고칠 때

1. 이 폴더에서 고치고 `npm run lint`(공용 모듈 자체 lint, 앱 lint에서는 제외됨)와 `npm test`(패키지 단위 테스트)를 돌린다.
2. `package.json` 버전을 올리고 `npm run pack`(lint·테스트 후 `npm pack --pack-destination ../../vendor`)으로 묶는다.
3. 적용이 승인된 앱에만 `vendor/` tgz와 의존성 버전을 올린 뒤 해당 앱 테스트를 실행한다. 심사 중·기존 배포 앱의 고정 버전은 일괄 변경하지 않는다.
4. 한 앱만 다르게 해야 하면 설정 항목을 추가하고 그 앱 AGENTS.md에 이유를 적는다.

현재 개발 소스: 1.16.2(다른 이메일 설정 뒤 화면 반영 수정). 1.16.1(AI 비서 연결 앱별 자세한 가이드). 1.16.0은 AI 비서 연결 공통 화면 `./ai-connect`. 1.15.0은 로그인 방법 목록·이메일 로그인 설정 3단계 시트. 1.14.0은 내 계정 이메일/비밀번호 행 ‘연결하기’. 1.13.0은 탈퇴 완료 공통 화면 `./withdrawal-complete`. 1.12.0은 탈퇴 안내 공통 문구 `./withdrawal-notice`. 1.11.0은 소셜 전용 계정 이메일 비밀번호 만들기(오늘Do클래스가 먼저 쓴다). 1.10.0은 공통 다국어 기반(ko 화면 변화 없음). 1.9.1·1.10.0은 묶음만 만들었고 앱 적용은 다음 배포 때 앱별로 한다. 달 리듬·오늘DoIt·오늘DoFamily·스파클·오늘DoEat·수학메이트·워크스페이스 모두 1.9.0을 쓴다. 원본 위치: oneuldoit-fe/packages/app-core. 다른 소비 앱(오늘DoFamily·스파클·오늘DoEat·수학메이트·워크스페이스)은 기존 고정 tarball을 유지한다. 새 버전 적용은 앱별로 명시적으로 수행한다.

| 버전 | 바뀐 점 |
|---|---|
| 1.25.1 | 문구만(사용자 입장, 2026-10-25 실기기 확인 피드백). 이메일 로그인 해제 시트 안내 `appCore.methods.removeNotice` → “해제 안내 메일을 {{email}} 주소로 보내 드립니다. 다시 쓰려면 이 화면에서 이메일 로그인을 설정하면 됩니다.”, 이메일 로그인 설정 3단계 `appCore.emailLogin.noticeMail` → “설정이 끝나면 {{email}} 주소로 안내 메일을 보내 드립니다.”(둘 다 email 변수, ko·en·ja). 메일 제목을 따옴표로 인용하던 모양을 없앴다. 동작 변화 없음 |
| 1.25.0 | 이메일 로그인 해제(설계 `dev/workspace/_review/email-login-remove-design-2026-10-25.md`). `LoginMethodsApi.password.remove`(POST /api/<앱>/account/email-login/remove) 추가: 다른 수단이 연결된 이메일 계정이면 내 계정 › 이메일 · 비밀번호 행이 ‘사용 중 ›’가 되어 해제 시트(현재 비밀번호 → [해제])를 열고, 유일한 수단이면 둘째 줄에 ‘유일한 로그인 방법이라 해제할 수 없습니다’. 해제 뒤 세션 유지, 행은 ‘설정 ›’로 돌아가고 비밀번호 재설정 행이 사라진다. `./account-model`에 `canRemoveEmailLogin`·`isLastLocal`·`localRowCaption`·`remainingProvidersText`, `localRowState`에 `removable`. 사전 `appCore.methods.remove*`·`emailRemoved`, `appCore.emailLogin.otherHint`를 ‘계정 이메일 자체가 바뀜’으로(ko·en·ja). remove를 넘기지 않은 앱은 이전과 같다 |
| 1.24.0 | 로그인 공통화 P4. `./password-reset`에 `purpose`(RESET·FIND_ID: 아이디 찾기 결과 loginIds 표시)·`PasswordResetForm`(대화상자 없이 페이지 카드 안)·`AccountRecoveryLinks`(로그인 화면 [아이디 찾기] [비밀번호 찾기] + 앱 링크) 추가. `./signup`(컴포넌트)·`./signup-model`(순수 계산) 추가: `EmailVerificationField`·`PasswordFields`·`RememberLoginChoice`, `normalizeSignupEmail`·`codeDigits`·`isDuplicateEmailError`·`signupPasswordError`. `./account-model`·`./email-validation` 공개. `recoveryBody`에 purpose, `findIdText`. 사전 `appCore.recovery.*`·`appCore.signup.*`·`appCore.login.remember`(ko·en·ja). 기존 `PasswordResetDialog` 모양·동작 변화 없음(내 계정 그대로) |
| 1.23.0 | 로그인 공통화 P3. `./web-session` 추가: `createWebSession({ transport, path, serviceCode, keys, store, clearAuthSession, onExpire?, native?, startWithoutSession?, legacy?, beforeLogout?, afterLogin?, onSignedOut?, enrich?, notices? })` → `refreshSession`·`completeLogin`·`logoutSession`·`restoreSession`·`recordSessionActivity`·`chooseShortSession`·`sessionSettled`·`expireSession`·`sessionCode`·`acceptPolicy`, `isTerminalSessionError`. 7개 앱의 sessionClient.ts(208~248줄)를 설정 한 덩어리의 껍데기로 바꾼다. 모든 앱에 같게: U1-b(로그인 전에는 만료 처리·로그아웃 표시 복원에서 세대를 올리지 않음, 2026-10-24 오늘Do클래스), 앱 세션 오류 code(SESSION_*) 읽기, 다른 탭 로그인 알림은 복원이 끝날 때까지 loading, 설치형 앱은 사용 기록(activity)을 보내지 않음. 사전 `appCore.session.*`(expired·wrongService·mismatch, ko·en·ja). 시험 tests/web-session.test.mjs(스파클 session-client.test.mjs를 옮기고 훅·U1-b 추가). 기존 모듈 변화 없음 |
| 1.22.0 | 로그인 공통화 P2. `./social-auth` 추가: `createKakaoAuth({ app, api, storageKey, open, client?, persistence?, fallbackStorage?, context?, reauthMode? })`·`createAppleAuth({ base, … })` → `start({ rememberLogin, returnTo })`·`link`·`reauth`·`complete(fragment)`(kind login·signup·link·reauth)·`unlink`·`available`·`isPending`·카카오 `pendingSignup`·`signupProfile`·`signup`·`cancelSignup`. 8개 앱의 kakaoApi·appleApi(55~345줄)를 설정 몇 줄의 얇은 껍데기로 바꾼다. 완료 결과를 캐시하지 않는다(2026-10-24 U1), 대기 정보 유효 시간·형식·설치형 앱 앞붙임·시작 계정 검사를 모든 앱에 같게. 사전 `appCore.oauth.*`(ko·en·ja). 기존 모듈 변화 없음 |
| 1.21.0 | 로그인 공통화 P1. `./social-login-start` 추가: `useSocialLoginStart({ starters, onReturn, messages })` — 간편 로그인 시작·‘로그인 중’ 규칙을 8개 앱에서 하나로(사용자 결정 2026-10-24 "창에서 돌아오면 푼다", 달 리듬 방식). `./app-events`에 `onLoginWindowReturn`(Android appStateChange·iOS browserFinished·웹 visibilitychange·pageshow) 추가(달 리듬 `platform/appEvents.ts`에서 옮김). **`./account-action` accountErrorMessage 수정**: ko에서 서버 안내가 없는 axios 오류는 연결·시간 초과·요청 과다·서버 장애면 종류 문구, 그 밖은 fallback(전에는 axios 영어 원문이 보였다). 서버 안내는 message 다음 detail도 읽는다. 사전 `appCore.social.going`·`startFailed` 추가. 내 계정 화면 등 accountErrorMessage를 쓰는 모든 곳의 영어 원문이 사라지는 것 외 화면 변화 없음 |
| 1.20.1 | `./native-return` 수정: `android: true` 앱은 카카오·Apple 복귀도 `android.` state를 받는다(전에는 Google만 받아 Android 앱의 카카오·Apple 로그인이 완료 화면으로 넘어가지 않았다). iOS 앱·웹은 변화 없음 |
| 1.20.0 | `./review-prompt` 추가(추가만, 기존 모듈 변화 없음): 평점 유도 공통 모듈 `createReviewPrompt({ service, storageKey, defaults, enabled, fetchConfig })` → `start()`·`note(순간, 횟수)`. iOS 앱은 App Store 별점 창, Android 앱은 Google Play 인앱 리뷰(`@capacitor-community/in-app-review`, 선택 peer), 웹은 아무것도 안 하고 플러그인도 안 불러온다. 규칙: 처음 실행 후 `firstOpenDays`·마지막 요청 후 `cooldownDays` 동안 묻지 않고, 켜진 순간 중 하나라도 기준에 닿으면 묻고 모든 횟수를 0으로. 설정 원본은 워크스페이스 ‘평점 유도’(공통 API `GET /api/app/review-prompt`), 못 읽으면 마지막 값·기본값. 앱마다 달랐던 예전 기기 저장 모양(오늘DoIt·달 리듬·오늘DoEat·오늘Do클래스)을 이어 읽는다. 오늘Do클래스의 ‘공통화하지 않음’ 결정(2026-10-24)을 사용자 지시로 바꿈 |
| 1.19.0 | `./web-update` 추가(추가만, 기존 모듈 변화 없음): `watchWebUpdate({ enabled })` — 웹·홈 화면 웹앱이 화면으로 돌아올 때(1분 간격)와 30분마다 배포된 index.html의 Vite 시작 묶음(`/assets/*.js`) 이름을 지금 것과 비교해 다르면 새로고침한다. 입력 중·대화상자가 열려 있으면 닫힐 때까지 미루고, 같은 새 버전으로는 10분 안에 다시 새로고침하지 않는다. 설치형 앱은 앱 정책 값(`enabled`)과 `isNativeApp()` 두 겹으로 꺼지고, 개발 서버·E2E(`/src/main.tsx`)도 꺼진다. 오래 켜 둔 홈 화면 웹앱이 예전 화면 코드로 돌아 메뉴가 멈춘 문제(오늘DoIt, 2026-10-24) |
| 1.18.0 | `./ai-connect`: `AiConnectSettings`·`AiConnectGuide`에 `connectorName`(커스텀 커넥터 이름 칸에 넣을 이름) 추가. 넘기면 설정 요약에 ‘커넥터 이름’ 칸과 복사 버튼, 가이드의 이름 안내(Claude `{{name}}`, ChatGPT `{{server}}`)가 화면 언어와 관계없이 그 이름이 되고 단계 안에 이름·주소 복사 버튼이 함께 보인다. 로그인·동의 화면 이름(`brand`)은 그대로. 사용자 결정 2026-10-22(오늘DoIt 글로벌 이름 TodaysDoIt). 넘기지 않으면 1.17.9와 같은 화면 |
| 1.16.2 | 화면 보완(실기기 확인 2026-10-19): 프로필 카드 둘째 줄을 수단 아이콘 줄로(글자는 aria-label), 연결 계정 이메일을 모르는 소셜 행은 ‘로그인에 사용 중’으로 행 높이 통일, 누를 수 없는 행도 화살표 자리를 비워 배지 열 정렬, 안내문·둘째 줄 단어 단위 줄바꿈, 완료 안내를 ‘이메일 로그인을 설정했습니다. 이제 {이메일}과 비밀번호로도…’로. 버그 수정: 이메일 로그인 설정 ‘다른 이메일’에서 prepare가 계정 이메일을 바꾼 뒤 앱에 알리지 않아(`onEmailChanged` 미호출) 내 계정 프로필·이메일 행이 예전 주소로 남던 문제(오늘DoIt iOS 1.3(18) 실기기 보고). 시트의 prepare 성공과 재인증 복귀 경로 모두에서 `onEmailChanged`를 부르고 로그인 수단을 다시 읽는다(`controller.emailPrepared`). 쓰는 모든 앱 영향 |
| 1.16.1 | `./ai-connect`: ‘연결 방법’ 카드에 ? 버튼과 ‘자세한 연결 가이드 보기’를 더해 앱별 가이드(Claude · ChatGPT 웹·데스크톱·모바일 · Claude Code, 요금제·메뉴 경로·주소/명령 복사·음성 지원·문제 해결)를 SheetDialog로 연다. 문구는 `src/ai-connect-guide.ts`(ko·en·ja, 2026-10 기준). 추가만, `./ai-connect`를 쓰지 않는 앱은 변화 없음 |
| 1.16.0 | `./ai-connect`·`./ai-connect-model`(타입·오류 규칙) 추가: AI 비서 연결 공통 화면 `AiConnectSettings`(연결 방법·서버 주소 복사·연결된 AI 목록·해제)와 OAuth 동의 화면 `AiConsent`(허용/거부 → AI 앱으로 이동, 만료·연결 수 한도·루프백 경고). 앱은 brand·mcpUrl·api(`AiConnectApi`)만 넘긴다. 서버는 공통 OAuth(`/oauth/*`) + `/api/<앱>/ai/oauth/request·decision`, `/api/<앱>/ai/connections`. 문구 `appCore.aiConnect.*` ko·en·ja. 오늘DoIt이 첫 사용처(2026-10-19). 1.15.0에서 새 모듈·새 문구 키만 **추가**했으므로, 다른 앱이 1.16.0으로 올려도 `./ai-connect`를 쓰지 않으면 화면 변화가 없다(2026-10-19 기준 다른 7개 앱은 1.15.0 유지) |
| 1.15.0 | 설계 `smartinfolab-api/docs/EMAIL-LOGIN-SETUP-DESIGN.md`. `./account-layout`: 로그인 방법 행에 수단 아이콘·연결 계정 이메일(`methods.accounts`)·배지(사용 중·연결됨)·버튼 모양 글자(설정·연결하기), 수단이 하나면 안내 한 줄. 이메일·비밀번호 행은 ‘설정’ → 3단계 시트(이메일 고르기 → 인증번호 → 비밀번호 ✓ 목록). `LoginMethodsApi.password.other`(start·confirm·prepare)를 넘기면 ‘다른 이메일 사용’이 보이고, 계정 이메일이 없는 소셜 계정도 설정할 수 있다. 재인증 왕복은 `account-action`의 `emailLogin` 작업(돌아오자마자 prepare). `./sheet-dialog`: 휴대폰은 아래 시트, 그 밖은 가운데 창(연결·해제·이메일 변경도). `SettingsRow`에 `icon`·`trailing`. 이메일 변경 설명 문구 변경. 사용자 결정 2026-10-19 |
| 1.14.0 | `./account-layout`: 로그인 수단의 이메일/비밀번호 행이 소셜 전용·연결 가능 계정이면 ‘연결하기’로 보이고, 누르면 이메일 로그인 연결(비밀번호 만들기) 창을 연다(`account-model`의 `localRowValue`). 계정 칸에 따로 있던 ‘이메일 비밀번호 만들기’ 행은 이 행으로 옮겼다. 관리 불가(자녀·학생) 계정은 ‘없음’ 그대로. 사용자 결정 2026-10-19 |
| 1.13.0 | `./withdrawal-complete`: 회원 탈퇴 완료 공통 화면 `WithdrawalComplete({ appName, action, note?, logo? })`. 제목 "탈퇴가 완료되었습니다" → 본문 "{앱} 계정과 기록을 삭제했습니다. 이용해주셔서 감사합니다." → 버튼(로그인 화면으로/홈으로)(ko·en·ja). 사용자 결정 2026-10-19: 앱마다 달랐던 완료 처리(완료 화면·로그인 알림·alert·토스트)를 완료 화면 하나로 통일. 앱 고유 한 줄(예: 달 리듬 기기 저장 기록)은 `note`로 |
| 1.12.0 | `./withdrawal-notice`: 회원 탈퇴 안내 공통 문구 `withdrawalNotice(methods)`·`useWithdrawalNotice(methods)`. 연결된 간편 로그인 수단만 골라 "{수단} 계정 자체는 삭제되지 않습니다." + "다시 가입하면 새 계정으로 시작합니다."(ko·en·ja). 이메일만 쓰거나 수단을 아직 모르면 뒤 문장만. 사용자 결정 2026-10-19: 탈퇴 안내는 꼭 필요한 문구만, 앱마다 따로 쓰지 않고 공통. 앱 고유 삭제 범위 설명은 앱에 남긴다 |
| 1.11.0 | `account-ui`: 소셜 전용 계정의 ‘이메일 비밀번호 만들기’(`LoginMethodsApi.password` {start, confirm, set}, `canSetPassword`·`openPassword`, `SetPasswordDialog`). `account-layout` 계정 묶음에 행 추가(이메일 비밀번호가 없고 계정 이메일이 있을 때만). 서버는 공통 `/api/<앱>/account/password/start`·`/account/password` + 공통 인증번호 확인. 사용자 결정 2026-10-17(오늘Do클래스): 소셜 가입자가 PC 웹에서 이메일로도 로그인할 수 있게. `password`를 넘기지 않은 앱은 화면 변화 없음 |
| 1.10.0 | 공통 다국어 기반(ko·en·ja). 2026-10-16 번역 검수 반영: en 계정 연결 용어 Link/Unlink, `social.title`을 확인 중 문구와 구분, 재설정·이메일 변경 안내 문장 보완, ja 전각 콜론(ko 값 변화 없음). `checkTranslations`는 i18next 복수형 접미사(`x_one`·`x_other`)를 뗀 키로 비교한다. 결정 반영: en·ja는 서버 한국어 안내 대신 code·오류 종류 문구(ko는 서버 안내 그대로), 빠진 번역 대체는 en(`fixed:"ko"`면 ko), 카카오 en·ja 표기 `Kakao`. `./locale`·`./i18n`·`./language-picker`·`./date-format`·`./i18n-check` 추가. app-core 화면·오류 문구(account-layout·account-ui·password-reset·login-layout·social-login·social-complete·account-action·native-session·google-auth)를 사전 키로 옮기고 en·ja 번역. 언어를 정하지 않은 앱은 늘 ko이고 1.9.1과 글자·HTML이 같다. 공개 이름·서브패스는 그대로(`providerLabel`·`LABEL`은 지금 언어 값을 읽는 같은 모양 객체, `providerRowValue` 반환 타입은 string). peer에 i18next ^26.2·react-i18next ^17 선택 추가(`./i18n`을 쓰는 앱만 설치) |
| 1.9.1 | 공용 모듈 lint 오류 정리(렌더 중 ref 접근 제거, 컴포넌트 아닌 함수는 별도 파일로 옮기고 같은 경로에서 다시 내보냄). 자체 `npm run lint` 추가. 공개 API·동작 변화 없음 |
| 1.9.0 | `./social-complete` 추가: 카카오·Apple·Google 완료 화면 틀과 실패 안내 규칙 공통화. 서버 안내(같은 이메일 계정 있음 등)를 고정 문구로 덮지 않는다. 7개 앱 완료 화면 적용 |
| 1.8.0 | `./social-availability` 추가: 로그인 화면 세 수단 상태를 공통 API 한 번으로 받아 같은 규칙으로 표시(`useSocialAvailability`). 7개 앱 로그인 화면이 앱별 카카오·Apple·Google 확인 요청 대신 이것을 쓴다. `useGoogleAvailability`는 옛 앱 호환용으로 남김 |
| 1.7.2 | `google-auth`에 `useGoogleAvailability(auth, serviceCode, {enabled})` 추가: 마지막 확인 결과를 기기 저장소에 서비스별로 기억해 첫 그림부터 Google 자리를 그리고, 확인 중에는 누르지 못하게, 꺼짐·오류면 자리를 없앤다. 7개 앱 로그인 화면 적용 |
| 1.7.1 | `AccountLayout` 옵션 추가: `localLabel`(아이디/비밀번호 표시), `methodsText`(프로필 둘째 줄), `linkDescription`(연결 안내), `nickname.noun`(닉네임·이름). 7개 앱 적용 |
| 1.7.0 | 내 계정 공통 틀(`./account-layout`: `AccountLayout`·`AccountHeaderButton`), 설정 목록 행(`./settings-list`), 공통 API 비밀번호 재설정(`./password-reset`). 달 리듬·오늘DoIt 적용 |
| 1.6.1 | Google 로그인 만료 안내 |
| 1.6.0 | 로그인 화면 공통 틀(`./login-layout`, 달 리듬·오늘DoIt 적용) |
| 1.5.0 | 간편 로그인 버튼 공통 부품(`./social-login`, 세로·가로 레이아웃) |
| 1.4.1 | Google 인증의 비동기 보안 저장소·계정 변경 차단·로그인 유지 선택, Android 네이티브 세션 opt-in |
| 1.4.0 | Google 인증 클라이언트·계정 UI opt-in, Google 재인증·마지막 수단 보호, 선택적 네이티브 복귀(실제 Google 왕복 미검증) |
| 1.3.0 | MUI 모서리 공통 토큰 |
| 1.2.0 | 계정 작업·계정 UI 공통화 |
| 1.1.0 | 가짜 설치형 앱에 platform(ios·android) 선택, 앱 세션 단위 테스트(달 리듬에서 옮김) |
| 1.0.0 | 처음 묶음(오늘DoIt 기준) |

## MUI 모서리 표준(`./mui-shape`)

배포 앱 오늘DoIt 실측값을 표준으로 한다. 카드·대화상자 16px, 카드 안 칸·Alert 12px, 버튼·입력칸 10px이다.

```ts
import { radius, radiusComponents, standardShape } from "@smartinfolab/app-core/mui-shape";

createTheme({ shape: standardShape, components: { ...radiusComponents, /* 앱별 부품 */ } });

<Box sx={{ borderRadius: radius.item }} />   // sx에서는 숫자 대신 토큰만 쓴다
```

- sx의 숫자 둥글기(`borderRadius: 2`)는 `theme.shape` 배수라 앱마다 크기가 달라진다. 쓰지 않는다.
- styleOverrides의 숫자는 그대로 px다. 배수로 착각해 3.2를 넣으면 거의 각진 모서리가 된다.

## Google 인증 선택 연결(1.4.0)

- 기존 앱의 패키지 버전·화면을 자동 변경하지 않는다. 아래 연결을 한 앱에만 Google 기능을 추가한다.
- 앱 API 모듈에서 `createGoogleAuth<LoginResponse>({api, serviceCode, storageKey, client, open})`를 만든다. `api`는 기존 axios 인스턴스, `open`은 웹·시스템 브라우저 분기를 적용한 공통 앱 복귀 함수다.
- 로그인 화면은 기존 MUI 버튼에서 Query로 `available()`을 조회하고 Mutation으로 `start()`를 호출한다. Google 설정이 준비되지 않았으면 버튼을 활성화하지 않는다.
- 계정 UI는 기존 `useLoginMethods`의 `api.google`에 `{available, link, unlink, reauth}`를 전달한다. 넘기지 않으면 기존 카카오·Apple 행만 표시한다.
- `/auth/google/complete` 라우트에서 `complete(location.hash)`를 호출한다. login은 기존 인증 상태·기기 세션 교환으로, link는 계정 조회 갱신으로, reauth는 기존 accountActions.attachReauthProof 후 계정 화면 복귀로 처리한다.
- 네이티브 Google을 사용할 때만 `createNativeReturn`의 providers에 google을 추가하고 isPending에서 Google state를 확인한다. Android 복귀 처리가 필요한 앱만 android=true로 지정한다.
- Android 복귀 형식 지원은 Android 프로젝트·보안 저장소·로그인 세션·푸시·실기기 검증 완료를 뜻하지 않는다.
- 서버 계약과 운영 활성화 순서는 공통 API `docs/GOOGLE-AUTH.md`를 따른다. 실제 Google 인증은 Cloud 설정 후 검증한다.

- 1.4.1: Google `persistence`에 비동기 보안 저장소를 연결하고 `context`로 시작 계정을 확인한다. `start("LOGIN", undefined, undefined, rememberLogin)`의 선택값은 완료 결과에 반환한다. Android 세션은 `createNativeSession({android:true, ...})`로 명시적으로 켠다.

## 내 계정 공통 틀(1.7.0)

- 앱은 `src/auth/accountLayout.ts` 같은 얇은 파일에서 다시 내보내고, `useLoginMethods`(앱 저장 키·쿼리 키·API 함수)를 만든 뒤 `AccountLayout`에 넘긴다.
- 앱 고유 행(기록·알림·기록 지우기 등)은 `appSections`에 `SettingsGroup`으로 넣는다. 앱 라우터 Link는 앱 `SettingsList`에서 `linkComponent`로 묶는다.
- 비밀번호 재설정은 공통 `/api/auth/recovery/*`(서버 허용 서비스: ONEULDOIT·ONEULDOFAMILY·DALLHYTHM·ONEULDOEAT·MATHMATE·SPEED·WORKSPACE)를 부른다. 앱 전용 `/password-reset/*` API는 출시 앱 호환을 위해 서버에 남아 있다.
- 화면 색은 MUI 테마 primary를 따른다. 글자 크기는 rem, 모서리는 `radius` 토큰이다.

## 다국어(1.10.0)

- 기본은 ko다. `createAppI18n`을 부르지 않은 앱(지금의 7개 앱)은 1.10.0으로 올려도 코드 변경 없이 화면이 1.9.1과 같다(`tests/i18n-ko.test.mjs`가 1.9.1 문구와 글자 단위로 비교).
- 다국어를 켜는 앱만 `npm i i18next react-i18next`를 하고 아래처럼 쓴다. 아직 번역이 없으면 `fixed: "ko"`로 시작한다.

```ts
// src/i18n.ts (앱)
import { createAppI18n } from "@smartinfolab/app-core/i18n";
export const appI18n = createAppI18n({ storageKey: "dallhythm-language", appResources: { ko: { app: ko }, en: { app: en }, ja: { app: ja } } });
// main.tsx: <I18nextProvider i18n={appI18n.i18n}>…  화면: const { t } = useTranslation(); t("home.title"); t("common:save")
// 설정: const [choice, setChoice] = useLanguageChoice(appI18n); <LanguageSettingsRow value={choice} onChange={setChoice} />
// 날짜: formatDateRange(start, end)  → ko "26.10.12 ~ 10.18" / en "Oct 12 – 18, 2026" / ja "2026年10月12日～18日"
// 공휴일: koreanHoliday(ymd, (d) => HOLIDAYS[d])  → ko일 때만 이름, 아니면 undefined
// 사전 테스트: assert.deepEqual(checkTranslations(ko, { en, ja }).problems, [])
```

- 앱 사전 네임스페이스는 앱이 정한다(예: `app`). `common`(저장·취소·삭제·닫기·확인·다시 시도·불러오는 중·오류 문구)과 `appCore`(app-core 화면)는 app-core가 넣는다. 앱 번역이 빠진 키는 en 문구로, en에도 없으면 ko 문구로 보인다. `fixed:"ko"`로 초기화한 앱은 ko만 본다. ko 화면은 ko 사전이 기준이라 바뀌지 않는다.
- 오류 문구: 서버 안내(message·detail)는 한국어뿐이라 **ko 화면에서만** 그대로 보인다(기존 규칙 그대로).
  - ko: `commonErrorMessage(error)`는 서버 안내 → 없으면 오류 종류(오프라인·연결·시간 초과·400·401·403·404·409·429·5xx) 문구.
  - en·ja: 서버 안내 대신 서버 `code`를 app-core가 알면 그 문구(`common.errorCode.*`: PASSWORD_REQUIRED·REAUTH_REQUIRED·REAUTH_INVALID·REAUTH_PROVIDER_MISMATCH·NOT_LINKED·LAST_LOGIN_METHOD·SESSION_EXPIRED·APPLE_EMAIL_UNAVAILABLE·APPLE_FLOW_MISSING_OR_EXPIRED·APPLE_LINK_REAUTH_REQUIRED), 모르는 code·code 없음은 오류 종류 문구.
  - 같은 규칙을 `accountErrorMessage`·`socialCompleteMessage`·`recoveryErrorMessage`(재설정 성공 안내 `recoveryServerText` 포함)도 따른다. 이 함수들은 en·ja에서 화면 고유 실패 문구(fallback)가 있으면 연결·시간 초과·요청 과다·서버 오류가 아닐 때 그 문구를 쓴다(`localizedServerError`).
  - `{ server: false }`는 언어와 상관없이 늘 종류 문구.
  - 새 서버 code 문구는 `src/locales/*`의 `common.errorCode`에 세 언어로 함께 더한다.
- 수단 이름: 카카오는 en·ja 모두 `Kakao`(カカオ 아님), Apple·Google은 그대로.
- 사전에 키를 더할 때는 `src/locales/ko.ts`·`en.ts`·`ja.ts`에 함께 넣는다. 영어는 간결한 앱 UI 영어, 일본어는 です・ます 기반으로 쓴다. 끼워 넣는 값은 `{{이름}}`.
- 패키지 테스트는 i18next를 `devDependencies`로 이 폴더 node_modules에 설치해 돌린다(`npm install --legacy-peer-deps`).
