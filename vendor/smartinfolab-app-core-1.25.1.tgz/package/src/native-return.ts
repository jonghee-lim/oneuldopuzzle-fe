/**
 * iOS 앱의 카카오·애플 로그인 복귀. 인앱 브라우저로 로그인 주소를 열고, 서버가
 * {scheme}://auth/{kakao|apple}/complete#state=ios.… 로 돌려보내면 앱 안의 완료 화면(/auth/{provider}/complete)으로 옮긴다.
 * 주소에는 토큰을 담지 않고 state만 오며, 이 앱이 시작한 state(앱의 대기 정보)와 같을 때만 받는다.
 */
import { App } from "@capacitor/app";
import { Browser } from "@capacitor/browser";
import { isIosApp, isNativeApp } from "./runtime.ts";

export type NativeProvider = "kakao" | "apple" | "google";
export type NativeReturn = { provider: NativeProvider; state: string; error: string | null };

export type NativeReturnConfig = {
  /** 앱 URL 스킴(콜론 없이). 예: com.smartinfol.oneuldoit */
  scheme: string;
  /** 기존 앱은 기본 두 제공자만 처리한다. */
  providers?: readonly NativeProvider[];
  android?: boolean;
  /** 이 앱이 시작해 기다리는 로그인인지(앱의 sessionStorage 대기 정보와 비교). */
  isPending: (provider: NativeProvider, state: string) => boolean | Promise<boolean>;
};

/** 앱 복귀 주소를 검사해 provider와 state를 돌려준다. 다른 스킴·경로·추가 값이 있으면 null. */
export function parseNativeReturn(raw: string, scheme: string, providers: readonly NativeProvider[] = ["kakao", "apple"], android = false): NativeReturn | null {
  try {
    const url = new URL(raw);
    const provider = url.pathname === "/kakao/complete" ? "kakao" : url.pathname === "/apple/complete" ? "apple" : url.pathname === "/google/complete" ? "google" : null;
    if (url.protocol !== scheme + ":" || url.hostname !== "auth" || !provider || !providers.includes(provider)
      || url.search || url.username || url.password || url.port) return null;
    const params = new URLSearchParams(url.hash.slice(1));
    if ([...params.keys()].some((key) => key !== "state" && key !== "error")
      || params.getAll("state").length !== 1 || params.getAll("error").length > 1) return null;
    const state = params.get("state");
    // Android 앱은 서버가 카카오·Apple·Google 모두 android. 꼬리표로 돌려보낸다(1.20.1, 전에는 Google만 받아 카카오·Apple 복귀가 막혔다).
    if (!state || !(android ? /^(?:ios|android)\.[A-Za-z0-9_-]{43}$/ : /^ios\.[A-Za-z0-9_-]{43}$/).test(state)) return null;
    const error = params.get("error");
    // 완료 화면이 아는 값으로만 넘긴다(애플: 취소·실패, 카카오: 실패).
    const safe = error === null ? null : provider !== "kakao" ? (error === "cancelled" ? "cancelled" : "invalid") : "authentication_failed";
    return { provider, state, error: safe };
  } catch {
    return null;
  }
}

/** 앱마다 한 번 만든다. initialize()는 앱 시작 때, open()은 로그인 버튼에서 부른다. */
export function createNativeReturn(config: NativeReturnConfig) {
  let initialization: Promise<void> | undefined;
  let handledState: string | undefined;

  async function receive(raw: string) {
    const parsed = parseNativeReturn(raw, config.scheme, config.providers, config.android);
    if (!parsed || parsed.state === handledState || !(await config.isPending(parsed.provider, parsed.state))) return;
    if (parsed.state === handledState) return;
    handledState = parsed.state;
    void Browser.close().catch(() => {});
    const params = new URLSearchParams({ state: parsed.state });
    if (parsed.error) params.set("error", parsed.error);
    // 번들된 앱 안에서만 이동한다.
    window.history.replaceState(null, "", `/auth/${parsed.provider}/complete#${params.toString()}`);
    window.dispatchEvent(new PopStateEvent("popstate"));
  }

  /** 앱 시작 시 한 번: 로그인 복귀 주소를 받을 준비. 웹은 아무것도 하지 않는다. */
  function initialize(): Promise<void> {
    if (!(config.android ? isNativeApp() : isIosApp())) return Promise.resolve();
    initialization ??= (async () => {
      await App.addListener("appUrlOpen", (event) => { void receive(event.url).catch(() => {}); });
      const launch = await App.getLaunchUrl();
      if (launch?.url) await receive(launch.url);
    })().catch((error) => { initialization = undefined; throw error; });
    return initialization;
  }

  /** 로그인 주소 열기: 앱은 인앱 브라우저, 웹은 현재 창 이동. */
  async function open(url: string) {
    if (!(config.android ? isNativeApp() : isIosApp())) { window.location.assign(url); return; }
    await initialize();
    handledState = undefined;
    await Browser.open({ url });
  }

  return { parse: (raw: string) => parseNativeReturn(raw, config.scheme, config.providers, config.android), initialize, open };
}
