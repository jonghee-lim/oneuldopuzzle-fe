/*
 * 앱 다국어 초기화(1.10.0, i18next + react-i18next). 이 경로를 가져오는 앱만 두 패키지를 설치한다(선택 peer).
 *
 *   export const appI18n = createAppI18n({ storageKey: "dallhythm-language", appResources: { ko: { app: koApp }, en: { app: enApp }, ja: { app: jaApp } } });
 *   <I18nextProvider i18n={appI18n.i18n}> … useTranslation("app") …
 *
 * 언어: fixed > 저장된 선택 > 기기 언어 > fallback(en). 아직 번역이 없는 앱은 fixed:"ko"로 고정한다.
 * 빠진 번역 대체: en → ko(fixed:"ko"면 ko).
 * 언어가 바뀌면 <html lang>, 저장값, app-core 화면 문구(setCoreLanguage)를 함께 바꾼다.
 */
import i18next, { type i18n as I18n, type Resource } from "i18next";
import { initReactI18next } from "react-i18next";
import { useSyncExternalStore } from "react";
import { coreResources, deviceLanguages, isLanguage, LANGUAGES, resolveLanguage, setCoreLanguage, type Language, type LanguageChoice } from "./locale.ts";

export * from "./locale.ts";

type Namespaces = Record<string, object>;

export type AppI18nOptions = {
  /** 언어별 앱 사전. 네임스페이스 이름을 키로 둔다(예: { ko: { app: {...} } }). common·appCore는 app-core가 넣는다. */
  appResources?: Partial<Record<Language, Namespaces>>;
  /** 고른 언어를 기억할 localStorage 키(앱마다 다르게, 예: "dallhythm-language"). */
  storageKey: string;
  /** 앱이 지원하는 언어(기본 ko·en·ja). */
  supported?: readonly Language[];
  /** 기기 언어를 지원하지 않을 때(기본 en). */
  fallback?: Language;
  /** 이 언어로 고정(번역 전 앱은 "ko"). 저장값·기기 언어를 보지 않는다. */
  fixed?: Language;
  /** useTranslation()의 기본 네임스페이스(기본: 앱 사전의 첫 네임스페이스, 없으면 common). */
  defaultNS?: string;
  /** 테스트용: 저장소·기기 언어·문서 바꾸기 */
  storage?: () => Pick<Storage, "getItem" | "setItem" | "removeItem">;
  device?: () => readonly string[];
  document?: () => { documentElement: { lang: string } } | undefined;
};

export function createAppI18n(options: AppI18nOptions) {
  const supported = options.supported?.length ? options.supported : LANGUAGES;
  const storage = options.storage ?? (() => localStorage);
  const device = options.device ?? deviceLanguages;
  const doc = options.document ?? (() => (typeof document === "undefined" ? undefined : document));
  const read = (): string | null => { try { return storage().getItem(options.storageKey); } catch { return null; } };
  const pick = () => resolveLanguage({ stored: read(), device: device(), supported, fallback: options.fallback, fixed: options.fixed });

  const resources: Resource = {};
  for (const lang of LANGUAGES) resources[lang] = { ...coreResources[lang], ...(options.appResources?.[lang] ?? {}) } as Resource[string];
  const firstAppNs = Object.keys(options.appResources?.ko ?? options.appResources?.[supported[0]] ?? {})[0];

  const listeners = new Set<() => void>();
  const notify = () => { for (const l of [...listeners]) l(); };
  const i18n: I18n = i18next.createInstance();
  const apply = (lang: string) => {
    if (!isLanguage(lang)) return;
    setCoreLanguage(lang);
    const d = doc();
    if (d) d.documentElement.lang = lang;
  };
  i18n.on("languageChanged", apply);
  void i18n.use(initReactI18next).init({
    resources,
    lng: pick(),
    // 앱 번역이 빠진 키는 en 문구로, en에도 없으면 ko 문구로 보인다(키 이름이 화면에 나오지 않게).
    // ko로 고정한 앱(fixed:"ko")은 ko만 본다. ko 화면은 ko 사전이 기준이라 대체가 일어나지 않는다.
    fallbackLng: options.fixed === "ko" ? ["ko"] : ["en", "ko"],
    supportedLngs: [...LANGUAGES],
    ns: Object.keys(resources.ko ?? {}),
    defaultNS: options.defaultNS ?? firstAppNs ?? "common",
    interpolation: { escapeValue: false },
    returnNull: false,
    initAsync: false,
  });
  apply(i18n.language);

  return {
    i18n,
    /** 지금 화면 언어 */
    language: (): Language => (isLanguage(i18n.language) ? i18n.language : "ko"),
    /** 사용자가 고른 값(저장값 없으면 "system") */
    choice: (): LanguageChoice => {
      const v = read();
      return isLanguage(v) && supported.includes(v) ? v : "system";
    },
    /** 언어 선택: "system"이면 저장값을 지우고 기기 언어를 따른다. */
    async setChoice(choice: LanguageChoice) {
      try {
        if (choice === "system") storage().removeItem(options.storageKey);
        else storage().setItem(options.storageKey, choice);
      } catch { /* 저장소를 못 쓰면 이번 실행에만 적용 */ }
      const next = choice === "system" ? pick() : options.fixed ?? choice;
      await i18n.changeLanguage(next);
      notify();
    },
    /** 선택 값이 바뀔 때 알림(useLanguageChoice가 쓴다). */
    subscribe(listener: () => void) { listeners.add(listener); return () => { listeners.delete(listener); }; },
    supported,
  };
}

export type AppI18n = ReturnType<typeof createAppI18n>;

/** 언어 선택 화면용: 지금 선택 값과 바꾸는 함수. 고르면 다시 그린다. */
export function useLanguageChoice(app: AppI18n): [LanguageChoice, (choice: LanguageChoice) => Promise<void>] {
  const choice = useSyncExternalStore(app.subscribe, app.choice, app.choice);
  return [choice, app.setChoice];
}
