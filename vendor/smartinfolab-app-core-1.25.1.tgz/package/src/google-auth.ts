import type { AxiosInstance } from "axios";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { ReauthProof } from "./account-action.ts";
import { coreT } from "./locale.ts";

export type GooglePurpose = "LOGIN" | "LINK" | "REAUTH";
type Pending = { state: string; verifier: string; purpose: GooglePurpose; at: number; context?: string; rememberLogin?: boolean };
export type GoogleCompletion<T> = { kind: "login"; response: T; rememberLogin: boolean } | { kind: "link" } | { kind: "reauth"; proof: ReauthProof };
type Options = {
  /** 앱의 기존 axios 인스턴스. 토큰·세션 처리를 여기서 새로 만들지 않는다. */
  api: Pick<AxiosInstance, "get" | "post">;
  serviceCode: string;
  storageKey: string;
  client?: () => "ios" | "android" | undefined;
  open: (url: string) => Promise<void> | void;
  storage?: () => Pick<Storage, "getItem" | "setItem" | "removeItem">;
  persistence?: { getItem: (key: string) => Promise<string | null>; setItem: (key: string, value: string) => Promise<void>; removeItem: (key: string) => Promise<void> };
  context?: () => string;
};
const TTL = 10 * 60 * 1000;
const bytes64 = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

/** Google 시작·완료·계정 연결의 공통 클라이언트. 화면은 앱의 MUI/Query 구성에서 호출한다. */
export function createGoogleAuth<TLogin>(options: Options) {
  const storage = () => options.persistence ?? (options.storage ?? (() => sessionStorage))();
  const base = "/api/auth/google";
  let completing: Promise<GoogleCompletion<TLogin>> | undefined;
  let completingFragment: string | undefined;
  const clear = async () => storage().removeItem(options.storageKey);
  async function pending(): Promise<Pending | null> {
    try {
      const p = JSON.parse(await storage().getItem(options.storageKey) || "null") as Pending | null;
      if (!p || p.context !== options.context?.() || !["LOGIN", "LINK", "REAUTH"].includes(p.purpose)
        || !/^(?:(?:ios|android)\.)?[A-Za-z0-9_-]{43}$/.test(p.state)
        || !/^[A-Za-z0-9_-]{43}$/.test(p.verifier) || !Number.isFinite(p.at)
        || p.at > Date.now() || Date.now() - p.at > TTL) return null;
      return p;
    } catch { return null; }
  }
  async function start(purpose: GooglePurpose = "LOGIN", password?: string, proof?: ReauthProof, rememberLogin = false) {
    const context = options.context?.();
    const verifier = bytes64(crypto.getRandomValues(new Uint8Array(32)));
    const challenge = bytes64(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier))));
    const client = options.client?.();
    const { data } = await options.api.post<{ url: string; state: string }>(base + "/start", {
      serviceCode: options.serviceCode, challenge, purpose, client, password, proof,
    });
    const url = new URL(data.url);
    const prefix = client ? client + "." : "";
    if (url.origin !== "https://accounts.google.com" || url.pathname !== "/o/oauth2/v2/auth"
      || !new RegExp("^" + prefix.replace(".", "\\.") + "[A-Za-z0-9_-]{43}$").test(data.state)
      || url.searchParams.get("state") !== data.state) throw new Error(coreT("appCore.google.badResponse"));
    completing = undefined; completingFragment = undefined;
    if (context !== options.context?.()) throw new Error(coreT("appCore.google.accountChanged"));
    await storage().setItem(options.storageKey, JSON.stringify({ state: data.state, verifier, purpose, at: Date.now(), context, rememberLogin }));
    try { await options.open(data.url); } catch (error) { await clear(); throw error; }
  }
  async function finish(fragment: string): Promise<GoogleCompletion<TLogin>> {
    const params = new URLSearchParams(fragment.replace(/^#/, ""));
    // 서버 콜백이 만료를 알려 주면 이 기기의 대기 정보와 상관없이 만료 안내만 한다(성공 처리는 하지 않는다).
    if (params.getAll("error").length === 1 && params.get("error") === "expired") {
      await clear(); throw new Error(coreT("appCore.social.expired", { provider: "Google" }));
    }
    const p = await pending();
    if (!p || params.getAll("state").length !== 1 || params.get("state") !== p.state
      || params.getAll("error").length > 1 || [...params.keys()].some(k => k !== "state" && k !== "error"))
      throw new Error(coreT("appCore.google.restartHere"));
    if (params.has("error")) { await clear(); throw new Error(params.get("error") === "cancelled" ? coreT("appCore.social.cancelled", { provider: "Google" }) : coreT("appCore.google.restart")); }
    const body = { serviceCode: options.serviceCode, state: p.state, verifier: p.verifier };
    if (p.purpose === "REAUTH") {
      await clear();
      return { kind: "reauth", proof: { provider: "GOOGLE", state: p.state, verifier: p.verifier } };
    }
    if (p.purpose === "LINK") {
      await options.api.post(base + "/link/finish", body); await clear(); return { kind: "link" };
    }
    const { data } = await options.api.post<TLogin>(base + "/finish", body);
    await clear(); return { kind: "login", response: data, rememberLogin: p.rememberLogin === true };
  }
  return {
    available: async () => (await options.api.get<{ enabled: boolean }>(base + "/config", { params: { serviceCode: options.serviceCode } })).data.enabled === true,
    start,
    clear,
    isPending: async (state: string) => (await pending())?.state === state,
    // 진행 중인 중복 요청만 합친다. 완료 토큰을 캐시해 로그아웃 뒤 재사용하지 않는다.
    complete: (fragment: string) => {
      if (completing && fragment !== completingFragment) return Promise.reject(new Error(coreT("appCore.google.responseChanged")));
      if (completing) return completing;
      completingFragment = fragment;
      const result = finish(fragment).finally(() => {
        if (completing === result) { completing = undefined; completingFragment = undefined; }
      });
      completing = result;
      return result;
    },
    link: (password: string, proof?: ReauthProof) => start("LINK", password, proof),
    reauth: () => start("REAUTH"),
    unlink: async (input: { password?: string; proof?: ReauthProof }) => {
      await options.api.post(base + "/disconnect", { serviceCode: options.serviceCode, ...input });
    },
  };
}

/*
 * 로그인 화면 Google 버튼 표시 상태(1.7.2).
 * 서버 설정 확인(available)이 끝난 뒤에야 버튼이 생기면 가로형 간편 로그인 배치가 움직인다.
 * - 마지막 확인 결과를 기기 저장소(localStorage, 설치형 앱은 웹뷰 저장소)에 서비스별로 기억해 첫 그림에 쓴다.
 * - 기억된 값이 없으면 확인 중에도 자리를 그리고 누르지 못하게만 한다(안내 문구 없음).
 * - 서버가 꺼짐(false)이나 오류로 답하면 자리를 없앤다. 서버 확인은 늘 백그라운드로 다시 한다.
 */
export type GoogleAvailability = {
  /** Google 자리를 그릴지. */
  visible: boolean;
  /** 눌러도 되는지(서버가 켜짐으로 답했거나 지난번 켜짐을 기억). */
  ready: boolean;
};
const rememberKey = (serviceCode: string) => "smartinfolab.google-available." + serviceCode;
export function readGoogleAvailability(serviceCode: string, storage?: Pick<Storage, "getItem">): boolean | undefined {
  try {
    const v = (storage ?? localStorage).getItem(rememberKey(serviceCode));
    return v === "true" ? true : v === "false" ? false : undefined;
  } catch { return undefined; }
}
export function rememberGoogleAvailability(serviceCode: string, value: boolean, storage?: Pick<Storage, "setItem">) {
  try { (storage ?? localStorage).setItem(rememberKey(serviceCode), String(value)); } catch { /* 저장소를 못 쓰면 기억만 건너뛴다 */ }
}
/** 기억된 값과 서버 확인 상태로 버튼 표시를 정한다. */
export function googleAvailabilityState(remembered: boolean | undefined, query: { status: "pending" | "success" | "error"; data?: boolean }): GoogleAvailability {
  if (query.status === "success") return { visible: query.data === true, ready: query.data === true };
  if (query.status === "error") return { visible: false, ready: false };
  if (remembered === undefined) return { visible: true, ready: false };
  return { visible: remembered, ready: remembered };
}
/**
 * 로그인 화면용 Google 표시 훅. enabled=false(비회원 첫 화면 등)면 서버에 묻지 않고 기억된 값만 쓴다.
 *   const google = useGoogleAvailability(googleAuth, "DALLHYTHM");
 *   ...(google.visible ? [{ provider: "google", onClick, disabled: busy || !google.ready }] : [])
 */
export function useGoogleAvailability(auth: { available: () => Promise<boolean> }, serviceCode: string, options: { enabled?: boolean } = {}): GoogleAvailability {
  const [remembered] = useState(() => readGoogleAvailability(serviceCode));
  const query = useQuery({
    queryKey: ["app-core", "google-available", serviceCode],
    queryFn: async () => { const v = await auth.available(); rememberGoogleAvailability(serviceCode, v); return v; },
    retry: false, staleTime: 60000, enabled: options.enabled ?? true,
  });
  return googleAvailabilityState(remembered, query);
}
