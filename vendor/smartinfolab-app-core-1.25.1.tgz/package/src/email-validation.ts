/** 이메일 입력 확인(계정 이메일 변경·비밀번호 재설정 공통). 공개 경로는 `./account-ui`에서 다시 내보낸다. */
import { coreT } from "./locale.ts";

export function emailValidation(value: string): string {
  const email = value.trim();
  if (!email) return coreT("appCore.email.required");
  if (email.length > 255 || !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(email)) return coreT("appCore.email.invalid");
  return "";
}
