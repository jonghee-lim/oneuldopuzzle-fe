import type { AxiosInstance } from "axios";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";

/*
 * 로그인 화면 간편 로그인 표시 상태 표준(1.8.0).
 * 카카오·Apple·Google 상태를 공통 API 한 번(/api/auth/social/config)으로 받아 세 버튼을 같은 규칙으로 그린다.
 * - 마지막 응답을 기기 저장소에 서비스별로 기억해 첫 그림에 쓴다(설치형 앱은 웹뷰 저장소).
 * - 기억이 없으면 확인 중에도 세 자리를 그리고 누르지 못하게만 한다(안내 문구 없음, 화면이 움직이지 않게).
 * - 응답이 오면 세 버튼이 함께 바뀐다. 꺼진 수단은 자리를 없앤다.
 * - 오류면 기억된 값을 그대로 쓰고(없으면 자리 없음) error로 알린다. 누른 뒤 실패는 각 시작 API가 안내한다.
 */
export type SocialProvider = "kakao" | "apple" | "google";
export type ProviderAvailability = {
  /** 자리를 그릴지. */
  visible: boolean;
  /** 눌러도 되는지. */
  ready: boolean;
};
export type SocialAvailability = Record<SocialProvider, ProviderAvailability> & {
  /** 상태 확인 실패(기억된 값으로 그리는 중일 수 있다). */
  error: boolean;
  retry: () => void;
};
type Config = Record<SocialProvider, boolean>;
const PROVIDERS: SocialProvider[] = ["kakao", "apple", "google"];
const rememberKey = (serviceCode: string) => "smartinfolab.social-available." + serviceCode;

export function readSocialAvailability(serviceCode: string, storage?: Pick<Storage, "getItem">): Config | undefined {
  try {
    const v = JSON.parse((storage ?? localStorage).getItem(rememberKey(serviceCode)) || "null");
    return v && PROVIDERS.every(p => typeof v[p] === "boolean") ? { kakao: v.kakao, apple: v.apple, google: v.google } : undefined;
  } catch { return undefined; }
}
export function rememberSocialAvailability(serviceCode: string, value: Config, storage?: Pick<Storage, "setItem">) {
  try { (storage ?? localStorage).setItem(rememberKey(serviceCode), JSON.stringify(value)); } catch { /* 저장소를 못 쓰면 기억만 건너뛴다 */ }
}
/** 기억된 값과 서버 확인 상태로 세 버튼 표시를 정한다(세 수단 같은 규칙). */
export function socialAvailabilityState(remembered: Config | undefined, query: { status: "pending" | "success" | "error"; data?: Config }): Record<SocialProvider, ProviderAvailability> {
  const known = query.status === "success" ? query.data : remembered;
  const one = (p: SocialProvider): ProviderAvailability => {
    if (known) return { visible: known[p], ready: known[p] };
    return query.status === "pending" ? { visible: true, ready: false } : { visible: false, ready: false };
  };
  return { kakao: one("kakao"), apple: one("apple"), google: one("google") };
}
export async function fetchSocialAvailability(api: Pick<AxiosInstance, "get">, serviceCode: string): Promise<Config> {
  const { data } = await api.get<Partial<Config>>("/api/auth/social/config", { params: { serviceCode } });
  return { kakao: data.kakao === true, apple: data.apple === true, google: data.google === true };
}
/**
 * 로그인 화면용 훅. enabled=false(비회원 첫 화면 등)면 서버에 묻지 않고 기억된 값만 쓴다.
 *   const social = useSocialAvailability(apiClient, "DALLHYTHM");
 *   ...(social.kakao.visible ? [{ provider: "kakao", onClick, disabled: busy || !social.kakao.ready }] : [])
 */
export function useSocialAvailability(api: Pick<AxiosInstance, "get">, serviceCode: string, options: { enabled?: boolean } = {}): SocialAvailability {
  const [remembered] = useState(() => readSocialAvailability(serviceCode));
  const query = useQuery({
    queryKey: ["app-core", "social-available", serviceCode],
    queryFn: async () => { const v = await fetchSocialAvailability(api, serviceCode); rememberSocialAvailability(serviceCode, v); return v; },
    retry: false, staleTime: 60000, enabled: options.enabled ?? true,
  });
  return { ...socialAvailabilityState(remembered, query), error: query.isError, retry: () => { void query.refetch(); } };
}
