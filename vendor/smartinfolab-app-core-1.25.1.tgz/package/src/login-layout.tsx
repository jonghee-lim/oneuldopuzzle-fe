import type { ReactNode } from "react";
import { Box, Card, CardContent, Divider, Stack, Typography } from "@mui/material";
import { loginSections, type LoginSection } from "./login-sections.ts";
import { useCoreText } from "./use-core-text.ts";

export { loginSections, type LoginSection };

/**
 * 로그인 화면 공통 틀(2026-10-14). 간격·구분선·카드·정렬만 맡고, 동작(입력·제출·검증·간편 로그인)은 앱이 슬롯으로 넘긴다.
 *
 * 순서(위→아래, 고정):
 *  1. 로고 + 제목 + 한 줄 안내(앱 정책 문구)
 *  2. guestAction: 계정 없이 바로 사용(설치형 앱 + guestUse일 때만 넘긴다)
 *  3. retention: 이 기기에서 로그인 유지(policy.loginRetentionChoice일 때만)
 *  4. notices: 오류·세션 만료·로그아웃 같은 안내(있을 때만)
 *  5. social: 간편 로그인 버튼(SocialLoginButtons). 위에 구분선을 두지 않는다.
 *  6. "이메일로 로그인" 구분선
 *  7. emailForm: 이메일·비밀번호·로그인 버튼(폼 submit은 앱이 그대로 가진다)
 *  8. links: 비밀번호 찾기 · 회원가입 한 줄
 *  9. footer: 카드 밖(개인정보 처리방침)
 *
 * collapsed를 넘기면(앱 비회원 화면에서 ‘기존 회원 로그인’을 누르기 전) 3·5~8 대신 그것만 보인다.
 */
export type LoginLayoutProps = {
  logo: ReactNode;
  title: ReactNode;
  lead?: ReactNode;
  guestAction?: ReactNode;
  retention?: ReactNode;
  notices?: ReactNode;
  social?: ReactNode;
  emailForm?: ReactNode;
  links?: ReactNode;
  footer?: ReactNode;
  collapsed?: ReactNode;
  /** 구분선 문구. 기본 "이메일로 로그인". */
  emailDivider?: ReactNode;
  /** 본문 최대 너비(px). 기본 440. */
  maxWidth?: number;
};

export function LoginLayout(props: LoginLayoutProps) {
  const t = useCoreText();
  const { logo, title, lead, emailDivider = t("appCore.login.emailDivider"), maxWidth = 440 } = props;
  const sections = loginSections(props);
  const body = sections.filter(s => s !== "header" && s !== "footer");
  const slot = (s: LoginSection): ReactNode => {
    if (s === "emailDivider")
      return <Divider><Typography variant="body2" color="text.secondary">{emailDivider}</Typography></Divider>;
    return props[s as keyof LoginLayoutProps] as ReactNode;
  };
  return (
    <Box sx={{ width: "100%", maxWidth, mx: "auto" }}>
      <Stack sx={{ gap: 2.5 }}>
        <Stack sx={{ alignItems: "center", gap: 1, textAlign: "center" }}>
          {logo}
          <Typography component="h1" variant="h5" sx={{ fontWeight: 700, wordBreak: "keep-all" }}>{title}</Typography>
          {lead && <Typography variant="body2" color="text.secondary" sx={{ wordBreak: "keep-all" }}>{lead}</Typography>}
        </Stack>
        {body.length > 0 && (
          <Card variant="outlined">
            <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
              <Stack sx={{ gap: 2 }}>
                {body.map(s => <Box key={s} data-login-section={s}>{slot(s)}</Box>)}
              </Stack>
            </CardContent>
          </Card>
        )}
        {sections.includes("footer") && <Box sx={{ textAlign: "center" }}>{props.footer}</Box>}
      </Stack>
    </Box>
  );
}
