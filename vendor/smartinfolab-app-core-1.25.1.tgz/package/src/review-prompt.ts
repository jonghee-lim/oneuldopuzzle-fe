import { isIosApp, isNativeApp } from "./runtime.ts";

/**
 * 앱 안 별점 요청(평점 유도) 공통 모듈(2026-10-24). iOS 앱은 App Store 별점 창, Android 앱은 Google Play 인앱 리뷰를
 * 같은 플러그인(@capacitor-community/in-app-review)으로 요청한다. 웹·웹앱은 아무것도 하지 않고 플러그인도 불러오지 않는다.
 *
 * - 앱은 createReviewPrompt 하나를 만들고 시작 때 start(), 성공 순간에 note("순간") 만 부른다.
 * - 규칙(앱마다 같음): 처음 실행 후 firstOpenDays 동안·마지막 요청 후 cooldownDays 동안은 묻지 않고,
 *   켜진 순간 가운데 하나라도 기준 횟수에 닿으면 묻는다. 물으면 모든 횟수를 0부터 다시 센다.
 * - 설정 원본은 워크스페이스 '평점 유도'(공통 API GET /api/app/review-prompt)이고, 앱에는 기본값만 둔다.
 *   서버를 못 읽으면 마지막으로 받은 값, 그것도 없으면 기본값으로 동작한다.
 * - 상태(첫 실행·마지막 요청 시각·횟수)는 이 기기 localStorage에만 숫자로 둔다. 앱마다 쓰던 예전 저장 모양도 그대로 읽는다.
 * 실제로 창을 띄울지는 Apple·Google이 정한다(횟수 제한).
 */

export type ReviewPlatform = "IOS" | "ANDROID";
export type ReviewMoment = { threshold: number; enabled: boolean };
export type ReviewConfig = {
  enabled: boolean;
  firstOpenDays: number;
  cooldownDays: number;
  moments: Record<string, ReviewMoment>;
};
export type ReviewState = { firstOpenAt: number; lastAskedAt: number | null; counts: Record<string, number> };

const DAY = 24 * 60 * 60 * 1000;

/** 공통 API 경로(인증 없음). 앱의 API 클라이언트로 부른다. */
export function reviewConfigPath(service: string, platform: ReviewPlatform): string {
  return `/api/app/review-prompt?service=${encodeURIComponent(service)}&platform=${platform}`;
}

const positive = (value: unknown, fallback: number) =>
  typeof value === "number" && Number.isFinite(value) && value >= 0 ? Math.floor(value) : fallback;

/** 서버 응답을 기본값 위에 얹는다. configured가 false이거나 모양이 이상하면 기본값을 그대로 쓴다. */
export function mergeReviewConfig(defaults: ReviewConfig, remote: unknown): ReviewConfig {
  if (!remote || typeof remote !== "object") return defaults;
  const r = remote as Partial<ReviewConfig> & { configured?: boolean };
  if (r.configured === false) return defaults;
  const moments: Record<string, ReviewMoment> = { ...defaults.moments };
  if (r.moments && typeof r.moments === "object") {
    for (const [key, value] of Object.entries(r.moments)) {
      if (!value || typeof value !== "object") continue;
      const base = defaults.moments[key] ?? { threshold: 0, enabled: false };
      const threshold = positive((value as ReviewMoment).threshold, base.threshold);
      moments[key] = { threshold, enabled: typeof (value as ReviewMoment).enabled === "boolean" ? (value as ReviewMoment).enabled : base.enabled };
    }
  }
  return {
    enabled: typeof r.enabled === "boolean" ? r.enabled : defaults.enabled,
    firstOpenDays: positive(r.firstOpenDays, defaults.firstOpenDays),
    cooldownDays: positive(r.cooldownDays, defaults.cooldownDays),
    moments,
  };
}

/**
 * 기기에 남은 상태를 읽는다. 앱마다 달랐던 예전 모양도 받는다.
 * - {firstOpenAt, lastAskedAt, counts}(오늘DoIt·오늘Do클래스)
 * - {firstRunAt, lastPromptAt, count}(달 리듬, count는 legacyCountKey 순간으로)
 * - {firstRunAt, lastPromptAt, meal, photo}(오늘DoEat, 숫자 칸은 같은 이름의 순간으로)
 */
export function normalizeReviewState(saved: unknown, now: number, legacyCountKey?: string): ReviewState {
  if (!saved || typeof saved !== "object") return { firstOpenAt: now, lastAskedAt: null, counts: {} };
  const s = saved as Record<string, unknown>;
  const firstOpenAt = typeof s.firstOpenAt === "number" ? s.firstOpenAt : typeof s.firstRunAt === "number" ? s.firstRunAt : now;
  const asked = typeof s.lastAskedAt === "number" ? s.lastAskedAt : typeof s.lastPromptAt === "number" ? s.lastPromptAt : null;
  const counts: Record<string, number> = {};
  if (s.counts && typeof s.counts === "object") {
    for (const [k, v] of Object.entries(s.counts as Record<string, unknown>)) if (typeof v === "number" && v >= 0) counts[k] = v;
  }
  for (const [k, v] of Object.entries(s)) {
    if (["firstOpenAt", "firstRunAt", "lastAskedAt", "lastPromptAt", "counts"].includes(k) || typeof v !== "number" || v < 0) continue;
    if (k === "count") { if (legacyCountKey) counts[legacyCountKey] = (counts[legacyCountKey] ?? 0) + v; continue; }
    counts[k] = (counts[k] ?? 0) + v;
  }
  return { firstOpenAt, lastAskedAt: asked, counts };
}

/** 순간 하나(amount번)를 반영하고, 지금 별점 창을 요청할지 돌려준다. 요청하면 모든 횟수를 0으로 하고 시각을 남긴다. */
export function noteReviewMoment(state: ReviewState, config: ReviewConfig, kind: string, amount: number, now: number): { state: ReviewState; ask: boolean } {
  const moment = config.moments[kind];
  if (!moment || !moment.enabled || amount <= 0) return { state, ask: false };
  const counts = { ...state.counts, [kind]: (state.counts[kind] ?? 0) + amount };
  const counted = { ...state, counts };
  const installed = now - state.firstOpenAt >= config.firstOpenDays * DAY;
  const cooled = state.lastAskedAt === null || now - state.lastAskedAt >= config.cooldownDays * DAY;
  const reached = Object.entries(config.moments).some(([k, m]) => m.enabled && m.threshold > 0 && (counts[k] ?? 0) >= m.threshold);
  if (config.enabled && installed && cooled && reached) return { state: { ...counted, counts: {}, lastAskedAt: now }, ask: true };
  return { state: counted, ask: false };
}

export type ReviewPromptOptions = {
  /** 서비스 코드(예: ONEULDOIT). */
  service: string;
  /** 기기 상태 저장 키(앱이 쓰던 키 그대로). 설정은 `${storageKey}.config`에 기억한다. */
  storageKey: string;
  /** 서버 설정이 없을 때 쓰는 기본값(지금까지 앱 코드에 있던 값). */
  defaults: ReviewConfig;
  /** 예전 저장 모양의 count 칸을 넣을 순간(달 리듬). */
  legacyCountKey?: string;
  /** 앱 정책 값(iOS·Android 앱 true, 웹 false). false면 아무것도 하지 않는다. */
  enabled: boolean;
  /** 서버 설정 읽기(앱 API 클라이언트로 reviewConfigPath를 GET). 없으면 기본값만 쓴다. */
  fetchConfig?: (path: string) => Promise<unknown>;
  /** 테스트용 바꿔 끼우기. */
  requestReview?: () => Promise<void>;
  now?: () => number;
  storage?: Pick<Storage, "getItem" | "setItem"> | null;
  delayMs?: number;
  platform?: () => ReviewPlatform | null;
};

export type ReviewPrompt = {
  /** 앱 시작 때: 첫 실행 시각을 남기고 서버 설정을 받아 둔다. */
  start: () => Promise<void>;
  /** 성공 순간(저장·완료 등) 직후에 부른다. 조건이 맞으면 잠시 뒤 별점 창을 요청한다. */
  note: (kind: string, amount?: number) => void;
};

function nativePlatform(): ReviewPlatform | null {
  if (!isNativeApp()) return null;
  return isIosApp() ? "IOS" : "ANDROID";
}

async function storeReview(): Promise<void> {
  const { InAppReview } = await import("@capacitor-community/in-app-review");
  await InAppReview.requestReview();
}

export function createReviewPrompt(options: ReviewPromptOptions): ReviewPrompt {
  const now = options.now ?? Date.now;
  const platformOf = options.platform ?? nativePlatform;
  const storage = options.storage === undefined ? (() => { try { return localStorage; } catch { return null; } })() : options.storage;
  const configKey = `${options.storageKey}.config`;
  const active = () => options.enabled && platformOf() !== null;

  const readJson = (key: string) => { try { return JSON.parse(storage?.getItem(key) ?? "null"); } catch { return null; } };
  const write = (key: string, value: unknown) => { try { storage?.setItem(key, JSON.stringify(value)); } catch { /* 저장이 막히면 이번 실행에서만 센다 */ } };
  const load = () => normalizeReviewState(readJson(options.storageKey), now(), options.legacyCountKey);
  const config = () => mergeReviewConfig(options.defaults, readJson(configKey));

  return {
    async start() {
      if (!active()) return;
      write(options.storageKey, load());
      const platform = platformOf();
      if (!options.fetchConfig || !platform) return;
      try {
        const remote = await options.fetchConfig(reviewConfigPath(options.service, platform));
        if (remote && typeof remote === "object") write(configKey, remote);
      } catch { /* 오프라인·서버 오류는 마지막 값·기본값으로 */ }
    },
    note(kind, amount = 1) {
      if (!active()) return;
      const result = noteReviewMoment(load(), config(), kind, amount, now());
      write(options.storageKey, result.state);
      if (!result.ask) return;
      const request = options.requestReview ?? storeReview;
      setTimeout(() => { void request().catch(() => {}); }, options.delayMs ?? 1000);
    },
  };
}
