import { useState } from "react";
import { Alert, Button, Checkbox, FormControlLabel, Stack, TextField, Typography } from "@mui/material";
import { useMutation } from "@tanstack/react-query";
import { emailValidation } from "./email-validation.ts";
import { passwordChecks } from "./account-model.ts";
import { accountErrorMessage } from "./account-action.ts";
import { RESEND_INTERVAL_MS, codeDigits, isDuplicateEmailError, normalizeSignupEmail, passwordFieldError, resendBlocked } from "./signup-model.ts";
import { useCoreText } from "./use-core-text.ts";

/**
 * 회원가입 화면 부품(로그인 공통화 P4, 1.24.0). 가입 화면 전체 틀은 앱마다 단계가 달라 그대로 두고, 세 부품만 공통으로 쓴다:
 * 이메일 인증번호 단계(EmailVerificationField), 비밀번호·확인 칸과 규칙 ✓ 목록(PasswordFields), 로그인 유지 선택(RememberLoginChoice).
 * 서버: /api/auth/check-email(선택)·/api/auth/email-verification/start·confirm(스파클은 /api/speed/auth/...). 앱은 자기 axios로 감싼 함수 세 개만 넘긴다.
 * 순수 계산(normalizeSignupEmail·signupPasswordError 등)은 ./signup-model, 비밀번호 규칙은 ./account-model, 이메일 형식은 ./email-validation에서 가져온다(이 파일은 컴포넌트만 내보낸다).
 */
export type EmailVerificationApi = {
  /** 가입 가능(중복 아님)이면 true. 없으면 start의 409로 중복을 판단한다. */
  checkEmail?: (email: string) => Promise<boolean>;
  start: (email: string) => Promise<void>;
  /** 인증번호 확인 → 가입에 보낼 emailVerificationToken. */
  confirm: (email: string, code: string) => Promise<string>;
};

export function EmailVerificationField(props: {
  api: EmailVerificationApi;
  email: string;
  onEmailChange: (value: string) => void;
  /** 확인이 끝난 토큰. 이메일을 바꾸면 ""로 되돌려 준다. */
  token: string;
  onTokenChange: (token: string) => void;
  disabled?: boolean;
  /** 다른 방법(카카오 동의)으로 이미 인증된 이메일이면 인증번호 단계 대신 이 안내만 보인다. */
  verifiedNote?: string;
  /** 이미 가입된 이메일이면(중복 확인 또는 start 409) 부른다. 앱은 '기존 계정으로 로그인' 안내를 보일 수 있다. */
  onDuplicate?: () => void;
  errorMessage?: (error: unknown) => string;
  label?: string;
  autoFocus?: boolean;
}) {
  const { api, email, onEmailChange, token, onTokenChange, disabled, verifiedNote, onDuplicate, errorMessage = (e) => accountErrorMessage(e), label, autoFocus } = props;
  const t = useCoreText();
  const [sent, setSent] = useState(false), [code, setCode] = useState(""), [retryAt, setRetryAt] = useState(0);
  const [message, setMessage] = useState(""), [error, setError] = useState("");
  const invalid = email ? emailValidation(email) : "";
  const normalized = normalizeSignupEmail(email);
  const send = useMutation({
    mutationFn: async () => {
      if (api.checkEmail && !(await api.checkEmail(normalized))) return "duplicate" as const;
      await api.start(normalized);
      return "sent" as const;
    },
    onSuccess: (result) => {
      if (result === "duplicate") { setError(t("appCore.signup.duplicate")); onDuplicate?.(); return; }
      setSent(true); setCode(""); setRetryAt(Date.now() + RESEND_INTERVAL_MS); setMessage(t("appCore.signup.codeSent"));
    },
    onError: (e) => {
      if (isDuplicateEmailError(e)) { setError(t("appCore.signup.duplicate")); onDuplicate?.(); return; }
      setError(errorMessage(e) || t("appCore.signup.sendFailed"));
    },
  });
  const confirm = useMutation({
    mutationFn: () => api.confirm(normalized, code),
    onSuccess: (value) => { onTokenChange(value); setMessage(t("appCore.signup.verified")); setError(""); },
    onError: (e) => setError(errorMessage(e) || t("appCore.signup.verifyFailed")),
  });
  const working = disabled || send.isPending || confirm.isPending;
  function change(value: string) {
    onEmailChange(value);
    if (sent || token) { setSent(false); setCode(""); onTokenChange(""); }
    setMessage(""); setError("");
  }
  function start() {
    const problem = emailValidation(email);
    if (problem) { setError(problem); return; }
    if (resendBlocked(retryAt)) { setError(t("appCore.reset.retryLater")); return; }
    setError(""); setMessage(""); send.mutate();
  }
  const verified = Boolean(token) || Boolean(verifiedNote);
  return (
    <Stack sx={{ gap: 1.5 }}>
      <Stack direction="row" spacing={1} sx={{ alignItems: "flex-start" }}>
        <TextField label={label ?? t("appCore.signup.email")} type="email" autoComplete="email" fullWidth required autoFocus={autoFocus} value={email} disabled={working || Boolean(token)}
          error={Boolean(invalid)} helperText={invalid || undefined} onChange={(e) => change(e.target.value)} slotProps={{ htmlInput: { maxLength: 255, autoCapitalize: "none" } }} />
        {!verified && (
          <Button type="button" variant="outlined" disabled={!email.trim() || Boolean(invalid) || working} onClick={start} sx={{ minWidth: 112, flexShrink: 0, mt: 1 }}>
            {send.isPending ? t("appCore.signup.sending") : sent ? t("appCore.signup.resend") : t("appCore.signup.sendCode")}
          </Button>
        )}
      </Stack>
      {sent && !verified && (
        <Stack direction="row" spacing={1}>
          <TextField label={t("appCore.signup.code")} fullWidth required value={code} disabled={working} autoComplete="one-time-code"
            onChange={(e) => setCode(codeDigits(e.target.value))} slotProps={{ htmlInput: { inputMode: "numeric", maxLength: 6 } }} />
          <Button type="button" variant="contained" disabled={code.length !== 6 || working} onClick={() => confirm.mutate()} sx={{ minWidth: 96, flexShrink: 0 }}>
            {confirm.isPending ? t("appCore.signup.checking") : t("appCore.signup.verify")}
          </Button>
        </Stack>
      )}
      {verifiedNote && !token && <Typography variant="caption" color="success.main">{verifiedNote}</Typography>}
      {message && <Typography variant="caption" color={token ? "success.main" : "text.secondary"} role="status">{message}</Typography>}
      {error && <Alert severity="error">{error}</Alert>}
    </Stack>
  );
}

/** 비밀번호·비밀번호 확인 칸. 규칙 ✓ 목록(8자 이상·영문·숫자·특수문자)은 내 계정의 이메일 로그인 설정과 같다. */
export function PasswordFields(props: {
  password: string;
  onPasswordChange: (value: string) => void;
  confirm: string;
  onConfirmChange: (value: string) => void;
  disabled?: boolean;
  labels?: { password?: string; confirm?: string };
  idPrefix?: string;
}) {
  const { password, onPasswordChange, confirm, onConfirmChange, disabled, labels, idPrefix = "signup" } = props;
  const t = useCoreText();
  const checks = passwordChecks(password);
  const rule = passwordFieldError(password);
  const mismatch = confirm.length > 0 && confirm !== password;
  const check = (ok: boolean, label: string) => (
    <Typography key={label} component="span" variant="caption" sx={{ color: ok ? "success.main" : "text.secondary", whiteSpace: "nowrap" }}>{ok ? "✓" : "○"} {label}</Typography>
  );
  return (
    <Stack sx={{ gap: 1.5 }}>
      <TextField id={`${idPrefix}-password`} label={labels?.password ?? t("appCore.signup.password")} type="password" autoComplete="new-password" fullWidth required value={password} disabled={disabled}
        error={Boolean(rule)} onChange={(e) => onPasswordChange(e.target.value)} slotProps={{ htmlInput: { maxLength: 100 } }} />
      <Stack direction="row" useFlexGap sx={{ flexWrap: "wrap", columnGap: 1.5, rowGap: 0.5, mt: "-0.5rem", pt: 0.5 }} aria-live="polite">
        {check(checks.length, t("appCore.emailLogin.checkLength"))}
        {check(checks.letter, t("appCore.emailLogin.checkLetter"))}
        {check(checks.digit, t("appCore.emailLogin.checkDigit"))}
        {check(checks.special, t("appCore.emailLogin.checkSpecial"))}
      </Stack>
      <TextField id={`${idPrefix}-password-confirm`} label={labels?.confirm ?? t("appCore.signup.passwordConfirm")} type="password" autoComplete="new-password" fullWidth required value={confirm} disabled={disabled}
        error={mismatch} helperText={mismatch ? t("appCore.signup.mismatch") : undefined} onChange={(e) => onConfirmChange(e.target.value)} slotProps={{ htmlInput: { maxLength: 100 } }} />
    </Stack>
  );
}

/** '이 기기에서 로그인 유지' 선택(웹·웹앱). 설치형 앱은 항상 유지라 앱 정책(loginRetentionChoice)이 false면 그리지 않는다. */
export function RememberLoginChoice(props: { value: boolean; onChange: (value: boolean) => void; disabled?: boolean; label?: string }) {
  const t = useCoreText();
  return (
    <FormControlLabel sx={{ mx: 0, minHeight: 44 }} label={props.label ?? t("appCore.login.remember")}
      control={<Checkbox checked={props.value} disabled={props.disabled} onChange={(_, checked) => props.onChange(checked)} />} />
  );
}
