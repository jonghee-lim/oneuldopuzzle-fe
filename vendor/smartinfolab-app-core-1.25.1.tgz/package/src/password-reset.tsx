import { useState, type FormEvent, type ReactNode } from "react";
import { Alert, Button, Dialog, DialogActions, DialogContent, DialogTitle, Stack, TextField, Typography } from "@mui/material";
import { useMutation } from "@tanstack/react-query";
import { emailValidation } from "./email-validation.ts";
import { findIdText, passwordRuleError, recoveryBody, recoveryErrorMessage, recoveryServerText } from "./account-model.ts";
import { useCoreText } from "./use-core-text.ts";

/** 앱 axios 인스턴스(apiClient)처럼 post만 있으면 된다. */
export type RecoveryClient = { post: <T = unknown>(url: string, body: unknown) => Promise<{ data: T }> };
type RecoveryResult = { message?: string; verificationToken?: string; loginIds?: string[] };
/** 복구 목적: 비밀번호 재설정(기본) 또는 아이디 찾기(서버가 그 서비스에서 허용할 때만, 지금은 스파클·Family). */
export type RecoveryPurpose = "RESET" | "FIND_ID";

/** 서버 응답 대신 앱 고유 안내를 보이고 싶을 때(달 리듬 기존 문구 유지). 넘기지 않으면 서버 message를 그대로 보인다. */
export type PasswordResetMessages = { sent?: string; confirmed?: string; done?: string };

export type PasswordResetProps = {
  client: RecoveryClient;
  serviceCode: string;
  purpose?: RecoveryPurpose;
  /** 닫을 때. done=true면 비밀번호를 바꿨거나 아이디를 찾았다. */
  onClose: (done: boolean) => void;
  /** 비밀번호를 바꾼 뒤 닫을 때 앱 로그인 상태 지우기(내 계정에서 열었을 때). 로그인 화면에서는 넘기지 않는다. */
  onSessionCleared?: () => void;
  messages?: PasswordResetMessages;
  errorMessage?: (error: unknown) => string;
};

/**
 * 공통 /api/auth/recovery/* 3단계(인증번호 보내기 → 확인 → 새 비밀번호, 아이디 찾기는 확인에서 끝) 상태 기계. 2026-10-15 공통화, 1.24.0에서 아이디 찾기·페이지형 추가.
 * 변경을 마치면 서버가 그 계정의 모든 로그인을 끊으므로 완료 안내를 보인 뒤 닫을 때 onSessionCleared → onClose(true) 순서로 부른다.
 */
function useRecovery(props: PasswordResetProps) {
  const { client, serviceCode, purpose = "RESET", onClose, onSessionCleared, messages, errorMessage = recoveryErrorMessage } = props;
  const t = useCoreText();
  const [email, setEmail] = useState(""), [code, setCode] = useState(""), [token, setToken] = useState("");
  const [password, setPassword] = useState(""), [confirmPassword, setConfirmPassword] = useState("");
  const [sent, setSent] = useState(false), [done, setDone] = useState(false), [retryAt, setRetryAt] = useState(0);
  const [found, setFound] = useState<string[] | null>(null);
  const [message, setMessage] = useState(""), [validation, setValidation] = useState("");
  const request = useMutation({
    mutationFn: async (step: "start" | "confirm" | "complete") =>
      (await client.post<RecoveryResult>(`/api/auth/recovery/${step}`, recoveryBody(step, { serviceCode, email, purpose, code, verificationToken: token, newPassword: password }))).data ?? {},
    onSuccess: (data, step) => {
      if (step === "start") { setSent(true); setCode(""); setRetryAt(Date.now() + 60000); setMessage(messages?.sent ?? recoveryServerText(data.message, "sent")); }
      if (step === "confirm" && purpose === "FIND_ID") { const ids = data.loginIds ?? []; setFound(ids); setMessage(findIdText(data.message, ids)); }
      if (step === "confirm" && purpose === "RESET") { setToken(data.verificationToken ?? ""); setCode(""); setMessage(messages?.confirmed ?? recoveryServerText(data.message, "confirmed")); }
      if (step === "complete") { setDone(true); setToken(""); setPassword(""); setConfirmPassword(""); setMessage(messages?.done ?? recoveryServerText(data.message, "done")); }
    },
  });
  const busy = request.isPending;
  const finished = done || found !== null;
  // 세션을 바로 지우면 앱이 로그아웃 화면으로 다시 그려져 완료 안내가 사라진다. 닫을 때 지우고 로그인 화면으로 보낸다.
  const close = () => { if (done) onSessionCleared?.(); onClose(finished); };
  function start() {
    const error = emailValidation(email);
    if (error) { setValidation(error); return; }
    if (Date.now() < retryAt) { setValidation(t("appCore.reset.retryLater")); return; }
    setValidation(""); setMessage(""); request.mutate("start");
  }
  function submit(e: FormEvent) {
    e.preventDefault(); e.stopPropagation();
    if (busy || finished) return;
    setValidation("");
    if (!sent) { start(); return; }
    if (!token) {
      if (!/^[0-9]{6}$/.test(code)) { setValidation(t("appCore.reset.codeRequired")); return; }
      request.mutate("confirm"); return;
    }
    const rule = passwordRuleError(password);
    if (rule) { setValidation(rule); return; }
    if (password !== confirmPassword) { setValidation(t("appCore.reset.mismatch")); return; }
    request.mutate("complete");
  }
  function restart() { setSent(false); setToken(""); setCode(""); setPassword(""); setConfirmPassword(""); setMessage(""); setValidation(""); request.reset(); }
  function changeEmail(value: string) { setEmail(value); setValidation(""); request.reset(); }
  const errorText = validation || (request.isError ? errorMessage(request.error) : "");
  const submitLabel = busy ? t("appCore.reset.processing") : !sent ? t("appCore.reset.send") : !token ? t("appCore.reset.confirm") : t("appCore.reset.change");
  return { t, purpose, email, changeEmail, code, setCode, password, setPassword, confirmPassword, setConfirmPassword, sent, token, done, found, finished, busy, message, errorText, start, submit, restart, close, submitLabel };
}
type Recovery = ReturnType<typeof useRecovery>;

function RecoveryFields({ f }: { f: Recovery }) {
  const { t } = f;
  return (
    <Stack sx={{ gap: 2 }}>
      <Typography variant="body2">{t("appCore.reset.intro")}</Typography>
      <TextField label={t("appCore.reset.email")} type="email" autoComplete="email" value={f.email} disabled={f.busy || f.sent || f.finished} onChange={(e) => f.changeEmail(e.target.value)} fullWidth />
      {f.sent && !f.token && !f.finished && (
        <TextField label={t("appCore.reset.code")} value={f.code} autoComplete="one-time-code" disabled={f.busy} onChange={(e) => f.setCode(e.target.value.replace(/[^0-9]/g, "").slice(0, 6))} slotProps={{ htmlInput: { inputMode: "numeric", maxLength: 6 } }} fullWidth />
      )}
      {f.token && !f.done && (
        <>
          <TextField label={t("appCore.reset.newPassword")} type="password" autoComplete="new-password" value={f.password} disabled={f.busy} onChange={(e) => f.setPassword(e.target.value)} helperText={t("appCore.reset.passwordHelp")} fullWidth />
          <TextField label={t("appCore.reset.newPasswordConfirm")} type="password" autoComplete="new-password" value={f.confirmPassword} disabled={f.busy} onChange={(e) => f.setConfirmPassword(e.target.value)} fullWidth />
          <Typography variant="caption">{t("appCore.reset.signOutAll")}</Typography>
        </>
      )}
      {f.message && <Alert severity={f.finished ? "success" : "info"}>{f.message}</Alert>}
      {f.found?.map((id) => <Typography key={id} sx={{ fontWeight: 700, overflowWrap: "anywhere" }}>{id}</Typography>)}
      {f.errorText && <Alert severity="error">{f.errorText}</Alert>}
      {f.sent && !f.finished && (
        <Stack direction="row" sx={{ justifyContent: "center", flexWrap: "wrap" }}>
          {!f.token && <Button type="button" disabled={f.busy} onClick={f.start}>{t("appCore.reset.resend")}</Button>}
          <Button type="button" disabled={f.busy} onClick={f.restart}>{t("appCore.reset.reenterEmail")}</Button>
        </Stack>
      )}
    </Stack>
  );
}
function RecoveryButtons({ f, closeLabel }: { f: Recovery; closeLabel: string }) {
  return (
    <>
      <Button type="button" disabled={f.busy} onClick={f.close}>{f.finished ? f.t("appCore.social.toLogin") : closeLabel}</Button>
      {!f.finished && <Button type="submit" variant="contained" disabled={f.busy}>{f.submitLabel}</Button>}
    </>
  );
}

/** 내 계정·로그인 화면의 비밀번호 재설정(또는 아이디 찾기) 대화상자. */
export function PasswordResetDialog(props: PasswordResetProps) {
  const f = useRecovery(props);
  return (
    <Dialog open fullWidth maxWidth="xs" onClose={() => { if (!f.busy) f.close(); }}>
      <DialogTitle>{f.purpose === "FIND_ID" ? f.t("appCore.recovery.findIdTitle") : f.t("appCore.reset.title")}</DialogTitle>
      <form onSubmit={f.submit} noValidate>
        <DialogContent><RecoveryFields f={f} /></DialogContent>
        <DialogActions><RecoveryButtons f={f} closeLabel={f.t("common.close")} /></DialogActions>
      </form>
    </Dialog>
  );
}

/**
 * 같은 흐름을 대화상자 없이 페이지 카드 안에 그린다(달 리듬 /password-reset, 오늘DoEat #/password-reset처럼 별도 경로를 유지하는 앱).
 * 제목(h1)·설명은 페이지가 그리고, 닫기 버튼은 늘 '로그인으로 돌아가기'(onClose)다.
 */
export function PasswordResetForm(props: PasswordResetProps) {
  const f = useRecovery(props);
  return (
    <form onSubmit={f.submit} noValidate>
      <Stack sx={{ gap: 2 }}>
        <RecoveryFields f={f} />
        <Stack direction="row" sx={{ justifyContent: "flex-end", gap: 1, flexWrap: "wrap" }}><RecoveryButtons f={f} closeLabel={f.t("appCore.social.toLogin")} /></Stack>
      </Stack>
    </form>
  );
}

/**
 * 로그인 화면 아래 글자 링크 한 줄: [아이디 찾기] [비밀번호 찾기] + 앱이 넘긴 링크(회원가입 등). 누르면 공통 대화상자를 연다.
 * 로그인 화면에는 세션이 없으므로 onSessionCleared는 받지 않는다. 끝나면 onDone(purpose)로 앱이 뒷정리(가입 진행 저장값 지우기 등)를 한다.
 */
export function AccountRecoveryLinks(props: {
  client: RecoveryClient;
  serviceCode: string;
  /** 아이디 찾기 링크(서버가 그 서비스에서 허용하는 앱만). 기본 false. */
  findId?: boolean;
  /** 비밀번호 찾기 링크. 기본 true. */
  passwordReset?: boolean;
  labels?: { findId?: string; passwordReset?: string };
  messages?: PasswordResetMessages;
  errorMessage?: (error: unknown) => string;
  onDone?: (purpose: RecoveryPurpose) => void;
  disabled?: boolean;
  children?: ReactNode;
}) {
  const { client, serviceCode, findId = false, passwordReset = true, labels, messages, errorMessage, onDone, disabled, children } = props;
  const t = useCoreText();
  const [purpose, setPurpose] = useState<RecoveryPurpose | null>(null);
  return (
    <>
      <Stack direction="row" sx={{ justifyContent: "center", alignItems: "center", flexWrap: "wrap", gap: 0.5 }}>
        {findId && <Button type="button" disabled={disabled} onClick={() => setPurpose("FIND_ID")}>{labels?.findId ?? t("appCore.recovery.findId")}</Button>}
        {passwordReset && <Button type="button" disabled={disabled} onClick={() => setPurpose("RESET")}>{labels?.passwordReset ?? t("appCore.recovery.forgotPassword")}</Button>}
        {children}
      </Stack>
      {purpose && (
        <PasswordResetDialog key={purpose} client={client} serviceCode={serviceCode} purpose={purpose} messages={messages} errorMessage={errorMessage}
          onClose={(done) => { setPurpose(null); if (done) onDone?.(purpose); }} />
      )}
    </>
  );
}
