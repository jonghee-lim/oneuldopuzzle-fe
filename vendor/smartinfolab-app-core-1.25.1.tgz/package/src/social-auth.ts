import type { AxiosInstance } from "axios";
import type { ReauthProof } from "./account-action.ts";
import { coreT, providerName } from "./locale.ts";

/*
 * 카카오·Apple 로그인 클라이언트 공통(1.22.0, 로그인 공통화 P2). 이미 공통인 ./google-auth와 같은 모양이다.
 * 담는 것: PKCE(verifier·challenge), 시작 주소·state 검사, 대기 정보 저장(웹 sessionStorage + 홈 화면 웹앱 예비 localStorage, 설치형 앱 보안 저장소),
 * 유효 시간·형식 검사, 로그인·가입·연결·재인증 모드, 로그인 유지·돌아갈 곳 보관, 완료 처리는 진행 중인 중복만 합치고 끝나면 비우기(2026-10-24 U1 교훈).
 * 앱은 서비스 이름·API 경로·저장 키·여는 방법만 넘기고, 앱 고유 단계(가입 확인 화면, 세션 교환, 이동)는 완료 결과(kind)로 받아 처리한다.
 *
 *   const kakao = createKakaoAuth<LoginResponse>({ app: "dallhythm", api: apiClient, storageKey: "dallhythm.kakao.v1", open: openLoginUrl, client: nativeClient });
 *   await kakao.start({ rememberLogin });            // 로그인 화면
 *   const done = await kakao.complete(location.hash); // 완료 화면: kind = login | signup | link | reauth
 */
export type OAuthClient = "ios" | "android" | undefined;
export type SocialAuthStorage = { getItem(key: string): string | null; setItem(key: string, value: string): void; removeItem(key: string): void };
export type SocialAuthPersistence = { getItem(key: string): Promise<string | null>; setItem(key: string, value: string): Promise<void>; removeItem(key: string): Promise<void> };
export type SocialAuthOptions = {
  /** 앱의 axios 인스턴스(토큰·세션 처리는 앱 것 그대로). */
  api: Pick<AxiosInstance, "get" | "post">;
  /** 대기 정보 저장 키(앱마다 다르게). 설치형 앱의 앱 복귀(native-return)는 isPending(state)으로 확인한다. */
  storageKey: string;
  /** 로그인 주소 열기: 웹은 현재 창 이동, 설치형 앱은 인앱 브라우저. */
  open: (url: string) => Promise<void> | void;
  /** 설치형 앱 표시(서버가 앱 주소로 돌려보내고 state에 ios.·android. 앞붙임을 붙인다). */
  client?: () => OAuthClient;
  /** 기본 sessionStorage. */
  storage?: () => SocialAuthStorage;
  /** 설치형 앱 보안 저장소(있으면 storage 대신 쓴다). */
  persistence?: SocialAuthPersistence;
  /** 홈 화면 웹앱이 외부 로그인 왕복 중 새 WebKit 세션으로 돌아올 때를 위한 예비 저장소(보통 localStorage). 웹에서만 쓴다. */
  fallbackStorage?: () => SocialAuthStorage;
  /** 시작한 계정 표시(예: 사용자 id). 완료 때 다르면 거부한다. */
  context?: () => string | null | undefined;
  /** 대기 정보 유효 시간(기본 10분). */
  ttlMs?: number;
};
export type SocialAuthMode = "login" | "signup" | "link" | "reauth";
type Provider = "KAKAO" | "APPLE";
type Pending = {
  state: string; verifier: string; mode: SocialAuthMode; at: number; context?: string | null;
  rememberLogin?: boolean; returnTo?: string;
  /** 카카오 가입 확인 단계: 완료 응답의 가입 정보를 붙여 둔다(signup()·cancelSignup()까지 유지). */
  profile?: unknown;
};
export type StartOptions = { rememberLogin?: boolean; returnTo?: string };
export type SocialCompletion<TLogin, TProfile = never> =
  | { kind: "login"; response: TLogin; rememberLogin: boolean; returnTo: string; state: string; verifier: string }
  | { kind: "signup"; profile: TProfile; rememberLogin: boolean; returnTo: string; /** 로그인으로 시작했는지 앱 고유 가입 모드로 시작했는지 */ mode: "login" | "signup" }
  | { kind: "link"; returnTo: string }
  | { kind: "reauth"; proof: ReauthProof; returnTo: string };

const DEFAULT_TTL = 10 * 60 * 1000;
/** 가입 확인 화면은 입력에 시간이 걸리므로 더 길게 둔다. */
const SIGNUP_TTL = 30 * 60 * 1000;
const RAW_STATE = "[A-Za-z0-9_-]{43}";
const hex = (bytes: Uint8Array) => Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
const base64url = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

export function safeReturnTo(value: unknown, fallback = "/"): string {
  return typeof value === "string" && value.startsWith("/") && !value.startsWith("//") && !value.includes("\\")
    && !Array.from(value).some((c) => c.charCodeAt(0) <= 32) ? value : fallback;
}
/** 설치형 앱(client)은 서버가 앞붙임(ios.·android.)을 붙인 state만, 웹은 앞붙임 없는 state만 받는다. */
export function statePattern(client: OAuthClient): RegExp {
  return new RegExp("^" + (client ? client + "\\." : "") + RAW_STATE + "$");
}

type Engine = {
  provider: Provider;
  challenge: (digest: Uint8Array) => string;
  origin: string;
  pathname: string;
};

/** 공통 뼈대: 대기 정보·PKCE·시작·완료 한 번 처리. createKakaoAuth·createAppleAuth가 쓴다. */
function createEngine(options: SocialAuthOptions, engine: Engine) {
  const name = () => providerName(engine.provider);
  const t = (key: string) => coreT(`appCore.oauth.${key}`, { provider: name() });
  const storage = () => options.storage?.() ?? sessionStorage;
  const ttl = options.ttlMs ?? DEFAULT_TTL;
  let completing: Promise<unknown> | undefined;
  let completingFragment: string | undefined;

  async function readRaw(): Promise<string | null> {
    if (options.persistence) return options.persistence.getItem(options.storageKey);
    return storage().getItem(options.storageKey) ?? options.fallbackStorage?.().getItem(options.storageKey) ?? null;
  }
  async function write(pending: Pending): Promise<void> {
    const raw = JSON.stringify(pending);
    if (options.persistence) { await options.persistence.setItem(options.storageKey, raw); return; }
    storage().setItem(options.storageKey, raw);
    try { options.fallbackStorage?.().setItem(options.storageKey, raw); } catch { /* 예비 저장소를 못 쓰면 건너뛴다 */ }
  }
  async function clear(): Promise<void> {
    if (options.persistence) await options.persistence.removeItem(options.storageKey);
    try { storage().removeItem(options.storageKey); } catch { /* 저장소 접근 불가: 무시 */ }
    try { options.fallbackStorage?.().removeItem(options.storageKey); } catch { /* 무시 */ }
  }
  function valid(p: Pending | null, state?: string): p is Pending {
    if (!p || typeof p.state !== "string" || typeof p.verifier !== "string") return false;
    if (state !== undefined && p.state !== state) return false;
    if (!statePattern(options.client?.()).test(p.state) || !/^[a-f0-9]{64}$/.test(p.verifier)) return false;
    if (!["login", "signup", "link", "reauth"].includes(p.mode)) return false;
    const now = Date.now();
    if (!Number.isFinite(p.at) || p.at > now || now - p.at > (p.profile !== undefined ? SIGNUP_TTL : ttl)) return false;
    return (p.context ?? null) === (options.context?.() ?? null);
  }
  async function pending(state?: string): Promise<Pending | null> {
    try {
      const p = JSON.parse((await readRaw()) || "null") as Pending | null;
      return valid(p, state) ? p : null;
    } catch { return null; }
  }
  /** 화면 첫 그림(useState 초기값)처럼 기다릴 수 없는 곳용. 보안 저장소(persistence)를 쓰는 앱에서는 null(복귀 뒤 pending()을 쓴다). */
  function pendingSync(): Pending | null {
    if (options.persistence) return null;
    try {
      const raw = storage().getItem(options.storageKey) ?? options.fallbackStorage?.().getItem(options.storageKey) ?? null;
      const p = JSON.parse(raw || "null") as Pending | null;
      return valid(p) ? p : null;
    } catch { return null; }
  }
  /** 시작: 대기 정보를 새로 만들고 창을 연다. 응답 주소·state가 맞지 않으면 열지 않는다. */
  async function begin(mode: SocialAuthMode, path: string, body: Record<string, unknown>, start: StartOptions = {}): Promise<void> {
    await clear();
    const context = options.context?.() ?? null;
    const verifier = hex(crypto.getRandomValues(new Uint8Array(32)));
    const challenge = engine.challenge(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier))));
    const client = options.client?.();
    const { data } = await options.api.post<{ url: string; state: string }>(path, { ...body, challenge, ...(client ? { client } : {}) });
    let url: URL;
    try { url = new URL(data.url); } catch { throw new Error(t("badResponse")); }
    if (url.origin !== engine.origin || url.pathname !== engine.pathname || !statePattern(client).test(data.state)) throw new Error(t("badResponse"));
    if ((options.context?.() ?? null) !== context) throw new Error(t("accountChanged"));
    completing = undefined; completingFragment = undefined;
    await write({ state: data.state, verifier, mode, at: Date.now(), context, rememberLogin: start.rememberLogin === true, returnTo: safeReturnTo(start.returnTo) });
    try { await options.open(url.href); } catch (error) { await clear(); throw error; }
  }
  /** 완료 주소(#state=…&error=…)를 검사하고 대기 정보를 돌려준다. 취소·만료·다른 기기면 안내와 함께 거부한다. */
  async function take(fragment: string): Promise<{ pending: Pending; state: string }> {
    const params = new URLSearchParams(fragment.replace(/^#/, ""));
    if (params.getAll("error").length === 1 && params.get("error") === "expired") { await clear(); throw new Error(coreT("appCore.social.expired", { provider: name() })); }
    const state = params.get("state");
    const p = state ? await pending(state) : null;
    if (!p || params.getAll("state").length !== 1 || params.getAll("error").length > 1 || [...params.keys()].some((k) => k !== "state" && k !== "error")) {
      await clear(); throw new Error(t("restartHere"));
    }
    if (params.has("error")) {
      await clear();
      throw new Error(params.get("error") === "cancelled" ? coreT("appCore.social.cancelled", { provider: name() }) : t("restart"));
    }
    return { pending: p, state: p.state };
  }
  /** 진행 중인 같은 완료 요청만 합친다. 결과를 캐시하지 않아 로그아웃 뒤 재로그인에 이전 결과가 쓰이지 않는다. */
  function once<T>(fragment: string, run: () => Promise<T>): Promise<T> {
    if (completing && fragment !== completingFragment) return Promise.reject(new Error(t("responseChanged")));
    if (completing) return completing as Promise<T>;
    completingFragment = fragment;
    const result = run().finally(() => { if (completing === result) { completing = undefined; completingFragment = undefined; } });
    completing = result;
    return result;
  }
  return { t, begin, take, once, pending, pendingSync, write, clear, isPending: async (state: string) => (await pending(state)) !== null };
}

/* ---------------------------------------------------------------- 카카오 */
export type KakaoAuthOptions = SocialAuthOptions & {
  /** 공통 카카오 API의 앱 이름(app=…). */
  app: string;
  /** 본인 확인용 재인증에 보낼 mode(기본 "reauth"; 스파클은 서버의 탈퇴 확인 흐름 "withdraw"를 쓴다). */
  reauthMode?: string;
};
type KakaoFinish<TLogin, TProfile> = { login: TLogin | null; linked: boolean; signupProfile: TProfile | null; reauthenticated: boolean };
export type KakaoCompletion<TLogin, TProfile> = SocialCompletion<TLogin, TProfile>;

export function createKakaoAuth<TLogin, TProfile = { name: string; email: string; phone: string }>(options: KakaoAuthOptions) {
  const base = "/api/auth/kakao";
  const e = createEngine(options, { provider: "KAKAO", challenge: hex, origin: "https://kauth.kakao.com", pathname: "/oauth/authorize" });
  const start = (mode: SocialAuthMode, serverMode: string, body: Record<string, unknown>, opts: StartOptions) =>
    e.begin(mode, base + "/start", { app: options.app, mode: serverMode, password: "", ...body }, opts);
  async function finish(fragment: string): Promise<KakaoCompletion<TLogin, TProfile>> {
    const { pending, state } = await e.take(fragment);
    const returnTo = safeReturnTo(pending.returnTo);
    const { data } = await options.api.post<KakaoFinish<TLogin, TProfile>>(base + "/finish", { state, verifier: pending.verifier });
    if (pending.mode === "reauth") {
      await e.clear();
      if (!data.reauthenticated) throw new Error(e.t("reauthFailed"));
      return { kind: "reauth", proof: { provider: "KAKAO", state, verifier: pending.verifier }, returnTo };
    }
    if (pending.mode === "link") {
      await e.clear();
      if (!data.linked) throw new Error(e.t("linkFailed"));
      return { kind: "link", returnTo };
    }
    if (data.signupProfile) {
      // 가입 확인 화면이 state·verifier로 가입을 마치므로 대기 정보를 남긴다(signup()·cancelSignup()에서 지운다).
      await e.write({ ...pending, at: Date.now(), profile: data.signupProfile });
      return { kind: "signup", profile: data.signupProfile, rememberLogin: pending.rememberLogin === true, returnTo, mode: pending.mode === "signup" ? "signup" : "login" };
    }
    await e.clear();
    if (!data.login) throw new Error(e.t("loginInfo"));
    return { kind: "login", response: data.login, rememberLogin: pending.rememberLogin === true, returnTo, state, verifier: pending.verifier };
  }
  const asSignup = (p: Pending | null) => (p && p.profile !== undefined && (p.mode === "login" || p.mode === "signup") ? p : null);
  const signupPending = async () => asSignup(await e.pending());
  const signupView = (p: Pending | null) => (p ? { profile: p.profile as TProfile, rememberLogin: p.rememberLogin === true, returnTo: safeReturnTo(p.returnTo) } : null);
  return {
    /** 로그인(또는 앱 고유 가입 모드 "signup"). */
    start: (opts: StartOptions = {}, mode: "login" | "signup" = "login") => start(mode, mode, {}, opts),
    /** 로그인한 계정에 카카오 연결: 비밀번호 계정은 password, 소셜 전용은 최근 로그인 또는 재인증 proof. */
    link: (password: string, proof?: ReauthProof, opts: StartOptions = {}) => start("link", "link", { password, ...(proof ? { proof } : {}) }, opts),
    /** 본인 확인용 카카오 재인증. 완료하면 증명(state·verifier)을 돌려준다. */
    reauth: (opts: StartOptions = {}) => start("reauth", options.reauthMode ?? "reauth", {}, opts),
    complete: (fragment: string) => e.once(fragment, () => finish(fragment)),
    /** 가입 확인 화면에서: 완료 때 받은 가입 정보와 로그인 유지·돌아갈 곳. 없거나 만료면 null. */
    pendingSignup: async () => signupView(await signupPending()),
    /** 가입 화면 첫 그림용(동기). 보안 저장소를 쓰는 앱에서는 null. */
    pendingSignupSync: () => signupView(asSignup(e.pendingSync())),
    /** 스파클처럼 가입 정보를 서버에서 다시 받는 앱용(/signup-profile). */
    signupProfile: async <T = TProfile>() => {
      const p = await signupPending(); if (!p) throw new Error(e.t("signupExpired"));
      return (await options.api.post<T>(base + "/signup-profile", { state: p.state, verifier: p.verifier })).data;
    },
    /** 가입 확인을 마치고 계정을 만든다(/signup). 성공하면 대기 정보를 지운다. */
    signup: async (account: object, emailVerificationToken?: string) => {
      const p = await signupPending(); if (!p) throw new Error(e.t("signupExpired"));
      const { data } = await options.api.post<TLogin>(base + "/signup", { state: p.state, verifier: p.verifier, account, ...(emailVerificationToken ? { emailVerificationToken } : {}) });
      await e.clear();
      return { response: data, rememberLogin: p.rememberLogin === true, returnTo: safeReturnTo(p.returnTo) };
    },
    cancelSignup: () => e.clear(),
    unlink: async (input: { password?: string; proof?: ReauthProof }) => { await options.api.post(base + "/disconnect", { password: input.password ?? "", ...(input.proof ? { proof: input.proof } : {}) }); },
    available: async () => (await options.api.get<{ configured?: boolean }>(base + "/availability", { params: { app: options.app } })).data.configured === true,
    clear: e.clear,
    isPending: e.isPending,
  };
}

/* ---------------------------------------------------------------- Apple */
export type AppleAuthOptions = SocialAuthOptions & {
  /** 앱별 Apple API 경로(예: /api/dallhythm/auth/apple). */
  base: string;
};
export type AppleCompletion<TLogin> = SocialCompletion<TLogin>;

export function createAppleAuth<TLogin>(options: AppleAuthOptions) {
  const base = options.base.replace(/\/$/, "");
  const e = createEngine(options, { provider: "APPLE", challenge: base64url, origin: "https://appleid.apple.com", pathname: "/auth/authorize" });
  async function finish(fragment: string): Promise<AppleCompletion<TLogin>> {
    const { pending, state } = await e.take(fragment);
    const returnTo = safeReturnTo(pending.returnTo);
    const body = { state, verifier: pending.verifier };
    if (pending.mode === "reauth") {
      // 증명은 연결·해제·이메일 변경 요청에서 서버가 검증·소비한다(callback 후 2분 안에).
      await e.clear();
      return { kind: "reauth", proof: { provider: "APPLE", state, verifier: pending.verifier }, returnTo };
    }
    if (pending.mode === "link") {
      try { await options.api.post(base + "/link/finish", body); } finally { await e.clear(); }
      return { kind: "link", returnTo };
    }
    try {
      const { data } = await options.api.post<TLogin>(base + "/finish", body);
      return { kind: "login", response: data, rememberLogin: pending.rememberLogin === true, returnTo, state, verifier: pending.verifier };
    } finally { await e.clear(); }
  }
  return {
    start: (opts: StartOptions = {}) => e.begin("login", base + "/start", {}, opts),
    link: (password: string, proof?: ReauthProof, opts: StartOptions = {}) => e.begin("link", base + "/link/start", { password, ...(proof ? { proof } : {}) }, opts),
    reauth: (opts: StartOptions = {}) => e.begin("reauth", base + "/reauth/start", {}, opts),
    complete: (fragment: string) => e.once(fragment, () => finish(fragment)),
    unlink: async (input: { password?: string; proof?: ReauthProof }) => { await options.api.post(base + "/disconnect", { password: input.password ?? "", ...(input.proof ? { proof: input.proof } : {}) }); },
    available: async () => (await options.api.get<{ enabled?: boolean }>(base + "/config")).data.enabled === true,
    clear: e.clear,
    isPending: e.isPending,
  };
}
