import { App } from "@capacitor/app";
import { Browser } from "@capacitor/browser";
import { isNativeApp } from "./runtime.ts";
import { onLoginWindowReturnWeb } from "./social-login-start.ts";

/**
 * 앱 생명주기·외부 링크 같은 기기 기능을 화면 대신 이 파일이 감싼다(공통 지침 ‘웹·웹앱·앱 분기 한 곳에서 관리’).
 */

/** 앱이 포그라운드로 돌아올 때마다 부른다. 웹은 탭이 다시 보일 때. 해제 함수를 돌려준다. */
export function onAppForeground(handler: () => void): () => void {
  if (isNativeApp()) {
    let active = true;
    let handle: Promise<{ remove: () => Promise<void> } | null> = Promise.resolve(null);
    try {
      handle = App.addListener("appStateChange", (state) => { if (active && state.isActive) handler(); }).catch(() => null);
    } catch {
      /* 브리지가 없는 환경(E2E)에서는 복귀 감지 없이 시작 때만 확인한다. */
    }
    return () => { active = false; void handle.then((h) => h?.remove()); };
  }
  const listener = () => { if (document.visibilityState === "visible") handler(); };
  document.addEventListener("visibilitychange", listener);
  return () => document.removeEventListener("visibilitychange", listener);
}

/**
 * 간편 로그인 창에서 로그인하지 않고 돌아온 순간을 알린다(1.21.0, 달 리듬 2026-10-24 구현을 공통화). 해제 함수를 돌려준다.
 * - Android: Custom Tab을 닫으면 앱이 다시 앞으로 온다(appStateChange).
 * - iOS: SFSafariViewController는 앱 위에 떠 있어 복귀 이벤트가 없으므로 창 닫힘(browserFinished)을 본다.
 * - 웹·웹뷰: 탭이 다시 보일 때(visibilitychange), 뒤로가기로 페이지가 되살아날 때(pageshow persisted).
 * 로그인에 성공하면 완료 화면으로 넘어가므로 이 알림은 남아 있는 로그인 화면의 '로그인 중' 상태를 푸는 데만 쓴다(useSocialLoginStart의 onReturn).
 */
export function onLoginWindowReturn(handler: () => void): () => void {
  const offWeb = onLoginWindowReturnWeb(handler);
  if (!isNativeApp()) return offWeb;
  const offForeground = onAppForeground(handler);
  let finished: Promise<{ remove: () => Promise<void> } | null> = Promise.resolve(null);
  try {
    finished = Browser.addListener("browserFinished", handler).catch(() => null);
  } catch {
    /* 브리지가 없는 환경(E2E)에서는 앱 복귀·탭 복귀만 본다. */
  }
  return () => { offWeb(); offForeground(); void finished.then((h) => h?.remove()); };
}

/** 스토어·외부 페이지를 연다. 앱은 시스템 브라우저(App Store 링크는 스토어 앱으로 이어진다), 웹은 새 탭. */
export async function openExternal(url: string): Promise<void> {
  if (isNativeApp()) {
    try { await Browser.open({ url }); return; } catch { /* 플러그인이 없으면 아래로 */ }
  }
  window.open(url, "_blank", "noopener");
}
