import type { ElementType, MouseEvent, ReactNode } from "react";
import { Box, List, ListItemButton, Paper, Typography } from "@mui/material";
import { radius } from "./mui-shape.ts";
import { ChevronRightRounded } from "./account-icons.tsx";

/**
 * 설정·내 계정 화면의 묶음 목록(기준 앱 달 리듬 모양, 2026-10-15 공통화). 각 줄 오른쪽에 지금 값을 보인다.
 * 화면 이동 링크는 앱 라우터에 묶이므로 linkComponent(예: react-router Link)를 앱이 넘긴다. 앱은 얇은 파일에서 Link를 묶어 다시 내보낸다.
 */
export function SettingsGroup({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <Box component="section" aria-label={title}>
      {title && (
        <Typography component="h2" sx={{ fontSize: "0.75rem", fontWeight: 700, color: "text.secondary", px: 0.5, pb: 0.5 }}>
          {title}
        </Typography>
      )}
      <Paper variant="outlined" sx={{ borderRadius: radius.item, overflow: "hidden" }}>
        <List disablePadding sx={{ "& > * + *": { borderTop: 1, borderColor: "divider" } }}>
          {children}
        </List>
      </Paper>
    </Box>
  );
}

export type SettingsRowProps = {
  label: string;
  value?: ReactNode;
  /** 라벨 아래 작은 안내(예: 마지막 로그인 수단은 해제할 수 없음). */
  caption?: ReactNode;
  disabled?: boolean;
  /** 화면 이동 주소. linkComponent와 함께 쓴다. */
  to?: string;
  linkComponent?: ElementType;
  onClick?: (event: MouseEvent<HTMLElement>) => void;
  color?: string;
  chevron?: boolean;
  /** 왼쪽 아이콘(예: 로그인 방법의 수단 마크). 1.15.0 */
  icon?: ReactNode;
  /** 오른쪽 표시(배지·‘설정’ 같은 버튼 모양 글자). value 대신 쓴다. 행 전체가 버튼이라 안에 버튼을 넣지 않는다. 1.15.0 */
  trailing?: ReactNode;
};

export function SettingsRow({ label, value, to, linkComponent, onClick, color, chevron = true, caption, disabled = false, icon, trailing }: SettingsRowProps) {
  const link = to && linkComponent ? { component: linkComponent, to } : {};
  return (
    <ListItemButton {...link} onClick={onClick} disabled={disabled} sx={{ minHeight: 52, gap: 1, pl: 1.75, pr: 1.25 }}>
      {icon != null && <Box aria-hidden sx={{ display: "flex", flexShrink: 0, mr: 0.5 }}>{icon}</Box>}
      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Typography sx={{ fontSize: "0.9375rem", color }}>{label}</Typography>
        {caption != null && (
          <Typography variant="caption" color="text.secondary" sx={{ display: "block", wordBreak: "keep-all", overflowWrap: "anywhere" }}>
            {caption}
          </Typography>
        )}
      </Box>
      {trailing != null && <Box sx={{ flexShrink: 0, display: "flex", alignItems: "center" }}>{trailing}</Box>}
      {trailing == null && value != null && (
        <Typography variant="body2" color="text.secondary" sx={{ textAlign: "right" }}>
          {value}
        </Typography>
      )}
      {chevron && <ChevronRightRounded aria-hidden sx={{ color: "text.disabled" }} />}
      {/* 누를 수 없는 행도 화살표 자리를 비워 두어 오른쪽 배지가 다른 행과 같은 열에 온다(1.16.2). */}
      {!chevron && trailing != null && <Box aria-hidden sx={{ width: 24, flexShrink: 0 }} />}
    </ListItemButton>
  );
}
