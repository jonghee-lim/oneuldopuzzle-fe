import { useEffect, useRef, useState, type ReactNode } from "react";
import { Alert, Box, Button, DialogActions, DialogContent, DialogTitle, FormControlLabel, LinearProgress, Radio, RadioGroup, Stack, TextField, Typography } from "@mui/material";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  accountActions,
  accountErrorMessage,
  isLastMethod,
  providerLabel,
  reauthVia,
  type AccountMethods,
  type ReauthProof,
  type SocialProvider,
  type Verification,
} from "./account-action.ts";
import { emailValidation } from "./email-validation.ts";
import { canRemoveEmailLogin, canSetupEmailLogin, passwordChecks, passwordRuleError, remainingProvidersText } from "./account-model.ts";
import { SheetDialog } from "./sheet-dialog.tsx";
import { radius } from "./mui-shape.ts";
import { accountErrorCode } from "./account-action.ts";
import { coreT } from "./locale.ts";
import { useCoreText } from "./use-core-text.ts";

export { emailValidation };

/**
 * 내 계정 › 로그인 수단·이메일 변경 공통 부품(MUI, 인증 표준 2026-10-12). 기준 구현: 달 리듬 AccountPage.
 * 앱은 자기 API 호출 함수만 넘기고(카카오·Apple 시작 흐름은 앱의 PKCE 저장 방식을 따른다), 화면에는 행(row)만 직접 그린다.
 *
 *   const login = useLoginMethods({ storageKey: "oneuldofamily-account-action", queryKey: ["family","account",id], api });
 *   login.rows → [{ target: "KAKAO", label, connected, available, last, open }] … 행을 앱 스타일로 그린다
 *   <LoginMethodDialogs controller={login} currentEmail={user.email} />
 */
export type LoginMethodsApi = {
  /** GET /api/<앱>/account/methods */
  getMethods: () => Promise<AccountMethods & { email?: string; manageable?: boolean }>;
  kakaoAvailable?: () => Promise<boolean>;
  appleAvailable?: () => Promise<boolean>;
  /** 앱이 명시적으로 연결한 경우에만 Google 행을 추가한다. */
  google?: {
    available: () => Promise<boolean>;
    link: (password: string, proof?: ReauthProof) => Promise<void>;
    unlink: (input: { password?: string; proof?: ReauthProof }) => Promise<void>;
    reauth: () => Promise<void>;
  };
  linkKakao: (password: string, proof?: ReauthProof) => Promise<void>;
  linkApple: (password: string, proof?: ReauthProof) => Promise<void>;
  unlinkKakao: (input: { password?: string; proof?: ReauthProof }) => Promise<void>;
  unlinkApple: (input: { password?: string; proof?: ReauthProof }) => Promise<void>;
  reauthKakao: () => Promise<void>;
  reauthApple: () => Promise<void>;
  /** 이메일 변경(없으면 이메일 변경 기능을 숨긴다) */
  changeEmail?: (input: { email: string; emailVerificationToken: string; password?: string; proof?: ReauthProof }) => Promise<{ email: string }>;
  startEmailVerification?: (email: string) => Promise<void>;
  /** 인증번호 확인 → 인증 토큰 */
  confirmEmailVerification?: (email: string, code: string) => Promise<string>;
  /**
   * 소셜 전용 계정의 이메일 비밀번호 만들기(2026-10-17, 오늘Do클래스에서 시작해 공통화). 없으면 행을 숨긴다.
   * start: POST /api/<앱>/account/password/start(계정 이메일로 인증번호) → confirm: 공통 인증번호 확인(토큰) → set: POST /api/<앱>/account/password
   */
  password?: {
    start: () => Promise<{ email: string }>;
    confirm: (email: string, code: string) => Promise<string>;
    set: (input: { password: string; emailVerificationToken: string }) => Promise<unknown>;
    /**
     * ‘다른 이메일’ 경로(1.15.0, docs/EMAIL-LOGIN-SETUP-DESIGN.md 3-5). 없으면 1단계에 ‘지금 계정 이메일’만 보인다.
     * start·confirm: 가입형 이메일 인증(/api/auth/email-verification/*) → 토큰, prepare: POST /api/<앱>/account/email-login/prepare
     */
    other?: {
      start: (email: string) => Promise<void>;
      confirm: (email: string, code: string) => Promise<string>;
      prepare: (input: { email: string; emailVerificationToken: string; password?: string; proof?: ReauthProof }) => Promise<{ verificationToken: string; email: string }>;
    };
    /**
     * 이메일 로그인 해제(1.25.0): POST /api/<앱>/account/email-login/remove {password}. 없으면 ‘사용 중’ 행에 동작이 없다(이전과 같음).
     * 다른 수단이 하나 이상 연결된 이메일 계정에서만 행이 ‘사용 중 ›’가 되어 해제 시트(현재 비밀번호)를 연다. 세션은 유지된다.
     */
    remove?: (input: { password?: string; proof?: ReauthProof }) => Promise<unknown>;
  };
};

type Pending = { action: "link" | "unlink"; target: SocialProvider };
type EmailInput = { email: string; token: string; password?: string };

export function useLoginMethods(options: { storageKey: string; queryKey: readonly unknown[]; api: LoginMethodsApi; enabled?: boolean; onEmailChanged?: (email: string) => void }) {
  const { api, enabled = true } = options;
  const [store] = useState(() => accountActions(options.storageKey));
  const methods = useQuery({ queryKey: options.queryKey, queryFn: api.getMethods, enabled });
  const kakao = useQuery({ queryKey: [...options.queryKey, "kakao-available"], queryFn: () => (api.kakaoAvailable ? api.kakaoAvailable() : Promise.resolve(true)), enabled });
  const apple = useQuery({ queryKey: [...options.queryKey, "apple-available"], queryFn: () => (api.appleAvailable ? api.appleAvailable() : Promise.resolve(true)), enabled });
  const google = useQuery({ queryKey: [...options.queryKey, "google-available"], queryFn: () => api.google!.available(), enabled: enabled && !!api.google });
  const [pending, setPending] = useState<Pending | null>(null);
  const [emailOpen, setEmailOpen] = useState(false);
  const [passwordOpen, setPasswordOpen] = useState(false);
  /** 재인증에서 돌아와 prepare를 마친 ‘다른 이메일’ 설정: 비밀번호 단계부터 연다. */
  const [passwordResume, setPasswordResume] = useState<{ email: string; token: string } | null>(null);
  const [notice, setNotice] = useState("");
  const [resumeError, setResumeError] = useState("");

  const run = useMutation({
    mutationFn: async (input: Pending & { password?: string; proof?: ReauthProof }) => {
      if (input.target === "GOOGLE") {
        if (!api.google) throw new Error(coreT("appCore.methods.googleUnavailable"));
        if (input.action === "link") await api.google.link(input.password ?? "", input.proof);
        else await api.google.unlink({ password: input.password, proof: input.proof });
        return;
      }
      if (input.action === "link") {
        if (input.target === "KAKAO") await api.linkKakao(input.password ?? "", input.proof);
        else await api.linkApple(input.password ?? "", input.proof);
        return;
      }
      if (input.target === "KAKAO") await api.unlinkKakao({ password: input.password, proof: input.proof });
      else await api.unlinkApple({ password: input.password, proof: input.proof });
    },
    onSuccess: async (_, input) => {
      if (input.action !== "unlink") return; // 연결은 카카오·Apple 화면으로 이동한다
      setPending(null);
      setNotice(coreT("appCore.methods.unlinked", { provider: providerLabel[input.target] }));
      await methods.refetch();
    },
  });
  const email = useMutation({
    mutationFn: (input: EmailInput & { proof?: ReauthProof }) => {
      if (!api.changeEmail) throw new Error(coreT("appCore.emailChange.unavailable"));
      return api.changeEmail({ email: input.email, emailVerificationToken: input.token, password: input.password, proof: input.proof });
    },
    onSuccess: async (result) => {
      options.onEmailChanged?.(result.email);
      setEmailOpen(false);
      setNotice(coreT("appCore.emailChange.changed"));
      await methods.refetch();
    },
  });
  const password = useMutation({
    mutationFn: (input: { password: string; token: string; email?: string }) => {
      if (!api.password) throw new Error(coreT("appCore.setPassword.unavailable"));
      return api.password.set({ password: input.password, emailVerificationToken: input.token });
    },
    onSuccess: async (_, input) => {
      setPasswordOpen(false);
      setPasswordResume(null);
      // 설정한 이메일을 넣어 안내한다(1.16.2). 이메일을 모르면 옛 문구.
      setNotice(input.email ? coreT("appCore.emailLogin.done", { email: input.email }) : coreT("appCore.setPassword.done"));
      await methods.refetch();
    },
  });
  // 이메일 로그인 해제(1.25.0): 이메일 계정이므로 본인 확인은 현재 비밀번호다. 성공하면 행이 ‘설정 ›’로 돌아가고 비밀번호 재설정 행은 사라진다.
  const [removeOpen, setRemoveOpen] = useState(false);
  const removeLocal = useMutation({
    mutationFn: (input: { password?: string; proof?: ReauthProof }) => {
      if (!api.password?.remove) throw new Error(coreT("appCore.methods.removeUnavailable"));
      return api.password.remove(input);
    },
    onSuccess: async () => {
      setRemoveOpen(false);
      setNotice(coreT("appCore.methods.emailRemoved"));
      await methods.refetch();
    },
  });
  const reauth = useMutation({
    mutationFn: async (input: ((Pending | (EmailInput & { action: "email" | "emailLogin" })) & { via: SocialProvider })) => {
      if ("target" in input) store.saveAccountAction({ action: input.action, target: input.target, via: input.via });
      else store.saveAccountAction({ action: input.action, email: input.email, token: input.token, via: input.via });
      if (input.via === "GOOGLE") {
        if (!api.google) throw new Error(coreT("appCore.methods.googleUnavailable"));
        await api.google.reauth();
      } else if (input.via === "KAKAO") await api.reauthKakao();
      else await api.reauthApple();
    },
  });

  // 재인증(카카오·Apple 화면)에서 돌아왔으면 멈췄던 연결·해제·이메일 변경을 바로 이어 간다.
  const resumed = useRef(false);
  useEffect(() => {
    if (resumed.current || !enabled) return;
    resumed.current = true;
    const action = store.takeAccountAction();
    if (!action?.proof) return;
    const onError = (error: unknown) => setResumeError(accountErrorMessage(error));
    if (action.action === "emailLogin") {
      // 증명은 2분 안에 써야 하므로 돌아오자마자 prepare를 부르고, 비밀번호 단계(3/3)에서 시트를 연다.
      const prepare = api.password?.other?.prepare;
      if (!prepare) return;
      prepare({ email: action.email, emailVerificationToken: action.token, proof: action.proof })
        .then((r) => {
          const changed = r.email || action.email;
          setPasswordResume({ email: changed, token: r.verificationToken });
          setPasswordOpen(true);
          // prepare가 계정 이메일을 바꿨으므로 앱 사용자 저장소(프로필 카드·오늘DoIt/달 리듬의 methods 이메일)도 바로 맞춘다.
          options.onEmailChanged?.(changed);
          void methods.refetch();
        })
        .catch(onError);
    } else if (action.action === "email") email.mutate({ email: action.email, token: action.token, proof: action.proof }, { onError });
    else run.mutate({ action: action.action, target: action.target, proof: action.proof }, { onError });
  }, [enabled, email, run, store, api, methods]);

  const data = methods.data;
  const verification: Verification = data?.verification ?? "PASSWORD";
  const open = (action: "link" | "unlink", target: SocialProvider) => {
    run.reset();
    reauth.reset();
    setPending({ action, target });
  };
  const targets: SocialProvider[] = api.google ? ["KAKAO", "APPLE", "GOOGLE"] : ["KAKAO", "APPLE"];
  const rows = targets.map((target) => {
    const connected = target === "KAKAO" ? !!data?.kakao : target === "APPLE" ? !!data?.apple : !!data?.google;
    const available = target === "KAKAO" ? kakao.data !== false : target === "APPLE" ? apple.data !== false : google.data === true;
    const last = !!data && isLastMethod(data, target);
    return {
      target,
      label: providerLabel[target],
      connected,
      available,
      last,
      caption: last ? coreT("appCore.methods.lastMethod") : undefined,
      open: () => open(connected ? "unlink" : "link", target),
    };
  });

  return {
    methods,
    data,
    rows,
    verification,
    pending,
    setPending,
    run,
    reauth,
    email,
    emailOpen,
    canChangeEmail: Boolean(api.changeEmail && api.startEmailVerification && api.confirmEmailVerification) && data?.manageable !== false,
    openEmail: () => {
      email.reset();
      reauth.reset();
      setEmailOpen(true);
    },
    closeEmail: () => setEmailOpen(false),
    password,
    passwordOpen,
    // 소셜 전용·관리 가능 계정. 계정 이메일이 없으면 ‘다른 이메일’ 경로가 있어야 한다(1.15.0). 이미 있으면 '비밀번호 재설정' 행이 대신 보인다.
    canSetPassword: canSetupEmailLogin({ hasApi: !!api.password, hasOther: !!api.password?.other, local: data?.local, email: data?.email, manageable: data?.manageable }),
    openPassword: () => {
      password.reset();
      reauth.reset();
      setPasswordResume(null);
      setPasswordOpen(true);
    },
    closePassword: () => {
      setPasswordOpen(false);
      setPasswordResume(null);
    },
    passwordResume,
    // 이메일 로그인 해제(1.25.0): 앱이 remove를 넘겼고, 이메일 계정이며, 관리 가능하고, 다른 수단이 하나 이상 연결됐을 때.
    canRemovePassword: canRemoveEmailLogin({ hasApi: !!api.password?.remove, local: data?.local, manageable: data?.manageable, kakao: data?.kakao, apple: data?.apple, google: data?.google }),
    removeLocal,
    removeOpen,
    openRemove: () => {
      removeLocal.reset();
      setRemoveOpen(true);
    },
    closeRemove: () => setRemoveOpen(false),
    /** ‘다른 이메일’ prepare가 계정 이메일을 바꾼 직후: 앱에 알리고 로그인 수단을 다시 읽는다(1.16.2). */
    emailPrepared: (email: string) => {
      options.onEmailChanged?.(email);
      void methods.refetch();
    },
    notice,
    setNotice,
    resumeError,
    api,
  };
}

export type LoginMethodsController = ReturnType<typeof useLoginMethods>;

/** 연결·해제 확인 대화상자와 이메일 변경 대화상자. 본인 확인 방식(비밀번호·바로 진행·소셜 재인증)은 서버 값으로 정한다. */
export function LoginMethodDialogs({ controller, currentEmail, linkDescription }: { controller: LoginMethodsController; currentEmail?: string | null; linkDescription?: ReactNode }) {
  const c = controller;
  const t = useCoreText();
  const [password, setPassword] = useState("");
  const pending = c.pending;
  const via = pending && c.data ? reauthVia(c.data, pending.action, pending.target) : null;
  const needsPassword = c.verification === "PASSWORD";
  const needsReauth = c.verification === "REAUTH" && via !== null;
  const busy = c.run.isPending || c.reauth.isPending;
  const label = pending ? providerLabel[pending.target] : "";
  const close = () => {
    if (busy) return;
    setPassword("");
    c.setPending(null);
  };
  const submit = () => {
    if (!pending) return;
    if (needsReauth && via) c.reauth.mutate({ ...pending, via });
    else c.run.mutate({ ...pending, password: needsPassword ? password : undefined });
  };
  const emailVia = c.data ? reauthVia(c.data, "email") : null;
  return (
    <>
      <SheetDialog open={Boolean(pending)} onClose={close}>
        <DialogTitle>
          {t(pending?.action === "unlink" ? "appCore.methods.unlinkTitle" : "appCore.methods.linkTitle", { provider: label })}
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ pt: 1 }}>
            {pending?.action === "unlink" ? (
              <Typography>{t("appCore.methods.unlinkConfirm", { provider: label })}</Typography>
            ) : (
              <Typography>{linkDescription ?? t("appCore.methods.linkDescription", { provider: label })}</Typography>
            )}
            {needsPassword && (
              <Stack spacing={0.75}>
                <Typography component="label" htmlFor="account-password" variant="subtitle2">
                  {t("appCore.methods.currentPassword")}
                </Typography>
                <TextField id="account-password" type="password" autoComplete="current-password" value={password} disabled={busy} onChange={(e) => setPassword(e.target.value)} />
              </Stack>
            )}
            {needsReauth && via && (
              <Typography color="text.secondary">
                {t(pending?.action === "unlink" ? "appCore.methods.reauthThenUnlink" : "appCore.methods.reauthThenLink", { provider: providerLabel[via] })}
              </Typography>
            )}
            {(c.run.isError || c.reauth.isError) && <Alert severity="error">{accountErrorMessage(c.run.error ?? c.reauth.error)}</Alert>}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button disabled={busy} onClick={close}>
            {t("common.cancel")}
          </Button>
          <Button variant="contained" disabled={busy || (needsPassword && !password)} onClick={submit}>
            {needsReauth && via ? t("appCore.methods.verifyWith", { provider: providerLabel[via] }) : pending?.action === "unlink" ? t("appCore.methods.unlink") : t("appCore.methods.link2")}
          </Button>
        </DialogActions>
      </SheetDialog>
      {c.emailOpen && (
        <EmailChangeDialog
          currentEmail={currentEmail ?? c.data?.email}
          verification={c.verification}
          via={emailVia}
          busy={c.email.isPending || c.reauth.isPending}
          error={c.email.error ?? c.reauth.error}
          api={c.api}
          onClose={c.closeEmail}
          onSubmit={(input) => c.email.mutate(input)}
          onReauth={(input) => emailVia && c.reauth.mutate({ action: "email", ...input, via: emailVia })}
        />
      )}
      {c.passwordOpen && c.api.password && (
        <EmailLoginSetupDialog currentEmail={c.data?.email ?? currentEmail ?? ""} api={c.api.password} verification={c.verification}
          via={c.data ? reauthVia(c.data, "emailLogin") : null} resume={c.passwordResume}
          busy={c.password.isPending || c.reauth.isPending} error={c.password.error ?? c.reauth.error}
          onClose={c.closePassword} onSubmit={(input) => c.password.mutate(input)} onPrepared={c.emailPrepared}
          onReauth={(input) => { const v = c.data ? reauthVia(c.data, "emailLogin") : null; if (v) c.reauth.mutate({ action: "emailLogin", ...input, via: v }); }} />
      )}
      {c.removeOpen && c.api.password?.remove && (
        <EmailLoginRemoveDialog email={c.data?.email || currentEmail || ""} data={c.data} busy={c.removeLocal.isPending} error={c.removeLocal.error}
          onClose={c.closeRemove} onSubmit={(password) => c.removeLocal.mutate({ password })} />
      )}
    </>
  );
}

/**
 * 이메일 로그인 해제 시트(1.25.0, 스토리보드 email-login-remove): 무엇이 바뀌는지 한 문장 + 현재 비밀번호 + [해제]/[취소].
 * 이메일 계정이므로 본인 확인은 늘 현재 비밀번호다(서버 verify 규칙). 유일한 수단이면 행이 열리지 않으므로 여기서는 검사하지 않는다.
 */
function EmailLoginRemoveDialog(props: { email: string; data: AccountMethods | undefined; busy: boolean; error: unknown; onClose: () => void; onSubmit: (password: string) => void }) {
  const { email, data, busy, error, onClose, onSubmit } = props;
  const t = useCoreText();
  const [password, setPassword] = useState("");
  return (
    <SheetDialog open onClose={() => !busy && onClose()} labelledBy="email-login-remove-title">
      <DialogTitle id="email-login-remove-title">{t("appCore.methods.removeTitle")}</DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ pt: 1 }}>
          <Typography sx={{ overflowWrap: "anywhere", wordBreak: "keep-all" }}>{t("appCore.methods.removeConfirm", { email, providers: remainingProvidersText(data) })}</Typography>
          <Stack spacing={0.75}>
            <Typography component="label" htmlFor="email-login-remove-password" variant="subtitle2">
              {t("appCore.methods.currentPassword")}
            </Typography>
            <TextField id="email-login-remove-password" type="password" autoComplete="current-password" autoFocus value={password} disabled={busy} onChange={(e) => setPassword(e.target.value)} />
          </Stack>
          <Typography variant="caption" color="text.secondary" sx={{ overflowWrap: "anywhere" }}>{t("appCore.methods.removeNotice", { email })}</Typography>
          {busy && <LinearProgress aria-hidden />}
          {error ? <Alert severity="error">{accountErrorMessage(error)}</Alert> : null}
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button disabled={busy} onClick={onClose}>
          {t("common.cancel")}
        </Button>
        <Button variant="contained" disabled={busy || !password} onClick={() => onSubmit(password)}>
          {t("appCore.methods.unlink")}
        </Button>
      </DialogActions>
    </SheetDialog>
  );
}


/** 계정 이메일 변경: 회원가입과 같은 인증번호 흐름 + 로그인 수단 연결·해제와 같은 본인 확인. */
function EmailChangeDialog(props: {
  currentEmail: string | null | undefined;
  verification: Verification;
  via: SocialProvider | null;
  busy: boolean;
  error: unknown;
  api: LoginMethodsApi;
  onClose: () => void;
  onSubmit: (input: EmailInput) => void;
  onReauth: (input: EmailInput) => void;
}) {
  const { currentEmail, verification, via, busy, error, api, onClose, onSubmit, onReauth } = props;
  const t = useCoreText();
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [token, setToken] = useState("");
  const [sent, setSent] = useState(false);
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const invalid = email ? emailValidation(email) : "";
  const same = Boolean(currentEmail) && email.trim().toLowerCase() === String(currentEmail).toLowerCase();
  const start = useMutation({
    mutationFn: (value: string) => api.startEmailVerification!(value),
    onSuccess: () => {
      setSent(true);
      setCode("");
      setToken("");
      setMessage(coreT("appCore.emailChange.sent"));
    },
    onError: (e) => setMessage(accountErrorMessage(e, coreT("appCore.emailChange.sendFailed"))),
  });
  const confirm = useMutation({
    mutationFn: (input: { value: string; code: string }) => api.confirmEmailVerification!(input.value, input.code),
    onSuccess: (t) => {
      setToken(t);
      setMessage(coreT("appCore.emailChange.verified"));
    },
    onError: (e) => {
      setToken("");
      setMessage(accountErrorMessage(e, coreT("appCore.emailChange.verifyFailed")));
    },
  });
  const change = (value: string) => {
    setEmail(value);
    setSent(false);
    setCode("");
    setToken("");
    setMessage("");
  };
  const working = busy || start.isPending || confirm.isPending;
  const needsPassword = verification === "PASSWORD";
  const needsReauth = verification === "REAUTH" && via !== null;
  const ready = Boolean(token) && !working && (!needsPassword || Boolean(password));
  const submit = () => {
    const input = { email: email.trim().toLowerCase(), token, password: needsPassword ? password : undefined };
    if (needsReauth) onReauth(input);
    else onSubmit(input);
  };
  return (
    <SheetDialog open onClose={() => !working && onClose()}>
      <DialogTitle>{t("appCore.emailChange.title")}</DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ pt: 1 }}>
          {currentEmail && (
            <Typography color="text.secondary" sx={{ overflowWrap: "anywhere" }}>
              {t("appCore.emailChange.current", { email: currentEmail })}
            </Typography>
          )}
          <Stack direction="row" spacing={1} sx={{ alignItems: "flex-start" }}>
            <TextField id="account-new-email" label={t("appCore.emailChange.newEmail")} type="email" fullWidth autoFocus value={email} disabled={working || Boolean(token)}
              error={Boolean(invalid) || same} helperText={invalid || (same ? t("appCore.emailChange.same") : undefined)}
              onChange={(e) => change(e.target.value)} autoComplete="email" slotProps={{ htmlInput: { maxLength: 255, autoCapitalize: "none" } }} />
            {!token && (
              <Button variant="outlined" disabled={!email.trim() || Boolean(invalid) || same || working} onClick={() => start.mutate(email.trim())} sx={{ minWidth: 112, flexShrink: 0, mt: 1 }}>
                {start.isPending ? t("appCore.emailChange.sending") : sent ? t("appCore.emailChange.resend") : t("appCore.emailChange.getCode")}
              </Button>
            )}
          </Stack>
          {sent && !token && (
            <Stack direction="row" spacing={1}>
              <TextField label={t("appCore.emailChange.code")} fullWidth value={code} disabled={working} onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                slotProps={{ htmlInput: { inputMode: "numeric", maxLength: 6 } }} />
              <Button variant="contained" disabled={code.length !== 6 || working} onClick={() => confirm.mutate({ value: email.trim(), code })} sx={{ minWidth: 96, flexShrink: 0 }}>
                {confirm.isPending ? t("appCore.emailChange.checking") : t("appCore.emailChange.verify")}
              </Button>
            </Stack>
          )}
          {message && (
            <Typography variant="caption" color={token ? "success.main" : sent ? "text.secondary" : "error.main"}>
              {message}
            </Typography>
          )}
          {token && needsPassword && (
            <Stack spacing={0.75}>
              <Typography component="label" htmlFor="account-email-password" sx={{ fontWeight: 700, fontSize: "0.9rem" }}>
                {t("appCore.methods.currentPassword")}
              </Typography>
              <TextField id="account-email-password" type="password" autoComplete="current-password" value={password} disabled={working} onChange={(e) => setPassword(e.target.value)} />
            </Stack>
          )}
          {token && needsReauth && via && <Typography color="text.secondary">{t("appCore.emailChange.reauth", { provider: providerLabel[via] })}</Typography>}
          {error ? <Alert severity="error">{accountErrorMessage(error)}</Alert> : null}
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button disabled={working} onClick={onClose}>
          {t("common.cancel")}
        </Button>
        <Button variant="contained" disabled={!ready} onClick={submit}>
          {needsReauth && via ? t("appCore.methods.verifyWith", { provider: providerLabel[via] }) : t("appCore.emailChange.change")}
        </Button>
      </DialogActions>
    </SheetDialog>
  );
}

/**
 * 이메일 로그인 설정(1.15.0, docs/EMAIL-LOGIN-SETUP-DESIGN.md 3-2): ① 이메일 고르기(지금 계정 이메일 / 다른 이메일) → ② 인증번호 → ③ 비밀번호.
 * 지금 이메일: 계정 이메일로 인증번호(password.start/confirm) → 설정 토큰. 다른 이메일: 가입형 인증(other.start/confirm) →
 * 본인 확인(최근 로그인이면 바로, 아니면 소셜 재인증 왕복) → other.prepare(계정 이메일 변경 + 설정 토큰). 마지막은 password.set.
 */
function EmailLoginSetupDialog(props: {
  currentEmail: string;
  api: NonNullable<LoginMethodsApi["password"]>;
  verification: Verification;
  via: SocialProvider | null;
  resume: { email: string; token: string } | null;
  busy: boolean;
  error: unknown;
  onClose: () => void;
  onSubmit: (input: { password: string; token: string; email?: string }) => void;
  onReauth: (input: EmailInput) => void;
  /** 다른 이메일 prepare 성공(계정 이메일이 바뀐 시점). 앱 사용자 정보를 맞추는 데 쓴다. */
  onPrepared?: (email: string) => void;
}) {
  const { currentEmail, api, verification, via, resume, busy, error, onClose, onSubmit, onReauth, onPrepared } = props;
  const t = useCoreText();
  const other = api.other;
  const [choice, setChoice] = useState<"current" | "other">(currentEmail || !other ? "current" : "other");
  const [otherEmail, setOtherEmail] = useState("");
  const [sentTo, setSentTo] = useState(resume?.email ?? "");
  const [code, setCode] = useState("");
  const [signupToken, setSignupToken] = useState("");
  const [token, setToken] = useState(resume?.token ?? "");
  const [needsReauth, setNeedsReauth] = useState(false);
  const [password, setPassword] = useState("");
  const [again, setAgain] = useState("");
  const [message, setMessage] = useState("");
  const step = token ? 3 : sentTo ? 2 : 1;
  const target = choice === "current" ? currentEmail : otherEmail.trim();
  const otherInvalid = choice === "other" && otherEmail ? emailValidation(otherEmail) : "";
  const otherSame = choice === "other" && Boolean(currentEmail) && otherEmail.trim().toLowerCase() === currentEmail.toLowerCase();
  const start = useMutation({
    mutationFn: async () => {
      if (choice === "current") return (await api.start()).email || currentEmail;
      await other!.start(target);
      return target.toLowerCase();
    },
    onSuccess: (to) => { setSentTo(to); setCode(""); setMessage(""); },
    onError: (e) => setMessage(accountErrorMessage(e, coreT("appCore.emailChange.sendFailed"))),
  });
  const resend = useMutation({
    mutationFn: async () => { if (choice === "current") await api.start(); else await other!.start(sentTo); },
    onSuccess: () => setMessage(coreT("appCore.emailChange.sent")),
    onError: (e) => setMessage(accountErrorMessage(e, coreT("appCore.emailChange.sendFailed"))),
  });
  const prepare = useMutation({
    mutationFn: (emailVerificationToken: string) => other!.prepare({ email: sentTo, emailVerificationToken }),
    onSuccess: (r) => { setToken(r.verificationToken); setMessage(""); if (r.email) setSentTo(r.email); onPrepared?.(r.email || sentTo); },
    onError: (e) => {
      if (accountErrorCode(e) === "REAUTH_REQUIRED" && via) { setNeedsReauth(true); setMessage(""); }
      else setMessage(accountErrorMessage(e));
    },
  });
  const confirm = useMutation({
    mutationFn: (value: string) => (choice === "current" ? api.confirm(sentTo, value) : other!.confirm(sentTo, value)),
    onSuccess: (v) => {
      setMessage("");
      if (choice === "current") { setToken(v); return; }
      setSignupToken(v);
      // 다른 이메일은 계정 이메일까지 바꾸므로 본인 확인을 한다: 최근 로그인이면 바로, 아니면 소셜 재인증.
      if (verification === "REAUTH" && via) setNeedsReauth(true);
      else prepare.mutate(v);
    },
    onError: (e) => setMessage(accountErrorMessage(e, coreT("appCore.emailChange.verifyFailed"))),
  });
  const working = busy || start.isPending || resend.isPending || confirm.isPending || prepare.isPending;
  const checks = passwordChecks(password);
  const rule = password ? passwordRuleError(password) : "";
  const mismatch = again.length > 0 && again !== password;
  const ready = step === 3 && !working && password.length > 0 && !rule && again === password;
  const canStart = !working && (choice === "current" ? Boolean(currentEmail) : Boolean(otherEmail) && !otherInvalid && !otherSame);
  const back = () => { setSentTo(""); setCode(""); setSignupToken(""); setNeedsReauth(false); setMessage(""); };
  const check = (ok: boolean, label: string) => (
    <Typography key={label} component="span" variant="caption" sx={{ color: ok ? "success.main" : "text.secondary", whiteSpace: "nowrap" }}>{ok ? "✓" : "○"} {label}</Typography>
  );
  return (
    <SheetDialog open onClose={() => !working && onClose()} labelledBy="email-login-setup-title">
      <DialogTitle id="email-login-setup-title" sx={{ pb: 1 }}>
        <Stack direction="row" spacing={0.75} aria-hidden sx={{ mb: 1.5 }}>
          {[1, 2, 3].map((n) => <Box key={n} sx={{ flex: 1, height: "0.25rem", borderRadius: radius.control, bgcolor: n <= step ? "primary.main" : "divider" }} />)}
        </Stack>
        <Typography variant="caption" color="text.secondary" sx={{ display: "block" }}>{t("appCore.emailLogin.step", { step })}</Typography>
        {step === 1 ? t("appCore.emailLogin.title") : step === 2 ? t("appCore.emailLogin.codeTitle") : t("appCore.emailLogin.passwordTitle")}
      </DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ pt: 0.5 }}>
          {step === 1 && (
            <>
              <Typography color="text.secondary">{t("appCore.emailLogin.chooseDescription")}</Typography>
              <RadioGroup value={choice} onChange={(e) => { setChoice(e.target.value as "current" | "other"); setMessage(""); }} sx={{ gap: 1 }}>
                {currentEmail && (
                  <FormControlLabel value="current" control={<Radio />} disabled={working} sx={{ m: 0, p: 1, pr: 1.5, border: 1, borderColor: choice === "current" ? "primary.main" : "divider", borderRadius: radius.item, alignItems: "flex-start" }}
                    label={<Box sx={{ pt: 0.75, minWidth: 0 }}><Typography sx={{ fontWeight: 600, overflowWrap: "anywhere" }}>{currentEmail}</Typography><Typography variant="caption" color="text.secondary">{t("appCore.emailLogin.currentOption")}</Typography></Box>} />
                )}
                {other && (
                  <FormControlLabel value="other" control={<Radio />} disabled={working} sx={{ m: 0, p: 1, pr: 1.5, border: 1, borderColor: choice === "other" ? "primary.main" : "divider", borderRadius: radius.item, alignItems: "flex-start" }}
                    label={<Box sx={{ pt: 0.75, minWidth: 0 }}><Typography sx={{ fontWeight: 600 }}>{t("appCore.emailLogin.otherOption")}</Typography><Typography variant="caption" color="text.secondary">{t("appCore.emailLogin.otherHint")}</Typography></Box>} />
                )}
              </RadioGroup>
              {choice === "other" && (
                <TextField id="email-login-other" label={t("appCore.emailLogin.otherEmail")} type="email" autoComplete="email" fullWidth value={otherEmail} disabled={working}
                  error={Boolean(otherInvalid) || otherSame} helperText={otherInvalid || (otherSame ? t("appCore.emailLogin.sameAsCurrent") : undefined)}
                  onChange={(e) => { setOtherEmail(e.target.value); setMessage(""); }} />
              )}
            </>
          )}
          {step === 2 && !needsReauth && (
            <>
              <Typography color="text.secondary" sx={{ overflowWrap: "anywhere" }}>{t("appCore.emailLogin.codeSentTo", { email: sentTo })}</Typography>
              <Stack direction="row" spacing={1}>
                <TextField label={t("appCore.emailChange.code")} fullWidth autoFocus value={code} disabled={working} autoComplete="one-time-code"
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))} slotProps={{ htmlInput: { inputMode: "numeric", maxLength: 6 } }} />
                <Button variant="contained" disabled={code.length !== 6 || working} onClick={() => confirm.mutate(code)} sx={{ minWidth: 96, flexShrink: 0 }}>
                  {confirm.isPending || prepare.isPending ? t("appCore.emailChange.checking") : t("appCore.emailChange.verify")}
                </Button>
              </Stack>
              <Button size="small" disabled={working} onClick={() => resend.mutate()} sx={{ alignSelf: "flex-start" }}>{resend.isPending ? t("appCore.emailChange.sending") : t("appCore.emailChange.resend")}</Button>
            </>
          )}
          {step === 2 && needsReauth && via && (
            <Typography color="text.secondary">{t("appCore.emailLogin.reauth", { provider: providerLabel[via] })}</Typography>
          )}
          {step === 3 && (
            <>
              <Typography color="success.main" sx={{ overflowWrap: "anywhere" }}>{t("appCore.emailLogin.verifiedFor", { email: sentTo || currentEmail })}</Typography>
              <TextField id="account-new-password" label={t("appCore.setPassword.newPassword")} type="password" autoComplete="new-password" fullWidth autoFocus value={password} disabled={working}
                error={Boolean(password) && Boolean(rule)} onChange={(e) => setPassword(e.target.value)} />
              <Stack direction="row" useFlexGap sx={{ flexWrap: "wrap", columnGap: 1.5, rowGap: 0.5, mt: "-0.5rem", pt: 0.5 }} aria-live="polite">
                {check(checks.length, t("appCore.emailLogin.checkLength"))}
                {check(checks.letter, t("appCore.emailLogin.checkLetter"))}
                {check(checks.digit, t("appCore.emailLogin.checkDigit"))}
                {check(checks.special, t("appCore.emailLogin.checkSpecial"))}
              </Stack>
              <TextField id="account-new-password-again" label={t("appCore.setPassword.again")} type="password" autoComplete="new-password" fullWidth value={again} disabled={working}
                error={mismatch} helperText={mismatch ? t("appCore.setPassword.mismatch") : undefined} onChange={(e) => setAgain(e.target.value)} />
              <Typography variant="caption" color="text.secondary" sx={{ overflowWrap: "anywhere" }}>{t("appCore.emailLogin.noticeMail", { email: sentTo || currentEmail })}</Typography>
            </>
          )}
          {working && <LinearProgress aria-hidden />}
          {message && <Alert severity="error">{message}</Alert>}
          {error ? <Alert severity="error">{accountErrorMessage(error)}</Alert> : null}
        </Stack>
      </DialogContent>
      <DialogActions sx={{ flexWrap: "wrap", gap: 1 }}>
        {step === 2 && !resume ? <Button disabled={working} onClick={back}>{t("appCore.emailLogin.back")}</Button> : <Button disabled={working} onClick={onClose}>{t("common.cancel")}</Button>}
        {step === 1 && (
          <Button variant="contained" disabled={!canStart} onClick={() => start.mutate()}>
            {start.isPending ? t("appCore.emailChange.sending") : t("appCore.emailChange.getCode")}
          </Button>
        )}
        {step === 2 && needsReauth && via && (
          <Button variant="contained" disabled={working} onClick={() => onReauth({ email: sentTo, token: signupToken })}>
            {t("appCore.methods.verifyWith", { provider: providerLabel[via] })}
          </Button>
        )}
        {step === 3 && (
          <Button variant="contained" disabled={!ready} onClick={() => onSubmit({ password, token, email: sentTo || currentEmail })}>
            {t("appCore.emailLogin.submit")}
          </Button>
        )}
      </DialogActions>
    </SheetDialog>
  );
}
