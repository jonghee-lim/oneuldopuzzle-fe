import { useEffect, useState, useSyncExternalStore } from "react";
import { accountErrorMessage } from "./account-action.ts";
import { coreT, providerName } from "./locale.ts";
import type { SocialLoginItem } from "./social-login.tsx";
import type { SocialAvailability } from "./social-availability.ts";
import { useCoreText } from "./use-core-text.ts";

/*
 * 로그인 화면 간편 로그인 시작·‘로그인 중’ 표준(1.21.0, 로그인 공통화 P1).
 * 8개 앱이 따로 들고 있던 "버튼을 누르면 로그인 중 → 창을 열고 → 돌아오면 풀기 → 실패 문구"를 한 곳에 둔다.
 *
 *   const social = useSocialAvailability(apiClient, "DALLHYTHM");
 *   const start = useSocialLoginStart({
 *     starters: { kakao: () => startKakaoLogin(remember), apple: () => startAppleLogin("/", remember), google: () => startGoogleLogin(remember) },
 *     onReturn: onLoginWindowReturn,       // 설치형 앱(app-events). 웹 전용 앱은 생략(탭 복귀·bfcache만 본다).
 *   });
 *   <SocialLoginButtons layout="horizontal" items={start.items(social)} />
 *   {start.error && <Alert severity="error">{start.error}</Alert>}
 *
 * 규칙(사용자 결정 2026-10-24, 달 리듬 방식):
 * - 버튼을 누르면 세 수단이 함께 막히고 누른 수단 아래에 "{수단}로 이동 중…"이 보인다. 창이 열린 뒤에도 그대로 둔다(두 번 눌러 시작 요청이 겹치지 않게).
 * - 로그인하지 않고 창에서 돌아오면 푼다: Android 앱 복귀(appStateChange)·iOS 창 닫힘(browserFinished)·웹 탭 복귀(visibilitychange)·뒤로가기 bfcache(pageshow).
 *   로그인에 성공하면 완료 화면으로 넘어가므로 이 풀림은 남아 있는 로그인 화면에만 영향을 준다.
 * - 시작 요청이 실패하면 바로 풀고 문구를 보인다: 서버 안내 → 연결·시간 초과·서버 장애 안내 → 앱 문구(messages) → 기본 문구(accountErrorMessage 규칙).
 *   돌아온 뒤 늦게 도착한 실패는 보이지 않는다.
 */
export type SocialStartProvider = "kakao" | "apple" | "google";
export type SocialStarters = Partial<Record<SocialStartProvider, () => Promise<unknown>>>;
export type SocialStartState = {
  /** 어느 수단이든 시작 중(창을 연 뒤 돌아오기 전까지 포함). 이메일 폼도 이 값으로 막는 앱이 많다. */
  busy: boolean;
  /** 지금 시작 중인 수단. */
  pending: SocialStartProvider | null;
  /** 마지막 시작 실패 문구(없으면 빈 문자열). 다른 수단을 누르면 지워진다. */
  error: string;
};
export type SocialStartOptions = {
  starters: SocialStarters;
  /** 로그인 창에서 돌아온 신호. 설치형 앱은 `./app-events`의 onLoginWindowReturn, 웹 전용 앱은 생략(onLoginWindowReturnWeb). */
  onReturn?: (handler: () => void) => () => void;
  /** 수단별 시작 실패 기본 문구(앱 다국어 사전을 쓰는 앱). 없으면 app-core 문구. */
  messages?: Partial<Record<SocialStartProvider, string>>;
  /** 실패 문구 규칙을 바꿀 때(기본 accountErrorMessage). */
  errorMessage?: (error: unknown, fallback: string) => string;
};

const PROVIDERS: readonly SocialStartProvider[] = ["kakao", "apple", "google"];
const upper = (p: SocialStartProvider) => p.toUpperCase() as "KAKAO" | "APPLE" | "GOOGLE";

/** 수단별 기본 시작 실패 문구(지금 화면 언어). */
export const socialStartFallback = (provider: SocialStartProvider) => coreT("appCore.social.startFailed", { provider: providerName(upper(provider)) });

/**
 * 웹에서 로그인 창(다른 사이트로 이동)에서 돌아온 순간: 탭이 다시 보일 때(visibilitychange), 뒤로가기로 페이지가 되살아날 때(pageshow persisted).
 * 설치형 앱 복귀까지 보려면 `./app-events`의 onLoginWindowReturn을 쓴다(이 함수를 포함한다).
 */
export function onLoginWindowReturnWeb(handler: () => void, env: { doc?: Pick<Document, "addEventListener" | "removeEventListener" | "visibilityState">; win?: Pick<Window, "addEventListener" | "removeEventListener"> } = {}): () => void {
  const doc = env.doc ?? (typeof document === "undefined" ? undefined : document);
  const win = env.win ?? (typeof window === "undefined" ? undefined : window);
  const onVisible = () => { if (doc?.visibilityState === "visible") handler(); };
  const onPageShow = (event: Event) => { if ((event as PageTransitionEvent).persisted) handler(); };
  doc?.addEventListener("visibilitychange", onVisible);
  win?.addEventListener("pageshow", onPageShow);
  return () => { doc?.removeEventListener("visibilitychange", onVisible); win?.removeEventListener("pageshow", onPageShow); };
}

/** 화면 틀과 무관한 상태 기계. 훅(useSocialLoginStart)이 감싸고, 단위 테스트는 이것을 직접 돈다. 옵션은 update()로 최신 값을 넣는다. */
export function createSocialLoginStart(initial: SocialStartOptions) {
  let options = initial;
  const read = () => options;
  let state: SocialStartState = { busy: false, pending: null, error: "" };
  const listeners = new Set<() => void>();
  let attempt = 0;
  const set = (patch: Partial<SocialStartState>) => {
    state = { ...state, ...patch };
    for (const l of [...listeners]) l();
  };
  async function start(provider: SocialStartProvider): Promise<void> {
    const starter = read().starters[provider];
    if (!starter || state.busy) return;
    const id = ++attempt;
    set({ busy: true, pending: provider, error: "" });
    try {
      await starter();
      // 창이 열렸다. 돌아오면(release) 풀린다.
    } catch (error) {
      if (id !== attempt) return; // 이미 돌아와서 풀린 뒤에 온 실패는 보이지 않는다.
      const options = read();
      const fallback = options.messages?.[provider] ?? socialStartFallback(provider);
      set({ busy: false, pending: null, error: (options.errorMessage ?? accountErrorMessage)(error, fallback) });
    }
  }
  /** 로그인 창에서 돌아왔다(또는 화면이 사라진다): 시작 중이면 푼다. */
  function release() {
    if (!state.busy && !state.pending) return;
    attempt += 1;
    set({ busy: false, pending: null });
  }
  return {
    getState: () => state,
    subscribe: (listener: () => void) => { listeners.add(listener); return () => { listeners.delete(listener); }; },
    /** 시작 함수는 누르는 순간의 값(로그인 유지 선택·돌아갈 곳)을 읽어야 하므로 렌더마다 최신 옵션을 넣는다. */
    update: (next: SocialStartOptions) => { options = next; },
    start,
    release,
    clearError: () => { if (state.error) set({ error: "" }); },
  };
}

export type SocialLoginStart = SocialStartState & {
  start: (provider: SocialStartProvider) => void;
  clearError: () => void;
  /** 그 수단이 시작 중이면 "{수단}로 이동 중…", 아니면 undefined(SocialLoginItem.hint에 넘긴다). */
  hint: (provider: SocialStartProvider) => string | undefined;
  /** 사용 가능 상태(useSocialAvailability)와 합쳐 SocialLoginButtons items를 만든다. 시작 함수가 없는 수단과 꺼진 수단은 빠진다. */
  items: (availability: Pick<SocialAvailability, SocialStartProvider>, options?: { disabled?: boolean }) => SocialLoginItem[];
};

export function useSocialLoginStart(options: SocialStartOptions): SocialLoginStart {
  const [controller] = useState(() => createSocialLoginStart(options));
  useEffect(() => { controller.update(options); });
  const { onReturn } = options;
  useEffect(() => {
    const off = (onReturn ?? onLoginWindowReturnWeb)(controller.release);
    return () => { off(); controller.release(); };
  }, [controller, onReturn]);
  const state = useSyncExternalStore(controller.subscribe, controller.getState, controller.getState);
  const t = useCoreText();
  const hint = (provider: SocialStartProvider) => (state.pending === provider ? t("appCore.social.going", { provider: t(`appCore.provider.${upper(provider)}`) }) : undefined);
  const { starters } = options;
  const items: SocialLoginStart["items"] = (availability, extra = {}) =>
    PROVIDERS.filter((p) => starters[p] && availability[p].visible).map((p) => ({
      provider: p,
      onClick: () => { void controller.start(p); },
      disabled: state.busy || extra.disabled === true || !availability[p].ready,
      hint: hint(p),
    }));
  return { ...state, start: (p) => { void controller.start(p); }, clearError: controller.clearError, hint, items };
}
