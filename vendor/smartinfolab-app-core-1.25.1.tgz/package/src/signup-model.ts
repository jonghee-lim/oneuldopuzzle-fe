/**
 * 회원가입 부품(./signup)의 순수 계산. JSX 없이 단위 테스트한다(로그인 공통화 P4, 1.24.0).
 */
import { passwordRuleError } from "./account-model.ts";

/** 인증번호 재요청 간격(서버 60초 제한과 같다). */
export const RESEND_INTERVAL_MS = 60000;

/** 가입용 이메일은 앞뒤 공백을 떼고 소문자로 보낸다(서버 normalizeEmail과 같은 결과). */
export function normalizeSignupEmail(value: string): string {
  return value.trim().toLowerCase();
}

/** 인증번호 입력값: 숫자만 6자리까지. */
export function codeDigits(raw: string): string {
  return raw.replace(/\D/g, "").slice(0, 6);
}

/** 재요청 제한 중인지. */
export function resendBlocked(retryAt: number, now = Date.now()): boolean {
  return now < retryAt;
}

/** 이메일 인증 시작(또는 중복 확인)의 '이미 가입된 이메일' 거절: 서버는 409로 돌려준다. */
export function isDuplicateEmailError(error: unknown): boolean {
  const status = (error as { response?: { status?: number } } | undefined)?.response?.status;
  return status === 409;
}

/** 비밀번호 칸 오류: 비어 있으면 아직 검사하지 않고, 입력했으면 공통 규칙으로 본다. */
export function passwordFieldError(password: string): string {
  return password ? passwordRuleError(password) : "";
}

/** 가입 제출 전 비밀번호 검사: 규칙 → 확인 일치. 통과하면 빈 문자열. */
export function signupPasswordError(password: string, confirm: string, mismatchText: string): string {
  const rule = passwordRuleError(password);
  if (rule) return rule;
  return password === confirm ? "" : mismatchText;
}
