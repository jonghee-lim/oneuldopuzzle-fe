import { useCallback, useEffect, useState, type ElementType } from "react";
import { Alert, Box, Button, CircularProgress, Dialog, IconButton, DialogActions, DialogContent, DialogContentText, DialogTitle, Paper, Stack, TextField, Typography } from "@mui/material";
import { alpha } from "@mui/material/styles";
import { radius } from "./mui-shape.ts";
import { HelpOutlineRounded } from "./account-icons.tsx";
import { useCoreLanguage, useCoreText } from "./use-core-text.ts";
import { formatDateTime } from "./date-format.ts";
import { AiConnectGuide } from "./ai-connect-guide-view.tsx";
import { aiConnectError, cleanLabel, clientInitial, connectionTitle, defaultAiConnectContent, isRequestId, unusedConnections, withoutConnection, type AiConnectApi, type AiConnectContent, type AiConnection, type AiConnectErrorView, type AiConsentRequest } from "./ai-connect-model.ts";

/*
 * AI 비서 연결 공통 화면(1.15.0, 2026-10-19 시안 oneuldoit-fe/docs/ai-connect-mockup.html).
 * - AiConnectSettings: 설정 › AI 비서 연결(연결 방법·서버 주소 복사·연결된 AI 목록·해제).
 * - AiConsent: AI 앱이 연 OAuth 로그인·동의 화면(허용/거부 → AI 앱으로 이동).
 * 앱은 brand(앱 이름)·mcpUrl·api만 넘긴다. 머리글·레이아웃(헤더·탭)은 앱 화면이 감싼다. 타입·규칙은 `./ai-connect-model`에서 가져온다.
 * 1.17.0(2026-10-20): 연결 이름(동의 화면 이름 칸, 목록에서 이름 바꾸기), 어느 앱인지(app) 한 줄, 연결 시각, 사용하지 않은 연결 정리.
 */

const k = (key: string) => `appCore.aiConnect.${key}`;

function Logo({ name, color }: { name: string; color?: string }) {
  return (
    <Box aria-hidden sx={(t) => ({ width: 40, height: 40, borderRadius: radius.item, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center",
      fontWeight: 800, color: t.palette.getContrastText(color ?? t.palette.primary.main), bgcolor: color ?? t.palette.primary.main })}>
      {clientInitial(name)}
    </Box>
  );
}

function Section({ title, children, help }: { title: string; children: React.ReactNode; help?: { label: string; onClick: () => void } }) {
  return (
    <Box component="section" aria-label={title}>
      <Stack direction="row" sx={{ alignItems: "center", justifyContent: "space-between", px: 0.5, pb: 0.5 }}>
        <Typography component="h2" sx={{ fontSize: "0.75rem", fontWeight: 700, color: "text.secondary" }}>{title}</Typography>
        {/* 제목 줄 높이에 맞춘 작은 아이콘(2026-10-20: 채운 원 버튼이 앱 테마 최소 높이로 커져 튀어나오던 것). 누르는 영역은 32px. */}
        {help && <IconButton onClick={help.onClick} aria-label={help.label} sx={{ width: 32, height: 32, minHeight: 0, my: -0.75, color: "text.secondary" }}><HelpOutlineRounded sx={{ fontSize: 18 }} /></IconButton>}
      </Stack>
      <Paper variant="outlined" sx={{ borderRadius: radius.item, overflow: "hidden" }}>{children}</Paper>
    </Box>
  );
}

/**
 * maxConnections(1.17.0): 안내 창의 연결 수 한도. 서버 정책(AiPlanPolicy FREE)과 같은 값, 기본 5.
 * content(1.17.0): 앱마다 다른 문구(다루는 데이터·말 예시). 없으면 일반 문구. MCP 서버 이름은 mcpUrl 끝에서 뽑는다.
 */
/** connectorName(1.18.0): 커스텀 커넥터 이름 칸에 넣을 이름. 가이드가 이 이름을 안내하고 복사하게 한다(없으면 1.17까지와 같음). */
export type AiConnectSettingsProps = { brand: string; mcpUrl: string; api: AiConnectApi; maxConnections?: number; content?: AiConnectContent; connectorName?: string };

export function AiConnectSettings({ brand, mcpUrl, api, maxConnections = 5, content: given, connectorName }: AiConnectSettingsProps) {
  const t = useCoreText();
  const lang = useCoreLanguage();
  const content = given ?? defaultAiConnectContent[lang];
  const data = content.data;
  const [list, setList] = useState<AiConnection[] | null>(null);
  const [loadError, setLoadError] = useState(false);
  const [copied, setCopied] = useState(false);
  const [nameCopied, setNameCopied] = useState(false);
  const [pending, setPending] = useState<AiConnection | null>(null);
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState(false);
  const [guide, setGuide] = useState(false);
  const [renaming, setRenaming] = useState<AiConnection | null>(null);
  const [labelDraft, setLabelDraft] = useState("");
  const [cleanup, setCleanup] = useState(false);
  const [info, setInfo] = useState(false);

  const load = useCallback(() => api.connections().then((l) => { setList(l); setLoadError(false); }, () => setLoadError(true)), [api]);
  useEffect(() => { void load(); }, [load]);
  const retry = () => { setLoadError(false); setList(null); void load(); };

  const copy = () => {
    void navigator.clipboard?.writeText(mcpUrl).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2000); }, () => undefined);
  };
  const copyName = () => {
    if (connectorName) void navigator.clipboard?.writeText(connectorName).then(() => { setNameCopied(true); setTimeout(() => setNameCopied(false), 2000); }, () => undefined);
  };
  const disconnect = async () => {
    if (!pending) return;
    setBusy(true); setActionError(false);
    try {
      await api.disconnect(pending.id);
      setList((cur) => withoutConnection(cur ?? [], pending.id));
      setPending(null);
      void load();
    } catch { setActionError(true); } finally { setBusy(false); }
  };
  const rename = async () => {
    if (!renaming || !api.rename) return;
    const label = cleanLabel(labelDraft);
    setBusy(true); setActionError(false);
    try {
      await api.rename(renaming.id, label);
      setList((cur) => (cur ?? []).map((c) => (c.id === renaming.id ? { ...c, label: label || null } : c)));
      setRenaming(null);
    } catch { setActionError(true); } finally { setBusy(false); }
  };
  const unused = unusedConnections(list ?? []);
  const runCleanup = async () => {
    setBusy(true); setActionError(false);
    try {
      for (const c of unused) {
        await api.disconnect(c.id);
        setList((cur) => withoutConnection(cur ?? [], c.id));
      }
      setCleanup(false);
      void load();
    } catch { setActionError(true); } finally { setBusy(false); }
  };

  // 연결 방법에는 물음표를 두지 않는다: 아래 ‘자세한 연결 가이드 보기’와 같은 동작(2026-10-20).
  const how = (
    <Section title={t(k("how"))}>
      <Box sx={{ p: 1.75 }}>
        {/* 설정에는 요약 한 문단만 둔다. 앱별 단계는 아래 ‘자세한 연결 가이드 보기’(1.17.7 중복 정리). */}
        <Typography sx={{ fontSize: "0.9rem", lineHeight: 1.6 }}>{connectorName ? t(k("howSummaryNamed"), { brand, name: connectorName }) : t(k("howSummary"), { brand })}</Typography>
        {/* 1.18.0: 커넥터 이름을 넘긴 앱은 이름 칸에 넣을 이름도 복사하게 한다(화면 언어와 관계없이 같은 이름). */}
        {connectorName && (
          <>
            <Typography sx={{ fontSize: "0.75rem", fontWeight: 700, color: "text.secondary", mt: 1.5, mb: 0.75 }}>{t(k("connectorName"))}</Typography>
            <Stack direction="row" sx={{ alignItems: "center", gap: 1, p: 1, borderRadius: radius.item, border: 1, borderColor: "divider", bgcolor: "action.hover" }}>
              <Typography sx={{ flex: 1, minWidth: 0, fontFamily: "ui-monospace, Menlo, monospace", fontSize: "0.8rem", overflowWrap: "anywhere" }}>{connectorName}</Typography>
              <Button size="small" variant="outlined" onClick={copyName} sx={{ flexShrink: 0 }}>{nameCopied ? t(k("copied")) : t(k("copy"))}</Button>
            </Stack>
          </>
        )}
        <Typography sx={{ fontSize: "0.75rem", fontWeight: 700, color: "text.secondary", mt: 1.5, mb: 0.75 }}>{t(k("serverUrl"))}</Typography>
        <Stack direction="row" sx={{ alignItems: "center", gap: 1, p: 1, borderRadius: radius.item, border: 1, borderColor: "divider", bgcolor: "action.hover" }}>
          <Typography sx={{ flex: 1, minWidth: 0, fontFamily: "ui-monospace, Menlo, monospace", fontSize: "0.8rem", overflowWrap: "anywhere" }}>{mcpUrl}</Typography>
          <Button size="small" variant="outlined" onClick={copy} sx={{ flexShrink: 0 }}>{copied ? t(k("copied")) : t(k("copy"))}</Button>
        </Stack>
        <Button fullWidth variant="outlined" onClick={() => setGuide(true)} sx={{ mt: 1.5, borderStyle: "dashed" }}>{t(k("guideOpen"))}</Button>
      </Box>
    </Section>
  );

  const connected = (
    <Stack sx={{ gap: 1.5 }}>
      <Section title={t(k("connected"))} help={{ label: t(k("connectedHelp")), onClick: () => setInfo(true) }}>
        {loadError ? (
          <Alert severity="error" action={<Button color="inherit" size="small" onClick={retry}>{t("common.retry")}</Button>} sx={{ borderRadius: 0 }}>{t(k("loadFailed"))}</Alert>
        ) : list == null ? (
          <Box sx={{ p: 3, display: "flex", justifyContent: "center" }}><CircularProgress size={24} /></Box>
        ) : list.length === 0 ? (
          <Typography color="text.secondary" sx={{ p: 2.75, textAlign: "center", fontSize: "0.9rem" }}>{t(k("empty"))}</Typography>
        ) : (
          <Box sx={{ "& > * + *": { borderTop: 1, borderColor: "divider" } }}>
            {/* 한 번도 쓰지 않은 연결이 여러 개면(여기저기서 거듭 추가한 흔적) 한 번에 정리. */}
            {unused.length >= 2 && (
              <Box sx={{ p: 1.25 }}>
                <Button fullWidth variant="outlined" color="warning" onClick={() => { setActionError(false); setCleanup(true); }}>{t(k("cleanupUnused"), { n: unused.length })}</Button>
              </Box>
            )}
            {list.map((c) => (
              <Stack key={c.id} direction="row" sx={{ alignItems: "flex-start", gap: 1.5, p: 1.75 }}>
                <Logo name={c.clientName} />
                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Typography sx={{ fontWeight: 700, overflowWrap: "anywhere" }}>{connectionTitle(c)}</Typography>
                  {/* 어느 앱인지 한 줄. 제목과 같은 글자(예: ChatGPT)면 생략. */}
                  {c.kind === "oauth" && c.app && t(k(`app${c.app.charAt(0).toUpperCase()}${c.app.slice(1)}`)) !== connectionTitle(c) && (
                    <Typography variant="caption" color="text.secondary" sx={{ display: "block" }}>{t(k(`app${c.app.charAt(0).toUpperCase()}${c.app.slice(1)}`))}</Typography>
                  )}
                  <Typography variant="caption" color="text.secondary" sx={{ display: "block", wordBreak: "keep-all" }}>
                    {c.kind === "token" ? t(k("testToken")) : t(k("connectedAt"), { date: formatDateTime(c.createdAt, { lang }) })}
                    {" · "}
                    {c.lastUsedAt ? t(k("lastUsed"), { time: formatDateTime(c.lastUsedAt, { lang }) }) : t(k("neverUsed"))}
                  </Typography>
                  <Typography variant="caption" color="text.secondary" sx={{ display: "block" }}>{t(k("scopeAll"), { data })}</Typography>
                  {c.kind === "oauth" && api.rename && (
                    <Button size="small" onClick={() => { setActionError(false); setLabelDraft(c.label ?? ""); setRenaming(c); }} sx={{ mt: 0.5, ml: -1, minHeight: 28, py: 0, fontSize: "0.75rem" }}>{t(k("rename"))}</Button>
                  )}
                </Box>
                <Button size="small" color="error" variant="outlined" onClick={() => { setActionError(false); setPending(c); }} sx={{ flexShrink: 0, mt: 0.5 }}>{t(k("disconnect"))}</Button>
              </Stack>
            ))}
          </Box>
        )}
      </Section>
      {/* 목록 아래 안내 두 줄(tip1·tip2)은 뺐다: 데이터 범위는 동의 화면·가이드에, 확인 시점은 가이드 맨 위에 있다(2026-10-20 중복 정리). */}
    </Stack>
  );

  return (
    <Stack sx={{ gap: 2 }}>
      <Typography color="text.secondary" sx={{ fontSize: "0.92rem" }}>{t(k("lead"), { brand, data })}</Typography>
      {/* 휴대폰은 안내 먼저, 넓은 화면(md~)은 목록 왼쪽·안내 오른쪽(시안). */}
      <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" }, gap: 2, alignItems: "start" }}>
        <Box sx={{ order: { xs: 2, md: 1 }, minWidth: 0 }}>{connected}</Box>
        <Box sx={{ order: { xs: 1, md: 2 }, minWidth: 0 }}>{how}</Box>
      </Box>
      <AiConnectGuide open={guide} onClose={() => setGuide(false)} brand={brand} mcpUrl={mcpUrl} content={content} connectorName={connectorName} />
      <Dialog open={Boolean(pending)} onClose={() => !busy && setPending(null)} fullWidth maxWidth="xs">
        <DialogTitle>{t(k("disconnectTitle"))}</DialogTitle>
        <DialogContent>
          <DialogContentText>{t(k("disconnectBody"), { client: pending ? connectionTitle(pending) : "", brand })}</DialogContentText>
          {actionError && <Alert severity="error" sx={{ mt: 1.5 }}>{t(k("failed"))}</Alert>}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPending(null)} disabled={busy}>{t("common.cancel")}</Button>
          <Button color="error" variant="contained" onClick={() => void disconnect()} disabled={busy}>{t(k("disconnect"))}</Button>
        </DialogActions>
      </Dialog>
      <Dialog open={Boolean(renaming)} onClose={() => !busy && setRenaming(null)} fullWidth maxWidth="xs">
        <DialogTitle>{t(k("renameTitle"))}</DialogTitle>
        <DialogContent>
          <TextField label={t(k("labelField"))} value={labelDraft} onChange={(e) => setLabelDraft(e.target.value)} helperText={t(k("labelHelp"))} placeholder={renaming?.clientName}
            disabled={busy} fullWidth autoFocus margin="dense" slotProps={{ htmlInput: { maxLength: 60 } }}
            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); void rename(); } }} />
          {actionError && <Alert severity="error" sx={{ mt: 1.5 }}>{t(k("failed"))}</Alert>}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRenaming(null)} disabled={busy}>{t("common.cancel")}</Button>
          <Button variant="contained" onClick={() => void rename()} disabled={busy}>{t(k("save"))}</Button>
        </DialogActions>
      </Dialog>
      {/* 연결이 생기고 사라지는 규칙(2026-10-20): 여러 곳에서 추가해 같은 이름이 여러 줄일 때 헷갈리지 않게. */}
      <Dialog open={info} onClose={() => setInfo(false)} fullWidth maxWidth="xs">
        <DialogTitle>{t(k("connectedHelpTitle"))}</DialogTitle>
        <DialogContent>
          <Stack component="ul" sx={{ m: 0, pl: 2.5, gap: 1, "& li": { fontSize: "0.9rem", lineHeight: 1.6 } }}>
            <li>{t(k("connectedHelp1"))}</li>
            <li>{t(k("connectedHelp2"))}</li>
            <li>{t(k("connectedHelp3"), { max: maxConnections })}</li>
          </Stack>
        </DialogContent>
        <DialogActions><Button variant="contained" onClick={() => setInfo(false)}>{t(k("close"))}</Button></DialogActions>
      </Dialog>
      <Dialog open={cleanup} onClose={() => !busy && setCleanup(false)} fullWidth maxWidth="xs">
        <DialogTitle>{t(k("cleanupTitle"))}</DialogTitle>
        <DialogContent>
          <DialogContentText>{t(k("cleanupBody"), { n: unused.length })}</DialogContentText>
          {actionError && <Alert severity="error" sx={{ mt: 1.5 }}>{t(k("failed"))}</Alert>}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCleanup(false)} disabled={busy}>{t("common.cancel")}</Button>
          <Button color="warning" variant="contained" onClick={() => void runCleanup()} disabled={busy || unused.length === 0}>{t(k("cleanupRun"))}</Button>
        </DialogActions>
      </Dialog>
    </Stack>
  );
}

export type AiConsentProps = {
  brand: string;
  api: AiConnectApi;
  /** 주소의 req 값. */
  req: string | null;
  /** ‘다른 계정으로’: 로그아웃 후 같은 주소로 로그인하게 한다. */
  onSwitchAccount: () => void;
  /** 연결 수 한도 안내의 ‘AI 비서 연결로 가기’ 주소와 링크 컴포넌트. */
  settingsPath: string;
  linkComponent?: ElementType;
  /** 테스트용: 이동 함수(기본 window.location.assign). */
  navigate?: (url: string) => void;
  /** 앱마다 다른 문구(1.17.0). 권한 줄의 데이터 이름에 쓴다. */
  content?: AiConnectContent;
};

export function AiConsent({ brand, api, req, onSwitchAccount, settingsPath, linkComponent, navigate, content }: AiConsentProps) {
  const t = useCoreText();
  const lang = useCoreLanguage();
  const data = (content ?? defaultAiConnectContent[lang]).data;
  const [info, setInfo] = useState<AiConsentRequest | null>(null);
  const [error, setError] = useState<AiConnectErrorView | null>(isRequestId(req) ? null : { key: "invalid" });
  const [busy, setBusy] = useState(false);
  const [moving, setMoving] = useState(false);
  const [label, setLabel] = useState("");

  useEffect(() => {
    if (!isRequestId(req)) return;
    api.consentRequest(req).then((i) => { setInfo(i); setLabel(i.suggestedLabel ?? i.clientName); }, (e) => setError(aiConnectError(e)));
  }, [api, req]);

  const decide = async (approve: boolean) => {
    if (!isRequestId(req)) return;
    setBusy(true);
    try {
      const { redirect } = await api.decide(req, approve, approve ? cleanLabel(label) : undefined);
      setMoving(true);
      (navigate ?? ((u: string) => window.location.assign(u)))(redirect);
    } catch (e) { setError(aiConnectError(e)); } finally { setBusy(false); }
  };

  const card = { width: "100%", maxWidth: 440, mx: "auto", p: { xs: 2.25, sm: 3 }, borderRadius: radius.card };

  if (error) {
    const link = linkComponent ? { component: linkComponent, to: settingsPath } : { href: settingsPath };
    return (
      <Paper variant="outlined" sx={card}>
        <Stack sx={{ gap: 2 }}>
          <Typography component="h1" variant="h6" sx={{ textAlign: "center" }}>{t(k("consentTitle"), { brand })}</Typography>
          <Alert severity={error.key === "limit" ? "warning" : "error"}>{t(k(error.key), { max: error.max ?? 5 })}</Alert>
          {error.toSettings && <Button variant="contained" {...link}>{t(k("goSettings"))}</Button>}
        </Stack>
      </Paper>
    );
  }
  if (!info || moving) {
    return (
      <Stack sx={{ alignItems: "center", gap: 1.5, py: 6 }}>
        <CircularProgress size={28} />
        {moving && <Typography color="text.secondary">{t(k("moving"))}</Typography>}
      </Stack>
    );
  }
  return (
    <Paper variant="outlined" sx={card}>
      <Stack sx={{ gap: 2 }}>
        <Stack direction="row" sx={{ alignItems: "center", justifyContent: "center", gap: 1.75 }}>
          <Logo name={info.clientName} color="#D97757" />
          <Typography aria-hidden color="text.disabled" sx={{ fontSize: "1.25rem" }}>⇄</Typography>
          <Logo name={brand} />
        </Stack>
        <Typography component="h1" variant="h6" sx={{ textAlign: "center" }}>{t(k("consentTitle"), { brand })}</Typography>
        <Typography color="text.secondary" sx={{ textAlign: "center", fontSize: "0.92rem" }}>{t(k("consentLead"), { client: info.clientName, brand })}</Typography>
        <Box>
          <Typography sx={{ fontSize: "0.75rem", fontWeight: 700, color: "text.secondary", mb: 0.75 }}>{t(k("account"))}</Typography>
          <Stack direction="row" sx={(th) => ({ alignItems: "center", gap: 1.25, p: 1.25, borderRadius: radius.item, bgcolor: alpha(th.palette.primary.main, 0.06) })}>
            <Box aria-hidden sx={(th) => ({ width: 34, height: 34, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, color: "primary.main", bgcolor: alpha(th.palette.primary.main, 0.14) })}>
              {clientInitial(info.account.name)}
            </Box>
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Typography sx={{ fontSize: "0.9rem", overflowWrap: "anywhere" }}>{info.account.name}</Typography>
              {info.account.emailMasked && <Typography variant="caption" color="text.secondary">{info.account.emailMasked}</Typography>}
            </Box>
            <Button size="small" onClick={onSwitchAccount} disabled={busy}>{t(k("otherAccount"))}</Button>
          </Stack>
        </Box>
        <Box>
          <Typography sx={{ fontSize: "0.75rem", fontWeight: 700, color: "text.secondary", mb: 0.75 }}>{t(k("permissions"))}</Typography>
          {[info.scopes.includes("todos.read") || info.scopes.length === 0 ? "permRead" : null, info.scopes.includes("todos.write") ? "permWrite" : null].filter(Boolean).map((p) => (
            <Stack key={p} direction="row" sx={{ gap: 1, alignItems: "flex-start", fontSize: "0.9rem", py: 0.25 }}>
              <Typography aria-hidden sx={{ color: "success.main", fontWeight: 800 }}>✓</Typography>
              <Typography sx={{ fontSize: "0.9rem" }}>{t(k(p as string), { data })}</Typography>
            </Stack>
          ))}
        </Box>
        <TextField label={t(k("labelField"))} value={label} onChange={(e) => setLabel(e.target.value)} helperText={t(k("labelHelp"))} placeholder={info.clientName}
          disabled={busy} fullWidth size="small" slotProps={{ htmlInput: { maxLength: 60 } }} />
        <Typography variant="body2" color="text.secondary">
          {t(k("returnTo"))}: <Box component="b" sx={{ color: "text.primary" }}>{info.redirectHost}</Box>
        </Typography>
        {info.loopback && <Alert severity="warning">{t(k("loopbackWarn"))}</Alert>}
        <Stack direction="row" sx={{ gap: 1.25 }}>
          <Button fullWidth variant="outlined" size="large" disabled={busy} onClick={() => void decide(false)}>{t(k("deny"))}</Button>
          <Button fullWidth variant="contained" size="large" disabled={busy} onClick={() => void decide(true)}>{t(k("allow"))}</Button>
        </Stack>
        <Typography variant="caption" color="text.secondary" sx={{ textAlign: "center" }}>{t(k("consentFoot"))}</Typography>
      </Stack>
    </Paper>
  );
}
