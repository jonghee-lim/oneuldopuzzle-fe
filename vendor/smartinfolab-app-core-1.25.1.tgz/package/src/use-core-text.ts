/* app-core 화면 부품이 쓰는 번역 훅(1.10.0). 언어가 바뀌면 다시 그린다. 언어를 정하지 않은 앱에서는 늘 ko다. */
import { useCallback, useSyncExternalStore } from "react";
import { coreT, getCoreLanguage, subscribeCoreLanguage, type Language } from "./locale.ts";

export function useCoreLanguage(): Language {
  return useSyncExternalStore(subscribeCoreLanguage, getCoreLanguage, getCoreLanguage);
}

export function useCoreText() {
  const lang = useCoreLanguage();
  return useCallback((key: string, vars?: Record<string, string | number>) => coreT(key, vars, lang), [lang]);
}
