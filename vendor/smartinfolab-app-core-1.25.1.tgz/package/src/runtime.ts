/**
 * 웹/웹앱/앱 판별(공통 지침 ‘웹·웹앱·앱 분기 한 곳에서 관리’). 앱은 src/platform/runtime.ts에서만 다시 내보내고,
 * 페이지·컴포넌트는 직접 부르지 말고 앱의 useAppPolicy() 기능 값을 읽는다.
 * 설치형 앱은 Capacitor가 window.Capacitor를 넣어 준다. E2E는 testing/fake-ios.cjs로 같은 값을 넣어 앱 화면을 흉내 낸다.
 */
declare global {
  interface Window {
    Capacitor?: { isNativePlatform?: () => boolean; getPlatform?: () => string };
  }
}

/** 설치형 앱(Capacitor) 안에서 실행 중인지. */
export function isNativeApp(): boolean {
  try {
    if (window.Capacitor?.isNativePlatform) return window.Capacitor.isNativePlatform();
    const platform = window.Capacitor?.getPlatform?.();
    return platform === "ios" || platform === "android";
  } catch {
    return false;
  }
}

/** iOS 앱인지(키체인·위젯·APNs 같은 iOS 전용 기능). */
export function isIosApp(): boolean {
  try {
    return isNativeApp() && window.Capacitor?.getPlatform?.() === "ios";
  } catch {
    return false;
  }
}

/** 홈 화면에 추가한 웹앱(PWA)으로 실행 중인지. 설치형 앱과 구분한다. */
export function isStandaloneWeb(): boolean {
  try {
    return !isNativeApp() && (window.matchMedia("(display-mode: standalone)").matches
      || (navigator as Navigator & { standalone?: boolean }).standalone === true);
  } catch {
    return false;
  }
}
