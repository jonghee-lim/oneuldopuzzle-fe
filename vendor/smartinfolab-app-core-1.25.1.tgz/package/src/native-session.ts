/**
 * 네이티브 앱 로그인 세션. 기존 iOS를 유지하고 Android는 명시적으로 활성화한다.
 * 서버 /api/{app}/auth/native-session과 refresh token을 본문으로 주고받고, 토큰은 기기 보안 저장소에만 둔다.
 * 웹·웹앱은 쓰지 않는다. 서버 쪽은 앱마다 native-session 컨트롤러가 있어야 한다(공통 지침 ‘앱 전용 로그인 API’).
 */
import axios, { type AxiosInstance, type AxiosRequestConfig } from "axios";
import { isIosApp, isNativeApp } from "./runtime.ts";
import { coreT } from "./locale.ts";

export type NativeSessionConfig = {
  /** 서버 서비스 코드. 응답 사용자가 이 서비스가 아니면 저장하지 않는다. 예: ONEULDOIT */
  serviceCode: string;
  /** 기존 앱은 iOS만 유지하며 Android는 명시적으로 선택한다. */
  android?: boolean;
  /** 키체인 키 앞붙임. 예: oneuldoit-session_ */
  keyPrefix: string;
  /** 새로 설치했는지 알아보는 localStorage 키. 예: oneuldoit-native-install */
  installKey: string;
  /** native-session API 경로(끝 / 없이). 예: /api/oneuldoit/auth/native-session */
  endpoint: string;
  /** 접속 API 주소(VITE_API_URL). 서버마다 로그인을 따로 둔다. */
  apiUrl: string;
};

type LoginLike = { user: { id: string; serviceCode: string } };

const TOKEN = /^[A-Za-z0-9_-]{43}$/;
const terminalCodes = ["SESSION_EXPIRED", "SESSION_REFRESH_REUSED", "SESSION_ACCOUNT_DISABLED", "SESSION_SERVICE_MISMATCH"];

export function createNativeSession(config: NativeSessionConfig) {
  const enabled = () => config.android ? isNativeApp() : isIosApp();
  let initialized: Promise<void> | undefined;
  const key = "refresh:" + config.apiUrl;

  async function secureStorage() {
    if (!enabled()) throw new Error(coreT("appCore.native.storageUnavailable"));
    const { SecureStorage, KeychainAccess } = await import("@aparajita/capacitor-secure-storage");
    initialized ??= (async () => {
      await SecureStorage.setKeyPrefix(config.keyPrefix);
      await SecureStorage.setSynchronize(false);
      await SecureStorage.setDefaultKeychainAccess(KeychainAccess.whenUnlockedThisDeviceOnly);
      // 키체인은 앱을 지워도 남을 수 있다: 새로 설치한 앱이 이전 설치의 로그인을 되살리지 않게 한다.
      if (!localStorage.getItem(config.installKey)) {
        await SecureStorage.clear();
        localStorage.setItem(config.installKey, "1");
      }
    })().catch(() => { initialized = undefined; throw new Error(coreT("appCore.native.storageOpenFailed")); });
    await initialized;
    // Capacitor 프록시는 then을 포함한 임의 메서드를 가지므로 Promise 값으로 바로 돌려주지 않는다.
    return { secure: SecureStorage };
  }

  async function storedToken(): Promise<string | null> {
    const { secure } = await secureStorage();
    let stored: unknown = null;
    try {
      if ((await secure.keys(false)).includes(key)) stored = await secure.get(key, false, false);
    } catch (error) {
      if ((error as { code?: string }).code !== "invalidData") throw error;
      await secure.remove(key, false);
    }
    const token = typeof stored === "string" && TOKEN.test(stored) ? stored : null;
    if (stored !== null && token === null) await secure.remove(key, false);
    return token;
  }

  /** 이 기기에 앱 로그인이 저장되어 있는지(서버에 닿지 못할 때 로그인 화면 대신 다시 시도를 보일지 정한다). */
  async function hasCredential() {
    if (!enabled()) return false;
    try { return (await storedToken()) !== null; } catch { return false; }
  }

  async function clearCredential() { if (enabled()) await (await secureStorage()).secure.remove(key, false); }

  /** 앱의 세션 잠금 안에서 부른다. 토큰은 인증 상태 저장소나 브라우저 저장소에 넣지 않는다. */
  async function request<T extends LoginLike>(client: AxiosInstance, action: string, body: unknown,
    requestConfig: AxiosRequestConfig | undefined, check: () => void, expectedUser?: string) {
    const { secure } = await secureStorage();
    check();
    const refreshToken = await storedToken();
    check();
    const url = config.endpoint + "/" + action;
    if (!refreshToken && (action === "refresh" || action === "policy"))
      throw new axios.AxiosError(coreT("appCore.native.loginAgain"), "SESSION_EXPIRED");
    if (action === "logout") {
      await secure.remove(key, false);
      return client.post<T>(url, { refreshToken }, { ...requestConfig, withCredentials: false });
    }
    try {
      const response = await client.post<T & { refreshToken: string }>(url,
        { ...((body as object) ?? {}), refreshToken }, { ...requestConfig, withCredentials: false });
      const { refreshToken: next, ...login } = response.data;
      try {
        check();
        if (login.user.serviceCode !== config.serviceCode || (expectedUser && login.user.id !== expectedUser)
          || !TOKEN.test(next)) throw new Error(coreT("appCore.native.loginInvalid"));
        await secure.set(key, next, false, false);
        check();
      } catch (error) {
        await client.post(config.endpoint + "/logout", { refreshToken: next }, { withCredentials: false }).catch(() => {});
        await secure.remove(key, false);
        throw error;
      }
      return { ...response, data: login as unknown as T };
    } catch (error) {
      if (axios.isAxiosError(error) && terminalCodes.includes(error.response?.data?.code)) await secure.remove(key, false);
      throw error;
    }
  }

  return { secureStorage, hasCredential, clearCredential, request };
}
