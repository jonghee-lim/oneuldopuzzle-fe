import { isNativeApp } from "./runtime.ts";

/**
 * 웹·웹앱(홈 화면에 추가)의 새 버전 자동 새로고침(2026-10-24).
 * 홈 화면 웹앱은 며칠씩 메모리에 남아 예전 화면 코드로 계속 돌기 때문에, 배포 뒤 서버·화면이 어긋나 메뉴가 멈출 수 있다
 * (오늘DoIt 웹앱에서 확인, 완전히 닫았다 열면 정상). 화면으로 돌아올 때 배포된 index.html의 웹 묶음 파일 이름을
 * 지금 돌고 있는 것과 비교해 다르면 새로고침한다. 입력 창·대화상자가 열려 있으면 닫힐 때까지 미룬다.
 *
 * 설치형 앱(iOS·Android)은 웹 묶음이 앱 안에 들어 있어 스토어 업데이트로만 바뀌므로 아무 일도 하지 않는다
 * (앱 정책 값과 isNativeApp() 두 겹으로 막는다). 개발 서버·E2E처럼 /assets/ 묶음이 없는 페이지도 아무 일도 하지 않는다.
 */

/** 다른 웹 묶음으로 같은 새로고침을 반복하지 않는 시간(배포 직후 CDN이 예전·새 index.html을 섞어 줄 때 대비). */
export const WEB_UPDATE_RETRY_MS = 10 * 60 * 1000;
/** 화면으로 돌아올 때 확인하는 최소 간격. */
export const WEB_UPDATE_MIN_INTERVAL_MS = 60 * 1000;
/** 화면을 계속 띄워 둘 때 확인하는 간격. */
export const WEB_UPDATE_POLL_MS = 30 * 60 * 1000;
const ATTEMPT_KEY = "app-core-web-update-attempt";

/** Vite가 만든 시작 묶음(/assets/*.js) 경로들. 묶음이 없으면(개발 서버) null. */
export function buildScripts(srcs: Iterable<string | null | undefined>): string | null {
  const list = [...srcs].filter((src): src is string => !!src && /\/assets\/[^/?#]+\.js(?:[?#].*)?$/.test(src)).sort();
  return list.length ? list.join("|") : null;
}

/** index.html 글에서 type="module" 스크립트의 src를 뽑는다. */
export function htmlModuleScripts(html: string): string[] {
  const out: string[] = [];
  for (const tag of html.match(/<script\b[^>]*>/gi) ?? []) {
    if (!/\btype\s*=\s*["']?module["']?/i.test(tag)) continue;
    const src = /\bsrc\s*=\s*["']([^"']+)["']/i.exec(tag)?.[1];
    if (src) out.push(src);
  }
  return out;
}

/** 지금 페이지가 불러온 시작 묶음. */
export function currentBuild(doc: Pick<Document, "querySelectorAll"> = document): string | null {
  return buildScripts(Array.from(doc.querySelectorAll('script[type="module"][src]'), (el) => el.getAttribute("src")));
}

/** 입력 중이거나 대화상자·시트가 열려 있으면 새로고침을 미룬다. */
export function defaultBusy(doc: Document = document): boolean {
  const active = doc.activeElement;
  if (active?.matches?.('input, textarea, select, [contenteditable=""], [contenteditable="true"]')) return true;
  return !!doc.querySelector('[role="dialog"], [role="alertdialog"]');
}

export type WebUpdateOptions = {
  /** 앱 정책 값(웹·웹앱만 true). false면 아무 일도 하지 않는다. */
  enabled: boolean;
  /** 지금 새로고침하면 안 되는지(기본: 입력 중·대화상자 열림). */
  isBusy?: () => boolean;
  /** 테스트용 바꿔 끼우기. */
  fetchHtml?: () => Promise<string | null>;
  reload?: () => void;
  now?: () => number;
  storage?: Pick<Storage, "getItem" | "setItem"> | null;
  doc?: Document;
  win?: Window;
  /** 바쁠 때 다시 볼 간격(기본 2초). */
  busyRetryMs?: number;
};

async function fetchIndexHtml(win: Window): Promise<string | null> {
  const response = await win.fetch(new URL("/", win.location.href).href, { cache: "no-store", credentials: "same-origin" });
  if (!response.ok || !/text\/html/i.test(response.headers.get("content-type") ?? "")) return null;
  return response.text();
}

function sessionStore(win: Window): Pick<Storage, "getItem" | "setItem"> | null {
  try { return win.sessionStorage; } catch { return null; }
}

/**
 * 화면 복귀(visibilitychange·pageshow)와 30분마다 새 버전을 확인하고, 다르면 바쁘지 않을 때 새로고침한다. 해제 함수를 돌려준다.
 */
export function watchWebUpdate(options: WebUpdateOptions): () => void {
  const noop = () => {};
  if (!options.enabled || isNativeApp()) return noop;
  const doc = options.doc ?? document;
  const win = options.win ?? window;
  const running = currentBuild(doc);
  if (!running) return noop;
  const now = options.now ?? Date.now;
  const isBusy = options.isBusy ?? (() => defaultBusy(doc));
  const fetchHtml = options.fetchHtml ?? (() => fetchIndexHtml(win));
  const reload = options.reload ?? (() => win.location.reload());
  const storage = options.storage === undefined ? sessionStore(win) : options.storage;
  const busyRetryMs = options.busyRetryMs ?? 2000;
  let stopped = false;
  let checking = false;
  let lastCheck = now();
  let pending: string | null = null;
  let waitTimer = 0;

  const attempted = (build: string) => {
    try {
      const saved = JSON.parse(storage?.getItem(ATTEMPT_KEY) ?? "null") as { build?: string; at?: number } | null;
      return saved?.build === build && typeof saved.at === "number" && now() - saved.at < WEB_UPDATE_RETRY_MS;
    } catch { return false; }
  };
  const apply = () => {
    win.clearTimeout(waitTimer);
    if (stopped || !pending || doc.visibilityState !== "visible") return;
    if (isBusy()) { waitTimer = win.setTimeout(apply, busyRetryMs); return; }
    try { storage?.setItem(ATTEMPT_KEY, JSON.stringify({ build: pending, at: now() })); } catch { /* 저장 못 해도 새로고침은 한다 */ }
    stopped = true;
    reload();
  };
  const check = async (force = false) => {
    if (stopped || checking || doc.visibilityState !== "visible") return;
    if (pending) { apply(); return; }
    if (!force && now() - lastCheck < WEB_UPDATE_MIN_INTERVAL_MS) return;
    checking = true;
    lastCheck = now();
    try {
      const html = await fetchHtml();
      const deployed = html ? buildScripts(htmlModuleScripts(html)) : null;
      if (deployed && deployed !== running && !attempted(deployed)) { pending = deployed; apply(); }
    } catch { /* 오프라인·서버 오류는 다음 복귀 때 다시 본다 */ }
    finally { checking = false; }
  };
  const onVisible = () => { if (doc.visibilityState === "visible") void check(); };
  const onPageShow = (event: PageTransitionEvent) => { if (event.persisted) void check(true); };
  doc.addEventListener("visibilitychange", onVisible);
  win.addEventListener("pageshow", onPageShow);
  const poll = win.setInterval(() => void check(), WEB_UPDATE_POLL_MS);
  return () => {
    stopped = true;
    win.clearTimeout(waitTimer);
    win.clearInterval(poll);
    doc.removeEventListener("visibilitychange", onVisible);
    win.removeEventListener("pageshow", onPageShow);
  };
}
