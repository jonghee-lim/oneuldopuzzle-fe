/*
 * AI 비서 연결 앱별 가이드 문구(1.16.1, 2026-10-19 시안 oneuldoit-fe/docs/ai-connect-guide-mockup.html 컨펌본).
 * 요금제·메뉴 이름은 2026-10 기준이다. AI 앱 화면이 바뀌면 이 파일만 고친다.
 * 1.17.7(2026-10-20 중복 정리): 탭은 Claude · ChatGPT(웹 방법 + 휴대폰 한 줄) 두 개(개발자용 Claude Code·Codex 안내는 뺐다). "확인했습니다"는 맨 위 notice에만 둔다.
 * 앱마다 다른 값(1.17.0, 모든 앱 공통으로 쓰도록): {{brand}} 앱 이름, {{server}} MCP 서버 이름(주소 끝, 예: oneuldoit), {{data}} AI가 다루는 데이터(예: 할 일·일정),
 * {{name}} 커스텀 커넥터 이름 칸에 넣을 이름(1.18.0: 앱이 connectorName을 넘기면 그 값, 아니면 {{brand}}. 그때 {{server}}도 connectorName),
 * {{ask}} 짧은 말 예시(예: 오늘 할 일 보여줘). 말해 보기 예시(examples)도 앱이 넘긴다(AiConnectContent). 여기 examples는 넘기지 않았을 때의 기본값이다.
 * 문장 안의 <b>…</b>(강조)와 <span class='path'>…</span>(메뉴 경로)만 쓴다 — 화면은 이 두 표시만 해석한다(HTML로 넣지 않는다).
 */
import type { Language } from "./locale.ts";

export type GuideFaq = [string, string];
export type GuideRoute = { req: string; steps: string[]; urlStep?: number; warn?: string; trouble: GuideFaq[] };
export type GuideApp = GuideRoute & { voice?: string; voiceOk?: boolean };
/** ChatGPT: 웹 방법 하나 + 휴대폰 앱 한 줄(1.17.7). */
export type ChatGptGuide = GuideApp & { mobile: string };
export type AiConnectGuideText = {
  title: string; notice: string; open: string; close: string; need: string; howTo: string; use: string; trouble: string; voiceTitle: string; copy: string;
  /** 1.18.0: 커넥터 이름을 넘긴 앱은 이름·주소 복사 버튼을 함께 둔다. */
  copyName: string; copyUrl: string;
  mobileTitle: string;
  examples: string[]; common: GuideFaq[]; claude: GuideApp; chatgpt: ChatGptGuide;
};

export const aiConnectGuide: Record<Language, AiConnectGuideText> = {
  "ko": {
    "title": "AI 앱 연결 가이드",
    "notice": "2026년 10월에 확인한 방법입니다. AI 앱 화면은 바뀔 수 있습니다.",
    "open": "앱별 자세한 연결 가이드",
    "close": "닫기",
    "need": "필요한 것",
    "howTo": "연결하기",
    "use": "연결한 뒤 이렇게 말해 보십시오",
    "trouble": "잘 안 될 때",
    "voiceTitle": "음성으로 쓰기",
    "copy": "복사",
    "copyName": "이름 복사",
    "copyUrl": "주소 복사",
    "mobileTitle": "휴대폰 앱",
    "examples": [],
    "common": [
      [
        "AI가 내 다른 정보도 봅니까?",
        "AI 앱은 내 계정의 {{data}}만 보고 바꿀 수 있습니다. 비밀번호는 AI 앱에 전달되지 않습니다."
      ]
    ],
    "claude": {
      "req": "웹(claude.ai)이나 데스크톱 앱에서 한 번 추가하면 휴대폰 앱에서도 함께 쓸 수 있습니다.",
      "steps": [
        "claude.ai(또는 Claude 데스크톱 앱)에서 왼쪽 아래 프로필 → <span class='path'>설정</span>을 엽니다.",
        "<span class='path'>커넥터</span> 메뉴에서 <span class='path'>커스텀 커넥터 추가</span>를 누릅니다.",
        "이름에 <b>{{name}}</b>, 원격 MCP 서버 URL에 아래 주소를 붙여 넣고 <span class='path'>추가</span>를 누릅니다.",
        "목록에 생긴 {{name}}의 <span class='path'>연결</span>을 누르면 {{brand}} 로그인 화면이 열립니다. 로그인한 뒤 <span class='path'>허용</span>을 누릅니다.",
        "새 채팅 입력창의 <span class='path'>검색 및 도구</span>(슬라이더 모양) 메뉴에서 {{name}}이 켜져 있는지 확인합니다."
      ],
      "trouble": [
        [
          "‘커스텀 커넥터 추가’가 안 보입니다",
          "조직(Team·Enterprise)에서 막아 두었거나 소유자가 아직 추가하지 않은 경우일 수 있습니다. 요금제에 따라 커스텀 커넥터 수가 제한될 수 있어, 이미 다른 커넥터가 있으면 먼저 지워야 할 수 있습니다."
        ],
        [
          "로그인 후 연결이 안 됩니다",
          "{{brand}} 동의 화면에서 ‘허용’을 눌렀는지 확인하고, 커넥터 목록에서 다시 ‘연결’을 눌러 보십시오."
        ]
      ],
      "voice": "Claude 음성 대화에서도 쓸 수 있습니다.",
      "voiceOk": true
    },
    "chatgpt": {
      "req": "<b>PC 브라우저의 chatgpt.com</b>에서 추가합니다.",
      "steps": [
        "PC 브라우저로 <b>chatgpt.com</b>에 로그인하고 왼쪽 위 메뉴 또는 설정에서 <span class='path'>플러그인</span> 화면(chatgpt.com/plugins)을 엽니다.",
        "오른쪽 위 <span class='path'>추가 ▾</span>를 눌러 <span class='path'>사용자 지정 MCP 서버 추가</span>를 고릅니다.",
        "이름에 <b>{{server}}</b>(영문), 연결은 <span class='path'>서버 URL</span>을 고르고 아래 주소를 붙여 넣습니다. 인증은 <b>OAuth</b> 그대로 두고 고급 OAuth 설정은 건드리지 않습니다.",
        "추가하면 ‘{{server}} 연결’ 창이 뜹니다. <span class='path'>{{server}} 연결 ↗</span>을 누릅니다.",
        "새 창에서 {{brand}}에 로그인하고 <span class='path'>허용</span>을 누릅니다. ChatGPT로 돌아오면 플러그인 › 설치됨에 {{server}} 항목이 보입니다.",
        "새 채팅 입력창의 <span class='path'>+</span>에서 <b>{{server}}</b> 항목을 골라 말합니다."
      ],
      "urlStep": 2,
      "warn": "이름은 영문만 써 주십시오(한글은 빠집니다).",
      "trouble": [
        [
          "‘사용자 지정 MCP 서버 추가’가 안 보입니다",
          "요금제나 계정에 따라 이 메뉴가 없을 수 있습니다. 회사·학교에서 쓰는 ChatGPT(Business·Enterprise·Edu)라면 그 회사의 ChatGPT 관리자가 허용해야 합니다."
        ],
        [
          "연결했는데 대화에서 쓰이지 않습니다",
          "입력창 + 에서 {{server}} 항목을 고르고, ‘{{server}}, {{ask}}’처럼 이름을 넣어 말해 보십시오."
        ]
      ],
      "voice": "음성 모드에서는 직접 추가한 MCP({{server}})가 동작하지 않을 수 있으니, {{data}} 조회·등록은 글로 입력하는 채팅에서 해 주십시오.",
      "voiceOk": false,
      "mobile": "웹에서 추가하면 같은 계정의 휴대폰 ChatGPT 앱에도 보입니다."
    }
  },
  "en": {
    "title": "AI app setup guide",
    "notice": "These steps were confirmed in October 2026. AI app screens may change.",
    "open": "Detailed setup guide by app",
    "close": "Close",
    "need": "What you need",
    "howTo": "How to connect",
    "use": "Then try saying",
    "trouble": "Troubleshooting",
    "voiceTitle": "Using voice",
    "copy": "Copy",
    "copyName": "Copy name",
    "copyUrl": "Copy URL",
    "mobileTitle": "Mobile app",
    "examples": [],
    "common": [
      [
        "Can the AI see my other data?",
        "AI apps can only see and change your own {{data}}. Your password is never shared."
      ]
    ],
    "claude": {
      "req": "Add it once on the web (claude.ai) or desktop app and you can use it in the mobile app too.",
      "steps": [
        "On claude.ai (or the Claude desktop app), open your profile at the bottom left → <span class='path'>Settings</span>.",
        "Under <span class='path'>Connectors</span>, choose <span class='path'>Add custom connector</span>.",
        "Name it <b>{{name}}</b>, paste the URL below as the remote MCP server URL, and tap <span class='path'>Add</span>.",
        "Tap <span class='path'>Connect</span> next to {{name}}. Sign in to {{brand}} and tap <span class='path'>Allow</span>.",
        "In a new chat, check that {{name}} is on in the <span class='path'>Search and tools</span> menu."
      ],
      "trouble": [
        [
          "I don't see ‘Add custom connector’",
          "Your organization (Team or Enterprise) may have turned it off, or the owner may not have added it yet. Your plan may limit custom connectors, so you may need to remove another one first."
        ],
        [
          "It doesn't connect after signing in",
          "Make sure you tapped ‘Allow’ on the {{brand}} page, then tap ‘Connect’ again in the connector list."
        ]
      ],
      "voice": "It also works in Claude voice conversations.",
      "voiceOk": true
    },
    "chatgpt": {
      "req": "Add it on <b>chatgpt.com in a PC browser</b>.",
      "steps": [
        "Sign in to <b>chatgpt.com</b> in a PC browser and open the <span class='path'>Plugins</span> page (chatgpt.com/plugins).",
        "Tap <span class='path'>Add ▾</span> at the top right → <span class='path'>Add custom MCP server</span>.",
        "Name it <b>{{server}}</b> (letters only), choose <span class='path'>Server URL</span>, and paste the URL below. Keep authentication as <b>OAuth</b> and leave advanced OAuth settings alone.",
        "In the ‘Connect {{server}}’ dialog, tap <span class='path'>Connect {{server}} ↗</span>.",
        "Sign in to {{brand}} in the new window and tap <span class='path'>Allow</span>. {{server}} then appears under Plugins › Installed.",
        "In a new chat, pick <b>{{server}}</b> from <span class='path'>+</span> and ask."
      ],
      "urlStep": 2,
      "warn": "Use English letters for the name.",
      "trouble": [
        [
          "I don't see ‘Add custom MCP server’",
          "Depending on your plan or account, this menu may not be available. On a company or school ChatGPT plan (Business, Enterprise, Edu), your organization's ChatGPT admin must allow it."
        ],
        [
          "Connected, but ChatGPT doesn't use it",
          "Pick {{server}} from + and mention it, like ‘{{server}}, {{ask}}’."
        ]
      ],
      "voice": "Custom MCP servers like {{server}} may not work in voice mode, so use a typed chat to view or add {{data}}.",
      "voiceOk": false,
      "mobile": "Once added on the web, it also shows in the ChatGPT mobile app with the same account."
    }
  },
  "ja": {
    "title": "AI アプリ連携ガイド",
    "notice": "2026年10月に確認した方法です。AI アプリの画面は変わることがあります。",
    "open": "アプリ別の詳しい連携ガイド",
    "close": "閉じる",
    "need": "必要なもの",
    "howTo": "連携する",
    "use": "連携したら話しかけてみましょう",
    "trouble": "うまくいかないとき",
    "voiceTitle": "音声で使う",
    "copy": "コピー",
    "copyName": "名前をコピー",
    "copyUrl": "アドレスをコピー",
    "mobileTitle": "スマホアプリ",
    "examples": [],
    "common": [
      [
        "AI はほかの情報も見ますか?",
        "AI アプリが見たり変更したりできるのは自分の{{data}}だけです。パスワードは渡されません。"
      ]
    ],
    "claude": {
      "req": "Web(claude.ai)かデスクトップアプリで一度追加すると、スマホアプリでも使えます。",
      "steps": [
        "claude.ai(または Claude デスクトップアプリ)で左下のプロフィール → <span class='path'>設定</span>を開きます。",
        "<span class='path'>コネクタ</span>で<span class='path'>カスタムコネクタを追加</span>を押します。",
        "名前に<b>{{name}}</b>、リモート MCP サーバー URL に下のアドレスを貼り付けて<span class='path'>追加</span>を押します。",
        "一覧の{{name}} の<span class='path'>連携</span>を押し、{{brand}} にログインして<span class='path'>許可</span>を押します。",
        "新しいチャットの<span class='path'>検索とツール</span>メニューで{{name}} がオンか確認します。"
      ],
      "trouble": [
        [
          "「カスタムコネクタを追加」が見えない",
          "組織(Team・Enterprise)で無効になっているか、オーナーがまだ追加していない可能性があります。プランによってカスタムコネクタの数が制限される場合があるため、ほかのコネクタがあれば先に削除が必要なことがあります。"
        ],
        [
          "ログイン後に連携されない",
          "{{brand}} の画面で「許可」を押したか確認し、コネクタ一覧でもう一度「連携」を押してください。"
        ]
      ],
      "voice": "Claude の音声会話でも使えます。",
      "voiceOk": true
    },
    "chatgpt": {
      "req": "<b>PC ブラウザの chatgpt.com</b> で追加します。",
      "steps": [
        "PC ブラウザで <b>chatgpt.com</b> にログインし、<span class='path'>プラグイン</span>画面(chatgpt.com/plugins)を開きます。",
        "右上の<span class='path'>追加 ▾</span> → <span class='path'>カスタム MCP サーバーを追加</span>を選びます。",
        "名前は <b>{{server}}</b>(英字)、接続は<span class='path'>サーバー URL</span>を選んで下のアドレスを貼り付けます。認証は <b>OAuth</b> のまま、詳細設定は変更しません。",
        "「{{server}} を接続」画面で<span class='path'>{{server}} を接続 ↗</span>を押します。",
        "新しいウィンドウで{{brand}} にログインし<span class='path'>許可</span>を押します。プラグイン › インストール済みに {{server}} が表示されます。",
        "新しいチャットの<span class='path'>+</span>から <b>{{server}}</b> を選んで話しかけます。"
      ],
      "urlStep": 2,
      "warn": "名前は英字のみにしてください。",
      "trouble": [
        [
          "「カスタム MCP サーバーを追加」が見えない",
          "プランやアカウントによってはこのメニューがない場合があります。会社・学校の ChatGPT（Business・Enterprise・Edu）では、その組織の ChatGPT 管理者の許可が必要です。"
        ],
        [
          "接続したのに使ってくれない",
          "+ から {{server}} を選び、「{{server}}、{{ask}}」のように名前を入れて話しかけてください。"
        ]
      ],
      "voice": "音声モードでは自分で追加した MCP({{server}})が動作しない場合があるため、{{data}}の確認・登録は文字のチャットで行ってください。",
      "voiceOk": false,
      "mobile": "Web で追加すると、同じアカウントのスマホの ChatGPT アプリにも表示されます。"
    }
  }
};

/** 문장을 강조·메뉴 경로·일반 글자 조각으로 나눈다(화면이 조각별로 그린다). */
export type GuidePart = { kind: "text" | "bold" | "path"; text: string };
/** 앱마다 다른 값. brand 외에는 없으면 그 자리 표시를 그대로 둔다. */
export type GuideVars = { brand: string; server?: string; data?: string; ask?: string; name?: string };

export function guideParts(line: string, vars: string | GuideVars): GuidePart[] {
  const v: GuideVars = typeof vars === "string" ? { brand: vars } : vars;
  let s = line;
  // {{name}}이 없으면 앱 이름(1.17까지와 같음).
  s = s.split("{{name}}").join(v.name ?? v.brand);
  for (const key of ["brand", "server", "data", "ask"] as const) if (v[key] != null) s = s.split(`{{${key}}}`).join(v[key] as string);
  const parts: GuidePart[] = [];
  const re = /<b>(.*?)<\/b>|<span class='path'>(.*?)<\/span>/g;
  let last = 0;
  for (let m = re.exec(s); m; m = re.exec(s)) {
    if (m.index > last) parts.push({ kind: "text", text: s.slice(last, m.index) });
    parts.push(m[1] != null ? { kind: "bold", text: m[1] } : { kind: "path", text: m[2] });
    last = re.lastIndex;
  }
  if (last < s.length) parts.push({ kind: "text", text: s.slice(last) });
  return parts;
}
