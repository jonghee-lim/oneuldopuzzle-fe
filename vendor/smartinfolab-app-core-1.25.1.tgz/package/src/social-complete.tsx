import { useEffect, useRef, useState, type ElementType } from "react";
import { Alert, Button, CircularProgress, Stack, Typography } from "@mui/material";
import { LABEL, socialCompleteMessage, takeCompletionFragment, type SocialProviderName } from "./social-complete-model.ts";
import { useCoreText } from "./use-core-text.ts";
export { LABEL, SOCIAL_NETWORK_MESSAGE, socialCompleteMessage, socialReturnError, takeCompletionFragment, type SocialProviderName } from "./social-complete-model.ts";

/*
 * 간편 로그인 완료 화면 표준(1.9.0). 카카오·Apple·Google에서 돌아온 화면의 틀과 실패 안내를 한 곳에서 정한다.
 * 기준: 달 리듬 Apple·카카오·Google 완료 화면.
 * - 화면은 한 번만 처리하고(StrictMode 두 번 실행 방지), 주소의 인증 값(#state 등)을 읽은 즉시 주소에서 지운다.
 * - 실패 안내는 서버 안내(같은 이메일 계정 있음·재인증 필요 등)를 그대로 보인다. 서버에 닿지 못했으면 연결 안내,
 *   앱이 던진 Error는 그 문구, 나머지만 기본 문구다. 고정 문구로 덮어 서버 안내를 감추지 않는다.
 * - 수단별 완료 요청·로그인 처리·연결·재인증 뒤 이동은 앱이 run으로 넘긴다(앱 흐름은 그대로).
 */
export type SocialCompletePageProps = {
  provider: SocialProviderName;
  /** 완료 처리. 성공하면 앱이 직접 이동하고, 실패하면 throw한다. */
  run: (input: { fragment: string; params: URLSearchParams }) => Promise<void>;
  /** 실패 뒤 정리(대기 정보·계정 작업 기억 지우기). 실패해도 안내는 보인다. */
  onError?: (error: unknown) => Promise<void> | void;
  /** 로그인한 상태(연결·재인증)면 내 계정, 아니면 로그인 화면으로 돌아간다. */
  signedIn: boolean;
  loginPath: string;
  accountPath: string;
  /** 앱 라우터 Link(react-router). */
  linkComponent: ElementType;
  /** 제목. 없으면 "<수단> 계정 확인". */
  title?: string;
  /** 앱 고유 실패 문구 함수가 필요할 때만. 없으면 socialCompleteMessage. */
  errorMessage?: (error: unknown) => string;
};

export function SocialCompletePage(props: SocialCompletePageProps) {
  const { provider, signedIn, loginPath, accountPath, linkComponent, title } = props;
  const t = useCoreText();
  const [error, setError] = useState("");
  const started = useRef(false);
  const latest = useRef(props);
  // 렌더 중 ref를 쓰지 않는다: 아래 시작 효과보다 먼저 실행되도록 앞에 둔다.
  useEffect(() => { latest.current = props; });
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    const input = takeCompletionFragment();
    void (async () => {
      const { run, onError, errorMessage } = latest.current;
      try { await run(input); }
      catch (e) {
        try { await onError?.(e); } catch { /* 정리 실패는 안내를 막지 않는다 */ }
        setError(errorMessage ? errorMessage(e) : socialCompleteMessage(e, provider));
      }
    })();
  }, [provider]);
  return <Stack sx={{ maxWidth: 420, mx: "auto", px: 2, py: 5, gap: 3, alignItems: "center" }}>
    <Typography component="h1" variant="h5">{title ?? t("appCore.social.title", { provider: LABEL[provider] })}</Typography>
    {error
      ? <><Alert severity="error" sx={{ width: "100%" }}>{error}</Alert>
        <Button component={linkComponent} to={signedIn ? accountPath : loginPath} variant="contained" replace>{signedIn ? t("appCore.social.toAccount") : t("appCore.social.toLogin")}</Button></>
      : <><CircularProgress aria-label={t("appCore.social.checking", { provider: LABEL[provider] })} /><Typography>{signedIn ? t("appCore.social.completingCheck") : t("appCore.social.completingLogin")}</Typography></>}
  </Stack>;
}
