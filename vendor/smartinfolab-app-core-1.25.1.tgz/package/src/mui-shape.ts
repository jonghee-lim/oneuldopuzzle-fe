import type { Components, Theme } from "@mui/material/styles";

/**
 * 스마트인포랩 MUI 모서리 표준(2026-10-12, 배포 앱 오늘DoIt 실측 기준).
 *
 * - 값은 항상 px 문자열이다. sx·styleOverrides에 숫자를 쓰면 theme.shape 배수(sx)나
 *   그대로 px(styleOverrides)로 해석이 갈려 앱마다 둥글기가 달라진다.
 * - 화면에서는 `borderRadius: radius.card`처럼 이 토큰만 쓴다.
 */
export const radius = {
  /** 화면의 큰 덩어리: Card, outlined Paper, Dialog, 하단 시트 */
  card: "16px",
  /** 카드 안의 칸·목록 묶음·Alert·Menu */
  item: "12px",
  /** 버튼·입력칸·토글 */
  control: "10px",
  /** 작은 배지·썸네일 */
  small: "8px",
  /** 칩·알약 모양 */
  pill: "999px",
} as const;

export type RadiusToken = keyof typeof radius;

/** 테마 shape 표준. sx에서 숫자 둥글기를 쓰지 않는 전제로 MUI 기본 부품의 둥글기를 맞춘다. */
export const standardShape = { borderRadius: 12 } as const;

/**
 * 테마 components에 펼쳐 넣는 모서리 표준.
 * `createTheme({ shape: standardShape, components: { ...radiusComponents, ...앱별 } })`
 */
export const radiusComponents = {
  MuiCard: { styleOverrides: { root: { borderRadius: radius.card } } },
  MuiPaper: { styleOverrides: { outlined: { borderRadius: radius.card } } },
  MuiDialog: { styleOverrides: { paper: { borderRadius: radius.card } } },
  MuiDrawer: { styleOverrides: { anchorBottom: { "& .MuiDrawer-paper": { borderTopLeftRadius: radius.card, borderTopRightRadius: radius.card } } } },
  MuiAlert: { styleOverrides: { root: { borderRadius: radius.item } } },
  MuiMenu: { styleOverrides: { paper: { borderRadius: radius.item } } },
  MuiButton: { styleOverrides: { root: { borderRadius: radius.control } } },
  MuiToggleButton: { styleOverrides: { root: { borderRadius: radius.control } } },
  MuiOutlinedInput: { styleOverrides: { root: { borderRadius: radius.control } } },
  MuiFilledInput: { styleOverrides: { root: { borderTopLeftRadius: radius.control, borderTopRightRadius: radius.control } } },
  MuiChip: { styleOverrides: { root: { borderRadius: radius.pill } } },
} satisfies Components<Omit<Theme, "components">>;
