import { useState, type ElementType, type ReactNode } from "react";
import { Alert, Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Stack, TextField, Typography } from "@mui/material";
import { alpha } from "@mui/material/styles";
import type { SocialProvider } from "./account-action.ts";
import { LoginMethodDialogs, type LoginMethodsController } from "./account-ui.tsx";
import { PasswordResetDialog, type PasswordResetMessages, type RecoveryClient } from "./password-reset.tsx";
import { SettingsGroup, SettingsRow } from "./settings-list.tsx";
import { radius } from "./mui-shape.ts";
import { PersonOutlineRounded, LogoutRounded, AccountCircleOutlined, MailOutlineRounded } from "./account-icons.tsx";
import { ProviderMark } from "./social-login.tsx";
import { isLastLocal, localRowCaption, localRowState, localRowValue, loginMethodKinds, loginMethodsText, providerRowCaption, providerRowValue, showsSingleMethodTip, visibleProviderRows, type MethodKind } from "./account-model.ts";
import { useCoreText } from "./use-core-text.ts";

export { SettingsGroup, SettingsRow, type SettingsRowProps } from "./settings-list.tsx";
// 순수 계산(hasNickname·loginMethodsText 등)은 ./account-model.ts에 있다(빠른 새로고침 규칙상 컴포넌트 파일과 나눈다).
export { PasswordResetDialog, type PasswordResetMessages, type RecoveryClient } from "./password-reset.tsx";

export type AccountLayoutProps = {
  /** 로그인한 계정. null이면 계정 없이 쓰는 화면(guest 카드 + appSections만). */
  account: null | {
    name?: string | null;
    /** 별명이 정해졌는지(기본 소셜 이름은 false). hasNickname()으로 계산할 수 있다. */
    named: boolean;
    email?: string | null;
    /** 로그인 수단 조회 전 둘째 줄을 짐작할 내부 로그인 ID(kakao_·apple_·google_). 없으면 "로그인 정보를 불러오는 중". */
    loginId?: string | null;
  };
  /** 계정 없이 쓸 때 프로필 카드 자리: 제목·설명·버튼(로그인). */
  guest?: { title: ReactNode; description?: ReactNode; action?: ReactNode };
  /** useLoginMethods 결과. 로그인 수단 행·연결/해제·이메일 변경 대화상자에 쓴다. */
  login?: LoginMethodsController;
  /** 로그인 수단 첫 행 이름(기본 ‘이메일 · 비밀번호’). 자녀·학생·옛 아이디 계정의 ‘아이디/비밀번호’ 표시용. */
  localLabel?: string;
  /** 프로필 카드 둘째 줄을 앱이 직접 정할 때(예: login 없이 쓰는 자녀 계정). 주면 로그인 수단 문구 대신 쓴다. */
  methodsText?: ReactNode;
  /** 소셜 연결 대화상자 안내 문구(앱별 ‘기존 회원 정보는 그대로 유지됩니다’ 등). */
  linkDescription?: ReactNode;
  /** 앱이 지원하는 소셜 수단(기본 카카오·Apple·Google). Google은 서버 설정이 켜졌거나 연결됐을 때만 보인다. */
  providers?: readonly SocialProvider[];
  nickname?: {
    save: (name: string) => Promise<unknown>;
    maxLength?: number;
    /** 버튼·기본 제목에 쓰는 이름(기본 ‘별명’; 예: ‘닉네임’·‘이름’). */
    noun?: string;
    /** 대화상자 제목. 기본 ‘별명 정하기’/‘별명 변경’. */
    dialogTitle?: string;
    label?: string;
    helperText?: ReactNode;
    /** 저장 뒤 위에 보일 안내(없으면 안내 없이 닫는다). */
    savedNotice?: string;
    errorMessage?: (error: unknown) => string;
  };
  /** 화면 맨 위 안내(Alert들). 로그인 수단 안내·재인증 오류는 틀이 그린다. */
  notices?: ReactNode;
  /** 로그인 수단과 계정 묶음 사이 앱 고유 묶음(기록·알림 등). */
  appSections?: ReactNode;
  /** 이메일·비밀번호 계정이면 ‘비밀번호 재설정’ 행 + 공통 대화상자(공통 /api/auth/recovery/*). */
  passwordReset?: { client: RecoveryClient; serviceCode: string; onDone: () => void; onSessionCleared?: () => void; messages?: PasswordResetMessages; errorMessage?: (error: unknown) => string };
  logout?: { onConfirm: () => void; busy?: boolean; confirmText: ReactNode };
  /** 회원 탈퇴 링크(앱 라우터 Link + 주소). */
  withdrawal?: { to: string; linkComponent: ElementType };
  title?: ReactNode;
  maxWidth?: number | Partial<Record<"xs" | "sm" | "md" | "lg" | "xl", number>>;
  /** 화면 아래 여백(theme spacing). */
  pb?: number;
};

const PROVIDERS: readonly SocialProvider[] = ["KAKAO", "APPLE", "GOOGLE"];
// 시안 숫자(px)는 rem으로 옮긴다: 17px 이름, 15px 로그아웃, 13px 탈퇴 링크, 30px 아이콘.
const nameFont = "1.0625rem";

/**
 * 내 계정 공통 틀(2026-10-15, 시안 account-unified). 순서는 틀이 정하고(accountSections), 앱 고유 행은 appSections로 넣는다.
 * 제목 → 안내 → 프로필 카드 → 로그인 수단 → 앱 칸 → 계정(이메일 변경·비밀번호 재설정) → 로그아웃 → 회원 탈퇴.
 * 색은 MUI 테마 primary를 쓴다.
 */
export function AccountLayout(props: AccountLayoutProps) {
  const t = useCoreText();
  const { account, guest, login, localLabel = t("appCore.account.localLabel"), methodsText, linkDescription, providers = PROVIDERS, nickname, notices, appSections, passwordReset, logout, withdrawal, title = t("appCore.account.title"), maxWidth = 680, pb } = props;
  const [nicknameValue, setNicknameValue] = useState<string | null>(null);
  const [nicknameBusy, setNicknameBusy] = useState(false), [nicknameError, setNicknameError] = useState("");
  const [savedNotice, setSavedNotice] = useState("");
  const [resetOpen, setResetOpen] = useState(false), [confirmOut, setConfirmOut] = useState(false);
  const data = login?.data;
  const methods = loginMethodsText(data, account?.loginId);
  const loadingText = account?.loginId == null ? t("appCore.account.loadingMethods") : "";
  const noun = nickname?.noun ?? t("appCore.account.nickname");

  async function saveNickname() {
    if (!nickname) return;
    const value = (nicknameValue ?? "").trim();
    if (!value) return;
    setNicknameBusy(true); setNicknameError("");
    try {
      await nickname.save(value);
      setNicknameValue(null);
      if (nickname.savedNotice) setSavedNotice(nickname.savedNotice);
    } catch (e) {
      setNicknameError(nickname.errorMessage ? nickname.errorMessage(e) : (nickname.noun ? t("appCore.account.nounSaveFailed", { noun }) : t("appCore.account.nicknameSaveFailed")));
    } finally {
      setNicknameBusy(false);
    }
  }

  const avatar = (
    <Box aria-hidden sx={(t) => ({ width: 52, height: 52, flexShrink: 0, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", bgcolor: alpha(t.palette.primary.main, 0.14), color: "primary.main" })}>
      <PersonOutlineRounded sx={{ fontSize: "1.875rem" }} />
    </Box>
  );

  return (
    <Stack sx={{ gap: 1.5, maxWidth, mx: "auto", width: "100%", pb }}>
      <Typography component="h1" variant="h5">{title}</Typography>
      {savedNotice && <Alert severity="success" onClose={() => setSavedNotice("")}>{savedNotice}</Alert>}
      {notices}
      {login?.notice && <Alert severity="success" onClose={() => login.setNotice("")} sx={{ wordBreak: "keep-all", overflowWrap: "anywhere" }}>{login.notice}</Alert>}
      {login?.resumeError && <Alert severity="error" sx={{ wordBreak: "keep-all", overflowWrap: "anywhere" }}>{login.resumeError}</Alert>}

      {/* ① 프로필 카드: 별명(없으면 ‘별명 없음’) / 로그인 방식 / 이메일, 오른쪽 별명 버튼 */}
      <Box sx={{ p: 2, borderRadius: radius.item, bgcolor: "action.hover" }}>
        <Stack direction="row" sx={{ alignItems: "center", gap: 1.75 }}>
          {avatar}
          <Stack sx={{ flex: 1, minWidth: 0 }}>
            {account ? (
              <>
                <Typography sx={{ fontSize: nameFont, fontWeight: 700, color: account.named ? "text.primary" : "text.secondary", overflowWrap: "anywhere" }}>{account.named ? account.name : t("appCore.account.noNickname")}</Typography>
                {/* 둘째 줄: 앱이 methodsText를 주면 그 글자, 조회가 끝났으면 수단 아이콘 줄(글자는 보조 기술용), 조회 전에는 짐작 글자. 1.16.2 */}
                {methodsText != null ? (
                  <Typography variant="body2" color="text.secondary" sx={{ wordBreak: "keep-all" }}>{methodsText}</Typography>
                ) : data ? (
                  <Stack direction="row" role="img" aria-label={methods ? t("appCore.account.methodsLogin", { methods }) : undefined} sx={{ gap: 0.5, mt: 0.25, mb: 0.25, flexWrap: "wrap" }}>
                    {loginMethodKinds(data).map((kind) => <MethodIcon key={kind} provider={kind === "EMAIL" ? undefined : kind} size="sm">{kind === "EMAIL" ? <MailOutlineRounded sx={{ fontSize: "0.8125rem" }} /> : <ProviderMark provider={kind.toLowerCase() as "kakao" | "apple" | "google"} size={12} />}</MethodIcon>)}
                  </Stack>
                ) : (
                  <Typography variant="body2" color="text.secondary" sx={{ wordBreak: "keep-all" }}>{methods ? t("appCore.account.methodsLogin", { methods }) : loadingText}</Typography>
                )}
                {account.email && <Typography variant="body2" color="text.secondary" sx={{ overflowWrap: "anywhere" }}>{account.email}</Typography>}
              </>
            ) : (
              <>
                <Typography sx={{ fontSize: nameFont, fontWeight: 700 }}>{guest?.title}</Typography>
                {guest?.description && <Typography variant="body2" color="text.secondary" sx={{ wordBreak: "keep-all" }}>{guest.description}</Typography>}
              </>
            )}
          </Stack>
          {account && nickname && (
            <Button size="small" sx={{ minHeight: 44, flexShrink: 0 }} onClick={() => { setNicknameValue(account.named ? (account.name ?? "") : ""); setNicknameError(""); }}>
              {account.named ? t("appCore.account.nounChange", { noun }) : t("appCore.account.nounSet", { noun })}
            </Button>
          )}
        </Stack>
        {!account && guest?.action && <Box sx={{ mt: 1.5 }}>{guest.action}</Box>}
      </Box>

      {/* ② 로그인 수단 */}
      {account && login && (
        <>
          {login.methods.isError && (
            <Alert severity="error" action={<Button onClick={() => void login.methods.refetch()}>{t("appCore.account.retry")}</Button>}>{t("appCore.account.methodsLoadFailed")}</Alert>
          )}
          <SettingsGroup title={t("appCore.account.loginMethods")}>
            {(() => {
              // 이메일·비밀번호 행(1.15.0): 사용 중(계정 이메일) / 설정(소셜 전용·설정 가능 → 이메일 로그인 설정 시트) / 없음.
              // 1.25.0: 다른 수단이 있고 앱이 remove를 넘기면 ‘사용 중 ›’(해제 시트), 유일한 수단이면 둘째 줄에 해제 불가 안내.
              const state = data ? localRowState({ local: data.local, canSetup: login.canSetPassword, canRemove: login.canRemovePassword }) : undefined;
              const icon = <MethodIcon><MailOutlineRounded sx={{ fontSize: "1.125rem" }} /></MethodIcon>;
              if (!state || !data) return <SettingsRow icon={icon} label={localLabel} chevron={false} />;
              const caption = localRowCaption(state, { email: data.email, hasRemoveApi: !!login.api.password?.remove, manageable: data.manageable, last: isLastLocal(data) }) || undefined;
              if (state === "setup") return <SettingsRow icon={icon} label={localLabel} caption={caption} trailing={<RowTag kind="action">{localRowValue(state)}</RowTag>} onClick={login.openPassword} />;
              if (state === "removable") return <SettingsRow icon={icon} label={localLabel} caption={caption} trailing={<RowTag kind="on">{localRowValue(state)}</RowTag>} onClick={login.openRemove} />;
              return <SettingsRow icon={icon} label={localLabel} caption={caption} trailing={<RowTag kind={state === "inUse" ? "on" : "off"}>{localRowValue(state)}</RowTag>} chevron={false} />;
            })()}
            {visibleProviderRows(login.rows, providers).map((row) => {
              const icon = <MethodIcon provider={row.target}><ProviderMark provider={row.target.toLowerCase() as "kakao" | "apple" | "google"} size={18} /></MethodIcon>;
              if (!data) return <SettingsRow key={row.target} icon={icon} label={row.label} chevron={false} />;
              const kind = row.connected ? "on" : row.available ? "action" : "off";
              return (
                <SettingsRow key={row.target} icon={icon} label={row.label} caption={providerRowCaption(row, data.accounts) || undefined}
                  trailing={<RowTag kind={kind}>{providerRowValue(row)}</RowTag>} disabled={row.connected ? row.last : !row.available} onClick={row.open} />
              );
            })}
          </SettingsGroup>
          {showsSingleMethodTip(data) && (
            <Typography variant="caption" color="text.secondary" sx={{ px: 0.5, mt: -0.5, wordBreak: "keep-all" }}>{t("appCore.account.singleMethodTip")}</Typography>
          )}
        </>
      )}

      {/* ③ 앱 칸 */}
      {appSections}

      {/* ④ 계정 */}
      {/* 이메일 로그인 연결은 위 로그인 수단의 이메일/비밀번호 행(연결하기)에서 연다. */}
      {account && login && (login.canChangeEmail || (passwordReset && data?.local)) && (
        <SettingsGroup title={t("appCore.account.group")}>
          {login.canChangeEmail && <SettingsRow label={t("appCore.emailChange.title")} caption={t("appCore.account.changeEmailCaption")} onClick={login.openEmail} />}
          {passwordReset && data?.local && <SettingsRow label={t("appCore.reset.title")} caption={t("appCore.account.resetCaption")} onClick={() => setResetOpen(true)} />}
        </SettingsGroup>
      )}

      {/* ⑤ 로그아웃 · ⑥ 회원 탈퇴 */}
      {account && (logout || withdrawal) && (
        <Stack sx={{ alignItems: "center", gap: 1, mt: 2 }}>
          {logout && (
            // 앱 색으로 연하게 채운 버튼: 위 목록과 구분되고 누를 곳이 바로 보인다.
            <Button disableElevation fullWidth startIcon={<LogoutRounded />} disabled={logout.busy} onClick={() => setConfirmOut(true)}
              sx={(t) => ({ minHeight: 52, borderRadius: radius.item, fontSize: "0.9375rem", fontWeight: 800, color: "primary.main", bgcolor: alpha(t.palette.primary.main, 0.1), "&:hover": { bgcolor: alpha(t.palette.primary.main, 0.16) } })}>
              {logout.busy ? t("appCore.account.loggingOut") : t("appCore.account.logout")}
            </Button>
          )}
          {withdrawal && (
            <Button component={withdrawal.linkComponent} to={withdrawal.to} size="small" disableRipple
              sx={{ minHeight: 44, px: 1.5, fontSize: "0.8125rem", fontWeight: 400, color: "text.secondary", textDecoration: "underline", textUnderlineOffset: "3px", textDecorationColor: (t) => alpha(t.palette.text.secondary, 0.4), "&:hover": { bgcolor: "transparent", textDecoration: "underline", color: "text.primary" } }}>
              {t("appCore.account.withdraw")}
            </Button>
          )}
        </Stack>
      )}

      {login && account && <LoginMethodDialogs controller={login} currentEmail={account.email} linkDescription={linkDescription} />}

      {resetOpen && passwordReset && (
        <PasswordResetDialog client={passwordReset.client} serviceCode={passwordReset.serviceCode} messages={passwordReset.messages} errorMessage={passwordReset.errorMessage}
          onSessionCleared={passwordReset.onSessionCleared}
          onClose={(done) => { setResetOpen(false); if (done) passwordReset.onDone(); }} />
      )}

      {logout && (
        <Dialog open={confirmOut} onClose={() => !logout.busy && setConfirmOut(false)} fullWidth maxWidth="xs">
          <DialogTitle>{t("appCore.account.logoutConfirm")}</DialogTitle>
          <DialogContent>
            <Typography variant="body2">{logout.confirmText}</Typography>
          </DialogContent>
          <DialogActions>
            <Button disabled={logout.busy} onClick={() => setConfirmOut(false)}>{t("common.cancel")}</Button>
            <Button variant="contained" disabled={logout.busy} onClick={() => { setConfirmOut(false); logout.onConfirm(); }}>{t("appCore.account.logout")}</Button>
          </DialogActions>
        </Dialog>
      )}

      {nickname && (
        <Dialog open={nicknameValue !== null} onClose={() => !nicknameBusy && setNicknameValue(null)} fullWidth maxWidth="xs">
          <DialogTitle>{nickname.dialogTitle ?? (account?.named ? t("appCore.account.nounChange", { noun }) : t("appCore.account.nounSet", { noun }))}</DialogTitle>
          <DialogContent>
            {/* 입력 칸 이름은 테두리 안 라벨 대신 칸 위에 따로 둔다(글자와 겹침 방지). */}
            <Typography component="label" htmlFor="nickname-input" variant="subtitle2" sx={{ display: "block", mb: 0.75 }}>{nickname.label ?? t("appCore.account.nickname")}</Typography>
            <TextField id="nickname-input" autoFocus fullWidth value={nicknameValue ?? ""} onChange={(e) => setNicknameValue(e.target.value)}
              slotProps={{ htmlInput: { maxLength: nickname.maxLength ?? 30 } }} error={!!nicknameError} helperText={nicknameError || nickname.helperText} />
          </DialogContent>
          <DialogActions>
            <Button disabled={nicknameBusy} onClick={() => setNicknameValue(null)}>{t("common.cancel")}</Button>
            <Button variant="contained" disabled={nicknameBusy || !(nicknameValue ?? "").trim()} onClick={() => void saveNickname()}>{t("common.save")}</Button>
          </DialogActions>
        </Dialog>
      )}
    </Stack>
  );
}

/** 로그인 방법 행 왼쪽 둥근 아이콘(수단 브랜드 색: 카카오 노랑, Apple 검정·흰 글자, Google 흰 바탕 테두리, 이메일 앱 색). */
function MethodIcon({ provider, size = "md", children }: { provider?: MethodKind; size?: "sm" | "md"; children: ReactNode }) {
  const px = size === "sm" ? "1.375rem" : "2rem";
  return (
    <Box sx={(th) => ({
      width: px, height: px, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
      ...(provider === "KAKAO" ? { bgcolor: "#FEE500", color: "#191919" }
        : provider === "APPLE" ? { bgcolor: th.palette.mode === "dark" ? "#fff" : "#000", color: th.palette.mode === "dark" ? "#000" : "#fff" }
        : provider === "GOOGLE" ? { bgcolor: "#fff", border: 1, borderColor: "#dadce0" }
        : { bgcolor: alpha(th.palette.primary.main, 0.12), color: "primary.main" }),
    })}>
      {children}
    </Box>
  );
}

/** 행 오른쪽 표시: on(사용 중·연결됨 배지) · action(설정·연결하기, 버튼 모양 글자 — 행 전체가 버튼) · off(없음·준비 중). */
function RowTag({ kind, children }: { kind: "on" | "action" | "off"; children: ReactNode }) {
  if (kind === "off") return <Typography variant="body2" color="text.secondary">{children}</Typography>;
  return (
    <Box component="span" sx={(th) => ({
      fontSize: "0.8125rem", fontWeight: 600, lineHeight: 1.2, px: 1.25, py: 0.5, borderRadius: radius.control, whiteSpace: "nowrap",
      ...(kind === "on"
        ? { color: "success.main", bgcolor: alpha(th.palette.success.main, 0.12) }
        : { color: "primary.main", border: 1, borderColor: alpha(th.palette.primary.main, 0.4) }),
    })}>
      {children}
    </Box>
  );
}

/**
 * 헤더 오른쪽 ‘내 계정’ 아이콘(사람 모양, 2026-10-15 공통화). 이동 경로는 앱 정책 accountPath를 넘긴다.
 * 기준: 달 리듬 MainLayout(회색 24px)·오늘DoIt PersonalHeader(앱 색 28px). 모양은 같고 색·크기만 tone·size로 고른다.
 */
export function AccountHeaderButton({ to, linkComponent, current, tone = "primary", size = "large", edge = false }: {
  to: string;
  linkComponent: ElementType;
  /** 지금 내 계정 화면이면 aria-current="page". */
  current?: boolean;
  tone?: "primary" | "muted";
  size?: "medium" | "large";
  /** 헤더 오른쪽 끝에 붙일 때 바깥 여백을 줄인다. */
  edge?: boolean;
}) {
  const t = useCoreText();
  const label = t("appCore.account.title");
  return (
    <IconButton component={linkComponent} to={to} aria-label={label} title={label} aria-current={current ? "page" : undefined}
      sx={{ width: 44, height: 44, flexShrink: 0, mr: edge ? -1 : undefined, color: tone === "primary" ? "primary.main" : "text.secondary" }}>
      <AccountCircleOutlined sx={{ fontSize: size === "large" ? "1.75rem" : "1.5rem" }} />
    </IconButton>
  );
}
