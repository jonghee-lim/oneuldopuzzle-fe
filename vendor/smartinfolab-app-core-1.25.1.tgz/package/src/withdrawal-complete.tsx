/*
 * 회원 탈퇴 완료 공통 화면(1.13.0). 로그인 공통 틀과 같은 폭·가운데 정렬로 제목 → 본문 → 이동 버튼만 그린다.
 * 사용자 결정 2026-10-19: 앱마다 달랐던 완료 처리(완료 화면·로그인 알림·alert·토스트)를 이 화면 하나로 통일한다.
 * 앱 고유 한 줄(예: 기기에 저장한 기록 안내)은 note로 넣고, 그 밖의 문구는 앱이 따로 쓰지 않는다.
 */
import type { ElementType, ReactNode } from "react";
import { Box, Button, Stack, Typography } from "@mui/material";
import { useCoreText } from "./use-core-text.ts";

export type WithdrawalCompleteAction = {
  /** 버튼 이름. 표준은 home(앱 첫 화면 `/`, 로그인 필수 앱은 첫 화면이 로그인). login은 예외용. 사용자 결정 2026-10-19. */
  label?: "login" | "home";
  /** 앱 라우터 Link + 주소 */
  to?: string;
  linkComponent?: ElementType;
  /** 해시 라우터 등은 href */
  href?: string;
  onClick?: () => void;
};

export type WithdrawalCompleteProps = {
  appName: string;
  action: WithdrawalCompleteAction;
  /** 앱 고유 한 줄(선택) */
  note?: ReactNode;
  logo?: ReactNode;
  maxWidth?: number;
};

export function WithdrawalComplete({ appName, action, note, logo, maxWidth = 440 }: WithdrawalCompleteProps) {
  const t = useCoreText();
  const { label = "login", to, linkComponent, href, onClick } = action;
  const buttonProps = to && linkComponent ? { component: linkComponent, to } : href ? { href } : {};
  return (
    <Box sx={{ width: "100%", maxWidth, mx: "auto" }} data-withdrawal-complete>
      <Stack sx={{ alignItems: "center", gap: 2, textAlign: "center" }}>
        {logo}
        <Typography component="h1" variant="h5" sx={{ fontWeight: 700, wordBreak: "keep-all" }}>{t("appCore.withdrawalComplete.title")}</Typography>
        <Typography sx={{ wordBreak: "keep-all" }}>{t("appCore.withdrawalComplete.body", { app: appName })}</Typography>
        {note && <Typography variant="body2" color="text.secondary" sx={{ wordBreak: "keep-all" }}>{note}</Typography>}
        <Button variant="contained" size="large" fullWidth onClick={onClick} {...buttonProps} sx={{ minHeight: 48, mt: 1 }}>
          {t(label === "home" ? "appCore.withdrawalComplete.toHome" : "appCore.withdrawalComplete.toLogin")}
        </Button>
      </Stack>
    </Box>
  );
}
