// 로그인 화면 칸 순서(LoginLayout과 단위 테스트가 함께 쓴다). JSX 없이 둬서 Node 테스트로 바로 돌린다.
export type LoginSection = "header" | "guestAction" | "retention" | "notices" | "social" | "emailDivider" | "emailForm" | "links" | "collapsed" | "footer";

/** 보일 칸을 위→아래 순서로 돌려준다(화면과 단위 테스트가 같은 순서를 쓴다). */
export function loginSections(p: Partial<Record<Exclude<LoginSection, "header" | "emailDivider">, unknown>>): LoginSection[] {
  const has = (v: unknown) => v !== undefined && v !== null && v !== false && v !== "";
  const out: LoginSection[] = ["header"];
  if (has(p.guestAction)) out.push("guestAction");
  if (has(p.collapsed)) {
    if (has(p.notices)) out.push("notices");
    out.push("collapsed");
  } else {
    if (has(p.retention)) out.push("retention");
    if (has(p.notices)) out.push("notices");
    if (has(p.social)) out.push("social");
    if (has(p.emailForm)) out.push("emailDivider", "emailForm");
    if (has(p.links)) out.push("links");
  }
  if (has(p.footer)) out.push("footer");
  return out;
}
