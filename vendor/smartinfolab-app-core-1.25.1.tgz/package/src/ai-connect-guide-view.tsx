import { useState } from "react";
import { Alert, Box, Button, IconButton, Stack, Tab, Tabs, Typography } from "@mui/material";
import { alpha } from "@mui/material/styles";
import { radius } from "./mui-shape.ts";
import { useCoreLanguage } from "./use-core-text.ts";
import { SheetDialog } from "./sheet-dialog.tsx";
import { aiConnectGuide, guideParts, type GuideFaq, type GuideVars } from "./ai-connect-guide.ts";
import { mcpServerName, type AiConnectContent } from "./ai-connect-model.ts";

/*
 * AI 비서 연결 앱별 자세한 가이드(1.16.1, 1.17.7 중복 정리). 휴대폰은 아래 시트, 그 밖은 가운데 창(SheetDialog).
 * 탭: Claude · ChatGPT(웹 방법 + 휴대폰 한 줄). 맨 위 notice에 확인 시점을 한 번만 둔다.
 * 각 탭: 필요한 것 → 연결하기(주소·명령 복사) → 주의 → 음성 → 말해 보기 → 잘 안 될 때.
 */
type AppKey = "claude" | "chatgpt";

function Line({ text, brand }: { text: string; brand: GuideVars }) {
  return (
    <>
      {guideParts(text, brand).map((p, i) =>
        p.kind === "bold" ? <b key={i}>{p.text}</b>
        : p.kind === "path" ? <Box key={i} component="span" sx={{ bgcolor: "action.hover", borderRadius: "6px", px: 0.75, py: "1px", fontWeight: 700, fontSize: "0.82rem" }}>{p.text}</Box>
        : <span key={i}>{p.text}</span>)}
    </>
  );
}

function CopyBox({ value, label }: { value: string; label: string }) {
  const [done, setDone] = useState(false);
  return (
    <Stack direction="row" sx={{ alignItems: "center", gap: 1, mt: 1, p: 1, borderRadius: radius.item, border: 1, borderColor: "divider", bgcolor: "action.hover" }}>
      <Typography sx={{ flex: 1, minWidth: 0, fontFamily: "ui-monospace, Menlo, monospace", fontSize: "0.78rem", overflowWrap: "anywhere" }}>{value}</Typography>
      <Button size="small" variant="outlined" sx={{ flexShrink: 0 }}
        onClick={() => void navigator.clipboard?.writeText(value).then(() => { setDone(true); setTimeout(() => setDone(false), 2000); }, () => undefined)}>
        {done ? "✓" : label}
      </Button>
    </Stack>
  );
}

const Section = ({ children }: { children: React.ReactNode }) => (
  <Typography component="h3" sx={{ fontSize: "0.8rem", fontWeight: 800, color: "text.secondary", mt: 2, mb: 0.75 }}>{children}</Typography>
);

/** connectorName(1.18.0): 커스텀 커넥터 이름 칸에 넣을 이름(예: TodaysDoIt). 넘기면 화면 언어와 관계없이 이 이름을 안내하고 이름 복사 버튼을 둔다. 없으면 1.17까지와 같다. */
export type AiConnectGuideProps = { open: boolean; onClose: () => void; brand: string; mcpUrl: string; content: AiConnectContent; connectorName?: string };

function Steps({ steps, urlStep, copyValue, copyLabel, brand, name }: { steps: string[]; urlStep?: number; copyValue: string; copyLabel: string; brand: GuideVars; name?: { value: string; label: string } }) {
  return (
    <Stack component="ol" sx={{ listStyle: "none", m: 0, p: 0, gap: 1.25 }}>
      {steps.map((s, i) => (
        <Stack key={i} component="li" direction="row" sx={{ gap: 1.25 }}>
          <Box aria-hidden sx={{ flexShrink: 0, width: 24, height: 24, borderRadius: "50%", bgcolor: "primary.main", color: "primary.contrastText", fontSize: "0.78rem", fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center", mt: "1px" }}>{i + 1}</Box>
          <Box sx={{ flex: 1, minWidth: 0, fontSize: "0.88rem", lineHeight: 1.6 }}>
            <Line text={s} brand={brand} />
            {i === urlStep && name && <CopyBox value={name.value} label={name.label} />}
            {i === urlStep && <CopyBox value={copyValue} label={copyLabel} />}
          </Box>
        </Stack>
      ))}
    </Stack>
  );
}

export function AiConnectGuide({ open, onClose, brand: brandName, mcpUrl, content, connectorName }: AiConnectGuideProps) {
  const g = aiConnectGuide[useCoreLanguage()];
  const brand: GuideVars = { brand: brandName, server: connectorName ?? mcpServerName(mcpUrl), data: content.data, ask: content.ask, name: connectorName };
  const examples = content.examples.length ? content.examples : g.examples;
  const [app, setApp] = useState<AppKey>("claude");
  const body = app === "claude" ? g.claude : g.chatgpt;
  const faq: GuideFaq[] = [...body.trouble, ...g.common];
  return (
    <SheetDialog open={open} onClose={onClose} labelledBy="ai-guide-title">
      <Box sx={{ p: { xs: 2, sm: 3 }, pt: { xs: 1.5, sm: 2.5 } }}>
        <Stack direction="row" sx={{ alignItems: "center", justifyContent: "space-between", mb: 1 }}>
          <Typography id="ai-guide-title" component="h2" sx={{ fontWeight: 800, fontSize: "1.05rem" }}>{g.title}</Typography>
          <IconButton aria-label={g.close} onClick={onClose} size="small">✕</IconButton>
        </Stack>
        <Typography color="text.secondary" sx={{ fontSize: "0.78rem", lineHeight: 1.5, mb: 1.25 }}>{g.notice}</Typography>
        <Tabs value={app} onChange={(_, v: AppKey) => setApp(v)} variant="fullWidth" sx={{ minHeight: 40, "& .MuiTab-root": { minHeight: 40, textTransform: "none", fontWeight: 700 } }}>
          <Tab value="claude" label="Claude" />
          <Tab value="chatgpt" label="ChatGPT" />
        </Tabs>
        <Section>{g.need}</Section>
        <Box sx={(t) => ({ p: 1.25, borderRadius: radius.item, bgcolor: alpha(t.palette.primary.main, 0.08), fontSize: "0.86rem", lineHeight: 1.6 })}><Line text={body.req} brand={brand} /></Box>
        <>
            <Section>{g.howTo}</Section>
            <Steps steps={body.steps} urlStep={body.urlStep ?? 2} copyValue={mcpUrl} copyLabel={connectorName ? g.copyUrl : g.copy} brand={brand}
              name={connectorName ? { value: connectorName, label: g.copyName } : undefined} />
            {body.warn && <Alert severity="warning" sx={{ mt: 1.5, fontSize: "0.82rem" }}><Line text={body.warn} brand={brand} /></Alert>}
            {app === "chatgpt" && (
              <>
                <Section>{g.mobileTitle}</Section>
                <Typography sx={{ fontSize: "0.86rem", lineHeight: 1.6 }}><Line text={g.chatgpt.mobile} brand={brand} /></Typography>
              </>
            )}
            {body.voice && (
              <>
                <Section>{g.voiceTitle}</Section>
                <Alert severity={body.voiceOk ? "success" : "info"} sx={{ fontSize: "0.84rem" }}><Line text={body.voice} brand={brand} /></Alert>
              </>
            )}
        </>
        {examples.length > 0 && <Section>{g.use}</Section>}
        <Stack direction="row" sx={{ flexWrap: "wrap", gap: 0.75 }}>
          {examples.map((e) => <Box key={e} sx={{ border: 1, borderColor: "divider", borderRadius: 999, px: 1.25, py: 0.5, fontSize: "0.8rem" }}>“{e}”</Box>)}
        </Stack>
        <Section>{g.trouble}</Section>
        {faq.map(([q, a]) => (
          <Box key={q} component="details" sx={{ borderTop: 1, borderColor: "divider", py: 1, fontSize: "0.86rem", "& summary": { cursor: "pointer", fontWeight: 700 } }}>
            <summary><Line text={q} brand={brand} /></summary>
            <Typography color="text.secondary" sx={{ mt: 0.75, fontSize: "0.84rem", lineHeight: 1.6 }}><Line text={a} brand={brand} /></Typography>
          </Box>
        ))}
      </Box>
    </SheetDialog>
  );
}
