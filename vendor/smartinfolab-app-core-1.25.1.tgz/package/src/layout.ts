/**
 * 앱 공통 레이아웃 기준(공통 지침 ‘화면 공통 기준’). 화면 크기 구간·본문 최대 너비·바깥 여백·안전 영역·1단/2단 전환·
 * 채우기(한 줄 더보기)는 여기서 정한다. 앱은 src/theme/layout.ts에서 이 값을 다시 내보내고 앱 고유 값(줄 높이, 달력 칸 등)만 더한다.
 *
 * 확인 기준 크기: 아이폰 375~440, 갤럭시 360, 아이패드 11인치 834×1210(Air 820×1180), 13인치 1032×1376,
 * 안드로이드 태블릿 800×1280, PC 1280~1920 (세로·가로 모두).
 */

/** 화면 너비 구간(px). 11인치 세로(820~834)는 1단, 13인치 세로(1032)·모든 가로 태블릿은 2단이다. */
export const widths = {
  /** 이 너비부터 태블릿 여백(24px)을 쓴다. */
  tablet: 600,
  /** 이 너비부터 2단으로 나눈다. */
  twoColumn: 1000,
} as const;

const minWidth = (px: number) => `@media (min-width: ${px}px)`;

/** sx 안에서 쓰는 미디어 조건. 새 구간이 필요하면 여기에 먼저 추가한다. */
export const media = {
  tablet: minWidth(widths.tablet),
  twoColumn: minWidth(widths.twoColumn),
  coarsePointer: "@media (hover: none) and (pointer: coarse)",
  reducedMotion: "@media (prefers-reduced-motion: reduce)",
} as const;

/** 본문·헤더가 함께 쓰는 폭과 여백(px). */
export const page = {
  maxWidth: 1328,
  paddingX: { phone: 16, tablet: 24 },
  paddingTop: { phone: 12, tablet: 20 },
  sectionGap: { phone: 12, tablet: 18 },
  /** 앱 틀 밖 전체 화면의 최소 높이: 안전 영역(#root 여백, index.css)을 뺀 화면 높이. */
  fullHeight: "calc(100dvh - env(safe-area-inset-top) - env(safe-area-inset-bottom))",
} as const;

/** 앱 틀의 고정 높이(px). 안전 영역은 따로 더한다. */
export const frame = {
  headerHeight: { phone: 56, tablet: 64 },
  bottomNavHeight: { phone: 64, tablet: 70 },
  bottomNavMaxWidth: 640,
  floatingButtonGap: 16,
} as const;

/** 한 줄 더보기 높이(px). */
export const moreRowHeight = 46;

/** MUI 테마 구간. sx의 { xs, sm, md }가 위 widths와 같은 기준으로 나뉘게 한다. */
export const muiBreakpoints = { xs: 0, sm: widths.tablet, md: widths.twoColumn, lg: 1200, xl: 1536 } as const;

/** MUI sx 반응형 값 도우미: 휴대폰 값과 태블릿(600px~) 값. */
export function byWidth<T>(phone: T, tablet: T) {
  return { xs: phone, sm: tablet };
}

/**
 * 카드 높이에 들어가는 항목 수를 정한다. 항목이 넘치면 마지막 한 줄을 ‘더보기’로 쓴다.
 * 넘치지 않으면 더보기 줄 없이 모두 보인다.
 */
export function fitRows(available: number, rowHeight: number, total: number, moreHeight: number = moreRowHeight) {
  if (total <= 0 || rowHeight <= 0 || available <= 0) return { visible: 0, hidden: Math.max(total, 0) };
  const all = Math.floor(available / rowHeight);
  if (all >= total) return { visible: total, hidden: 0 };
  const visible = Math.max(0, Math.floor((available - moreHeight) / rowHeight));
  return { visible, hidden: total - visible };
}
