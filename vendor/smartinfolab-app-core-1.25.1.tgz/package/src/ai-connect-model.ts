/*
 * AI 비서 연결(1.15.0) 화면 밖 규칙: 서버 오류 → 안내 키, 마지막 사용 표시, 이름 첫 글자. React 없이 테스트한다(tests/ai-connect.test.mjs).
 * 서버 계약: docs/oneuldoit-ai-connect-impl.md(smartinfolab-api) 2.7 — 410 REQUEST_EXPIRED, 409 CONNECTION_LIMIT{max}.
 */
/** app(1.17.0): 돌아가는 주소로 가늠한 AI 앱 — claude(claude.ai 웹·데스크톱·모바일)·chatgpt·local(이 컴퓨터의 앱: Claude Code 등)·other. 수동 토큰은 null. */
export type AiConnectionApp = "claude" | "chatgpt" | "local" | "other";
export type AiConnection = { id: string; kind: "oauth" | "token"; clientName: string; label?: string | null; app?: AiConnectionApp | null; scope: string; createdAt: string; lastUsedAt: string | null };
export type AiConsentRequest = { clientName: string; redirectHost: string; loopback: boolean; app?: AiConnectionApp; suggestedLabel?: string; scopes: string[]; account: { name: string; emailMasked: string | null } };
/** 앱이 넘기는 API. 실패하면 서버 응답 그대로({code}, 상태) 던지면 된다 — aiConnectError가 안내 키로 바꾼다. */
export type AiConnectApi = {
  connections: () => Promise<AiConnection[]>;
  disconnect: (id: string) => Promise<void>;
  consentRequest: (req: string) => Promise<AiConsentRequest>;
  /** label(1.17.0): 동의 화면에서 붙인 연결 이름(허용일 때만). */
  decide: (req: string, approve: boolean, label?: string) => Promise<{ redirect: string }>;
  /** 연결 이름 바꾸기(1.17.0). 없으면 화면에 ‘이름 바꾸기’가 안 보인다. */
  rename?: (id: string, label: string) => Promise<void>;
};

/**
 * 앱마다 다른 문구(1.17.0, 모든 앱이 같은 화면을 쓰도록). 앱의 번역(t)으로 현재 언어 값을 넘긴다.
 * data: AI가 다루는 데이터(예: "할 일·일정"), ask: 짧은 말 예시(예: "오늘 할 일 보여줘"), examples: 가이드 ‘이렇게 말해 보세요’.
 */
export type AiConnectContent = { data: string; ask: string; examples: string[] };

/** content를 넘기지 않은 앱의 기본값. */
export const defaultAiConnectContent: Record<"ko" | "en" | "ja", AiConnectContent> = {
  ko: { data: "내 기록", ask: "오늘 기록 보여줘", examples: [] },
  en: { data: "your data", ask: "Show today's items", examples: [] },
  ja: { data: "自分の記録", ask: "今日の記録を見せて", examples: [] },
};

/** MCP 서버 이름: 주소의 마지막 부분(예: …/mcp/oneuldoit → oneuldoit). AI 앱에 커넥터 이름으로 넣는다. */
export function mcpServerName(mcpUrl: string): string {
  return mcpUrl.replace(/\/+$/, "").split("/").pop() || "app";
}

export type AiConnectErrorView = { key: "expired" | "invalid" | "limit" | "failed"; max?: number; toSettings?: boolean };

/** axios 오류나 {code,max} 객체를 받아 화면 안내로 바꾼다. */
export function aiConnectError(error: unknown): AiConnectErrorView {
  const e = error as { code?: string; max?: number; status?: number; response?: { status?: number; data?: { code?: string; max?: number } } } | null;
  const data = e?.response?.data ?? e ?? {};
  const status = e?.response?.status ?? e?.status;
  const code = (data as { code?: string }).code;
  if (code === "CONNECTION_LIMIT" || status === 409) return { key: "limit", max: (data as { max?: number }).max ?? 5, toSettings: true };
  if (code === "REQUEST_EXPIRED" || status === 410) return { key: "expired" };
  if (status === 404 || status === 400) return { key: "invalid" };
  return { key: "failed" };
}

/** 로고 자리 글자: 이름 첫 글자(대문자). 없으면 "A". */
export function clientInitial(name: string | null | undefined): string {
  const c = (name ?? "").trim().charAt(0);
  return c ? c.toUpperCase() : "A";
}

/** 연결 해제 뒤 목록에서 뺀다(서버 재조회 전 즉시 반영용). */
export function withoutConnection(list: AiConnection[], id: string): AiConnection[] {
  return list.filter((c) => c.id !== id);
}

/** 목록에 보일 이름: 사용자가 붙인 이름, 없으면 AI 앱 이름. */
export function connectionTitle(c: Pick<AiConnection, "clientName" | "label">): string {
  const label = (c.label ?? "").trim();
  return label || c.clientName;
}

/** 연결 이름 입력값 정리(서버와 같은 규칙: 공백 정리·60자). 빈 값은 "". */
export function cleanLabel(value: string): string {
  return value.trim().replace(/\s+/g, " ").slice(0, 60);
}

/** 한 번도 쓰지 않은 OAuth 연결(정리 대상). 수동 토큰은 빼고, 마지막 사용이 없는 것만. */
export function unusedConnections(list: AiConnection[]): AiConnection[] {
  return list.filter((c) => c.kind === "oauth" && !c.lastUsedAt);
}

/** 동의 요청 id(req) 형식 검사 — 주소를 손으로 바꾼 경우 서버에 묻기 전에 안내한다. */
export function isRequestId(value: string | null | undefined): value is string {
  return typeof value === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
}
