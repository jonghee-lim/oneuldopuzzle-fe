import type { ReactNode } from "react";
import { Box, Dialog, useMediaQuery } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { radius } from "./mui-shape.ts";

/**
 * 내 계정 작업 창(1.15.0, docs/EMAIL-LOGIN-SETUP-DESIGN.md 3-2): 휴대폰(xs)은 아래에서 올라오는 시트, 태블릿·PC는 가운데 대화상자.
 * 내용(DialogTitle·DialogContent·DialogActions)은 그대로 넘긴다. 이메일 로그인 설정·연결/해제·이메일 변경이 같이 쓴다.
 */
export function SheetDialog({ open, onClose, children, labelledBy }: { open: boolean; onClose: () => void; children: ReactNode; labelledBy?: string }) {
  const theme = useTheme();
  const sheet = useMediaQuery(theme.breakpoints.down("sm"));
  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm" aria-labelledby={labelledBy}
      sx={sheet ? { "& .MuiDialog-container": { alignItems: "flex-end" } } : undefined}
      slotProps={sheet ? { paper: { sx: { m: 0, width: "100%", maxWidth: "100%", maxHeight: "92dvh", borderRadius: `${radius.card} ${radius.card} 0 0`, pb: "env(safe-area-inset-bottom)" } } } : undefined}>
      {sheet && <Box aria-hidden sx={{ width: "2.5rem", height: "0.25rem", borderRadius: radius.item, bgcolor: "divider", mx: "auto", mt: 1.25 }} />}
      {children}
    </Dialog>
  );
}
