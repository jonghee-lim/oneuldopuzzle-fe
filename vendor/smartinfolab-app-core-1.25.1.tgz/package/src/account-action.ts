import axios from "axios";
import { coreT, errorKind, liveRecord, localizedServerError, serverMessage, showsServerText } from "./locale.ts";

/**
 * 내 계정의 작업(로그인 수단 연결·해제, 이메일 변경)을 재인증 왕복(카카오·Apple 화면에 다녀오기) 동안 기억한다.
 * 소셜 전용 계정은 본인 확인으로 기존 소셜 재인증을 거치는데, 그 결과(state·verifier 증명)를 받아 돌아오면
 * 내 계정 화면이 멈췄던 작업을 자동으로 이어 간다. 토큰은 담지 않고 12분이 지나면 버린다.
 * 앱마다 저장 키(예: dallhythm-account-action)만 다르다. 기준 구현: 오늘DoIt·달 리듬(2026-10-11).
 */
export type SocialProvider = "KAKAO" | "APPLE" | "GOOGLE";
export type ReauthProof = { provider: SocialProvider; state: string; verifier: string };
type Common = { via: SocialProvider; at: number; proof?: ReauthProof };
export type ProviderAction = Common & { action: "link" | "unlink"; target: SocialProvider };
/** 이메일 변경: 새 이메일과 그 인증 토큰(30분 유효)을 들고 재인증을 다녀온다. */
export type EmailAction = Common & { action: "email"; email: string; token: string };
/** 이메일 로그인 설정 ‘다른 이메일’: 새 이메일과 그 인증 토큰을 들고 재인증을 다녀와 prepare를 부른다(비밀번호는 담지 않는다). */
export type EmailLoginAction = Common & { action: "emailLogin"; email: string; token: string };
export type AccountAction = ProviderAction | EmailAction | EmailLoginAction;
/** 서버가 알려 주는 본인 확인 방식: 비밀번호·필요 없음(최근 로그인)·소셜 재인증 */
export type Verification = "PASSWORD" | "NONE" | "REAUTH";
/** 내 계정 조회 응답(GET /api/<앱>/account) */
export interface AccountMethods {
  local: boolean;
  kakao: boolean;
  apple: boolean;
  /** 1.3 이하 서버 응답과 호환한다. */
  google?: boolean;
  verification: Verification;
  /** 수단별 연결 계정 이메일(2026-10-19 API부터, 받은 적 있는 수단만). 옛 서버 응답에는 없다. */
  accounts?: Partial<Record<"kakao" | "apple" | "google", string>>;
}

export const ACTION_TTL_MS = 12 * 60 * 1000;
/** 수단 이름. 지금 화면 언어 값을 읽는다(ko: 카카오·Apple·Google). */
export const providerLabel: Record<SocialProvider, string> = liveRecord(["KAKAO", "APPLE", "GOOGLE"], (p) => coreT(`appCore.provider.${p}`));

function isProvider(value: unknown): value is SocialProvider {
  return value === "KAKAO" || value === "APPLE" || value === "GOOGLE";
}

/** 로그인 수단 개수. 마지막 하나는 해제할 수 없다. */
export function methodCount(methods: Pick<AccountMethods, "local" | "kakao" | "apple" | "google">): number {
  return (methods.local ? 1 : 0) + (methods.kakao ? 1 : 0) + (methods.apple ? 1 : 0) + (methods.google ? 1 : 0);
}

/** 해제하려는 수단이 마지막이면 true(버튼을 막고 안내 문구를 보인다). */
export function isLastMethod(methods: Pick<AccountMethods, "local" | "kakao" | "apple" | "google">, target: SocialProvider): boolean {
  const linked = target === "KAKAO" ? methods.kakao : target === "APPLE" ? methods.apple : !!methods.google;
  return linked && methodCount(methods) <= 1;
}

/** 소셜 재인증에 쓸 수단: 해제는 해제할 그 수단으로, 연결·이메일 변경은 이미 연결된 수단(카카오 우선)으로. */
export function reauthVia(methods: Pick<AccountMethods, "kakao" | "apple" | "google">, action: "link" | "unlink" | "email" | "emailLogin", target?: SocialProvider): SocialProvider | null {
  if (action === "unlink" && target) return target;
  if (methods.kakao) return "KAKAO";
  if (methods.apple) return "APPLE";
  if (methods.google) return "GOOGLE";
  return null;
}

export function accountActions(storageKey: string, storage: () => Storage = () => sessionStorage) {
  function read(now = Date.now()): AccountAction | null {
    try {
      type Raw = { action?: unknown; target?: unknown; email?: unknown; token?: unknown; via?: unknown; at?: unknown; proof?: ReauthProof };
      const raw = JSON.parse(storage().getItem(storageKey) || "null") as Raw | null;
      if (!raw || !isProvider(raw.via) || typeof raw.at !== "number" || !Number.isFinite(raw.at) || now - raw.at > ACTION_TTL_MS) return null;
      if ((raw.action === "link" || raw.action === "unlink") && isProvider(raw.target)) return raw as ProviderAction;
      if ((raw.action === "email" || raw.action === "emailLogin") && typeof raw.email === "string" && raw.email && typeof raw.token === "string" && raw.token) return raw as EmailAction | EmailLoginAction;
      return null;
    } catch {
      return null;
    }
  }
  function clearAccountAction(): void {
    try {
      storage().removeItem(storageKey);
    } catch {
      /* 저장소 접근 불가: 무시 */
    }
  }
  return {
    saveAccountAction(action: Omit<ProviderAction, "at" | "proof"> | Omit<EmailAction, "at" | "proof"> | Omit<EmailLoginAction, "at" | "proof">, now = Date.now()): void {
      storage().setItem(storageKey, JSON.stringify({ ...action, at: now }));
    },
    /** 재인증 완료 화면에서 증명을 붙인다. 기다리던 작업이 있으면 true. */
    attachReauthProof(proof: ReauthProof, now = Date.now()): boolean {
      const action = read(now);
      if (!action || action.via !== proof.provider) {
        clearAccountAction();
        return false;
      }
      storage().setItem(storageKey, JSON.stringify({ ...action, proof }));
      return true;
    },
    /** 증명이 붙은 작업을 꺼내고 지운다(한 번만 실행). */
    takeAccountAction(now = Date.now()): AccountAction | null {
      const action = read(now);
      clearAccountAction();
      return action?.proof ? action : null;
    },
    clearAccountAction,
  };
}

/** 서버 오류 응답의 code. 카카오·Apple·계정 API 모두 {message, code?} 형식이다. */
export function accountErrorCode(error: unknown): string | null {
  return axios.isAxiosError(error) && typeof error.response?.data?.code === "string" ? error.response.data.code : null;
}

/** 서버 안내가 없을 때 fallback보다 먼저 보이는 오류 종류: 연결·시간 초과·요청 과다·서버 장애(화면 고유 문구가 사정을 가리면 안 된다). */
const TRANSPORT_KINDS = ["offline", "network", "timeout", "tooManyRequests", "server"];

/**
 * 계정·로그인 작업 오류 문구.
 * ko: 서버 안내(message·detail) → 연결·시간 초과·서버 장애 종류 문구 → 그 밖의 서버 응답은 fallback → app-core·앱이 만든 Error 문구 → fallback.
 *     1.21.0 전에는 서버 안내가 없는 axios 오류에서 axios 영어 원문("Request failed with status code 409", "Network Error")이 그대로 보였다.
 * en·ja: 서버 message(한국어)는 보이지 않고 code·오류 종류 문구(localizedServerError). app-core가 만든 Error는 이미 지금 언어다.
 */
export function accountErrorMessage(error: unknown, fallback?: string): string {
  const unknown = () => fallback ?? coreT("common.error.unknown");
  if (axios.isAxiosError(error)) {
    if (!showsServerText()) return localizedServerError(error, fallback);
    const message = serverMessage(error);
    if (message) return message;
    const kind = errorKind(error);
    return TRANSPORT_KINDS.includes(kind) ? coreT(`common.error.${kind}`) : unknown();
  }
  if (error instanceof Error && error.message) return error.message;
  return unknown();
}
