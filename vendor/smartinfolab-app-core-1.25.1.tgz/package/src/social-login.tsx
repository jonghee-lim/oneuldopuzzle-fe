import { Box, ButtonBase, Stack, Typography } from "@mui/material";
import { radius } from "./mui-shape.ts";
import { useCoreText } from "./use-core-text.ts";

/**
 * 로그인 화면 간편 로그인 버튼 공통 부품(2026-10-14).
 * 앱은 쓰는 수단과 누를 때 할 일만 넘기고, 모양은 앱 정책의 socialLoginLayout으로 고른다.
 *
 *   <SocialLoginButtons layout={policy.socialLoginLayout} items={[
 *     { provider: "kakao", onClick: kakaoLogin, disabled: !kakaoReady, hint: kakaoHint },
 *     { provider: "apple", onClick: appleLogin, disabled: !appleReady },
 *     { provider: "google", onClick: googleLogin },
 *   ]} />
 *
 * - vertical: 큰 버튼 세로(브랜드 색 유지, 높이·모서리·글자·아이콘 위치 통일)
 * - horizontal: 동그란 아이콘 + 아래 이름 가로 한 줄
 * - 순서는 카카오 → Apple → Google로 고정한다. 각 회사 버튼 규정(카카오 노란색, Apple 흑백, Google 흰 바탕+테두리)을 지킨다.
 */
export type SocialLoginProvider = "kakao" | "apple" | "google";
export type SocialLoginLayout = "vertical" | "horizontal";
export type SocialLoginItem = {
  provider: SocialLoginProvider;
  onClick: () => void;
  disabled?: boolean;
  /** 준비 중·확인 중처럼 버튼 아래에 보일 짧은 안내. 정상일 때는 넘기지 않는다. */
  hint?: string;
};

const ORDER: SocialLoginProvider[] = ["kakao", "apple", "google"];
// 버튼 문구 키(카카오는 ‘시작하기’, Apple·Google은 각 회사 규정 ‘계속하기’).
const LONG_KEY: Record<SocialLoginProvider, string> = { kakao: "appCore.social.kakaoStart", apple: "appCore.social.appleContinue", google: "appCore.social.googleContinue" };

/** 카카오·Apple·Google 공식 도형(로그인 버튼·내 계정 로그인 방법 행에서 같이 쓴다). */
export function ProviderMark({ provider, size }: { provider: SocialLoginProvider; size: number }) {
  const common = { width: size, height: size, viewBox: "0 0 24 24", "aria-hidden": true } as const;
  if (provider === "kakao")
    return <svg {...common}><path fill="#191919" d="M12 3C6.5 3 2 6.5 2 10.8c0 2.8 1.9 5.2 4.7 6.6l-1 3.6c-.1.3.3.6.6.4l4.3-2.8c.5.1.9.1 1.4.1 5.5 0 10-3.5 10-7.9S17.5 3 12 3z"/></svg>;
  if (provider === "apple")
    return <svg {...common}><path fill="currentColor" d="M16.4 12.7c0-2.4 2-3.6 2.1-3.7-1.1-1.7-2.9-1.9-3.5-1.9-1.5-.2-2.9.9-3.7.9-.8 0-1.9-.9-3.2-.8-1.6 0-3.1 1-4 2.4-1.7 3-.4 7.4 1.2 9.8.8 1.2 1.8 2.5 3 2.4 1.2 0 1.7-.8 3.2-.8s1.9.8 3.2.8c1.3 0 2.1-1.2 2.9-2.4.9-1.4 1.3-2.7 1.3-2.8-.1 0-2.5-1-2.5-3.9zM14 5.6c.7-.8 1.1-1.9 1-3-1 0-2.1.6-2.8 1.4-.6.7-1.2 1.8-1 2.9 1 .1 2.1-.5 2.8-1.3z"/></svg>;
  // Google 공식 'G' 로고(Sign in with Google 버튼 원본 도형).
  return <svg {...common} viewBox="0 0 48 48">
    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
  </svg>;
}

/** 수단별 바탕·글자·테두리. Apple·Google은 다크 모드에서 각 회사의 어두운 버튼으로 바꾼다. */
function brand(provider: SocialLoginProvider, dark: boolean) {
  if (provider === "kakao") return { bgcolor: "#FEE500", color: "#191919", border: "none", hover: "#F5DC00" };
  if (provider === "apple")
    return dark ? { bgcolor: "#FFFFFF", color: "#000000", border: "none", hover: "#EEEEEE" }
      : { bgcolor: "#000000", color: "#FFFFFF", border: "none", hover: "#222222" };
  return dark ? { bgcolor: "#131314", color: "#E3E3E3", border: "1px solid #8E918F", hover: "#1E1F20" }
    : { bgcolor: "#FFFFFF", color: "#1F1F1F", border: "1px solid #747775", hover: "#F8FAFD" };
}

export function SocialLoginButtons({ layout, items }: { layout: SocialLoginLayout; items: SocialLoginItem[] }) {
  const t = useCoreText();
  const label = (p: SocialLoginProvider) => ({ long: t(LONG_KEY[p]), short: t(`appCore.provider.${p.toUpperCase()}`) });
  const list = ORDER.flatMap(p => items.filter(i => i.provider === p));
  const hints = list.filter(i => i.hint);
  const focus = { "&.Mui-focusVisible": { outline: "2px solid", outlineColor: "primary.main", outlineOffset: "2px" } };
  const disabledLook = { "&.Mui-disabled": { opacity: 0.45 } };

  if (layout === "horizontal") return (
    <Stack sx={{ gap: 1 }}>
      <Stack direction="row" sx={{ justifyContent: "center", gap: 3.5 }}>
        {list.map(item => (
          <ButtonBase key={item.provider} disabled={item.disabled} onClick={item.onClick} aria-label={label(item.provider).long}
            sx={{ minWidth: 64, p: 0.5, borderRadius: radius.item, flexDirection: "column", gap: 1, ...focus, ...disabledLook }}>
            <Box sx={theme => {
              const b = brand(item.provider, theme.palette.mode === "dark");
              return { width: 56, height: 56, borderRadius: "50%", display: "grid", placeItems: "center", bgcolor: b.bgcolor, color: b.color, border: b.border, boxSizing: "border-box" };
            }}>
              <ProviderMark provider={item.provider} size={24} />
            </Box>
            <Typography component="span" sx={{ fontSize: "0.8125rem", fontWeight: 500, color: "text.primary" }}>{label(item.provider).short}</Typography>
          </ButtonBase>
        ))}
      </Stack>
      {hints.map(i => <Typography key={i.provider} variant="caption" color="text.secondary" sx={{ textAlign: "center" }}>{i.hint}</Typography>)}
    </Stack>
  );

  return (
    <Stack sx={{ gap: 1.5 }}>
      {list.map(item => (
        <Stack key={item.provider} sx={{ gap: 0.5 }}>
          <ButtonBase disabled={item.disabled} onClick={item.onClick}
            sx={theme => {
              const b = brand(item.provider, theme.palette.mode === "dark");
              return {
                width: "100%", height: 48, px: 2, borderRadius: radius.control, boxSizing: "border-box",
                display: "grid", gridTemplateColumns: "20px minmax(0, 1fr) 20px", columnGap: "10px", alignItems: "center",
                bgcolor: b.bgcolor, color: b.color, border: b.border, fontSize: "0.9375rem", fontWeight: 500,
                "&:hover": { bgcolor: b.hover }, ...focus, ...disabledLook,
              };
            }}>
            <ProviderMark provider={item.provider} size={20} />
            <span>{label(item.provider).long}</span>
            <span aria-hidden="true" />
          </ButtonBase>
          {item.hint && <Typography variant="caption" color="text.secondary">{item.hint}</Typography>}
        </Stack>
      ))}
    </Stack>
  );
}
