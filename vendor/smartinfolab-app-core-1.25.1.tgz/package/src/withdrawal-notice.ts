/*
 * 회원 탈퇴 안내 공통 문구(1.12.0). 연결된 간편 로그인 수단만 골라 "그 계정 자체는 삭제되지 않는다"고 알리고,
 * 어느 앱이든 "다시 가입하면 새 계정"을 붙인다. 이메일만 쓰거나 수단을 아직 모르면 뒤 문장만 보인다.
 * 앱 고유 삭제 범위(기록·권한 등) 설명은 앱 화면이 따로 적는다. 사용자 결정 2026-10-19: 꼭 필요한 문구만.
 */
import { coreT, type Language } from "./locale.ts";
import { useCoreLanguage } from "./use-core-text.ts";

export type WithdrawalMethods = { kakao?: boolean; apple?: boolean; google?: boolean };

const ORDER = ["KAKAO", "APPLE", "GOOGLE"] as const;

/** 연결된 수단 이름을 카카오 → Apple → Google 순서로 잇는다(ko·ja "·", en ", "). */
export function connectedProviders(methods: WithdrawalMethods | undefined, lang?: Language): string {
  const names = ORDER.filter((p) => methods?.[p.toLowerCase() as keyof WithdrawalMethods]).map((p) => coreT(`appCore.provider.${p}`, undefined, lang));
  return names.join(lang === "en" ? ", " : "·");
}

export function withdrawalNotice(methods: WithdrawalMethods | undefined, lang?: Language): string {
  const providers = connectedProviders(methods, lang);
  const rejoin = coreT("appCore.withdrawal.rejoin", undefined, lang);
  // 일본어는 문장 사이를 띄우지 않는다.
  return providers ? `${coreT("appCore.withdrawal.providersKept", { providers }, lang)}${lang === "ja" ? "" : " "}${rejoin}` : rejoin;
}

/** 화면용: 언어가 바뀌거나 수단 조회가 끝나면 다시 계산한다. */
export function useWithdrawalNotice(methods: WithdrawalMethods | undefined): string {
  return withdrawalNotice(methods, useCoreLanguage());
}
