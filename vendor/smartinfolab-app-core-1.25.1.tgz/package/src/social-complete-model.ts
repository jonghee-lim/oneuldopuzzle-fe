/* 간편 로그인 완료 화면 안내 규칙(1.9.0). 화면 틀은 social-complete.tsx. Node 단위 테스트를 위해 .ts로 분리했다. */
import { coreT, liveRecord, localizedServerError, showsServerText } from "./locale.ts";

export type SocialProviderName = "kakao" | "apple" | "google";
/** 수단 이름(지금 화면 언어 값을 읽는다). */
export const LABEL: Record<SocialProviderName, string> = liveRecord(["kakao", "apple", "google"], (p) => coreT(`appCore.provider.${p.toUpperCase()}`));

/** ko 연결 안내(1.9.0 호환 상수). 화면은 지금 언어 문구(common.error.network)를 쓴다. */
export const SOCIAL_NETWORK_MESSAGE = "서버에 연결할 수 없습니다. 연결 상태를 확인하고 다시 시도해 주십시오.";

/**
 * 완료 화면 실패 안내. 서버 message·detail → (응답 없음) 연결 안내 → Error 문구 → 기본 문구 순서다.
 * en·ja는 서버 안내(한국어) 대신 code·오류 종류 문구, 모르면 기본 문구다.
 */
export function socialCompleteMessage(error: unknown, provider: SocialProviderName): string {
  const e = error as { isAxiosError?: boolean; response?: { data?: { message?: unknown; detail?: unknown } }; message?: unknown } | null;
  if (!showsServerText() && e?.isAxiosError) return localizedServerError(error, coreT("appCore.social.failed", { provider: LABEL[provider] }));
  const data = e?.response?.data;
  for (const value of [data?.message, data?.detail]) if (typeof value === "string" && value.trim()) return value;
  if (e?.isAxiosError && !e.response) return coreT("common.error.network");
  if (!e?.isAxiosError && error instanceof Error && error.message) return error.message;
  return coreT("appCore.social.failed", { provider: LABEL[provider] });
}

/** 공급자가 돌려준 취소·실패 값(#error=...)을 안내 문구로. 앱 run 안에서 throw해 쓴다. */
export function socialReturnError(provider: SocialProviderName, code: string | null): Error {
  const key = code === "cancelled" ? "cancelled" : code === "expired" ? "expired" : "cancelledOrExpired";
  return new Error(coreT(`appCore.social.${key}`, { provider: LABEL[provider] }));
}

/** 주소의 #해시를 읽고 바로 지운다(뒤로 가기·새로고침으로 같은 값을 다시 쓰지 않게). */
export function takeCompletionFragment(): { fragment: string; params: URLSearchParams } {
  const fragment = window.location.hash;
  window.history.replaceState(window.history.state, "", window.location.pathname);
  return { fragment, params: new URLSearchParams(fragment.replace(/^#/, "")) };
}

