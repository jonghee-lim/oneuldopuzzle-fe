import { App } from "@capacitor/app";
import { isIosApp, isNativeApp } from "./runtime.ts";

/**
 * 앱 버전 업데이트 체크에 쓰는 현재 버전·플랫폼과 ‘나중에’ 기억.
 * 설치형 앱은 Capacitor App 플러그인(Info.plist의 MARKETING_VERSION·빌드 번호)에서 읽고, 웹은 앱이 넘긴
 * 빌드 버전(VITE_APP_VERSION)이 있을 때만 값을 돌려준다(없으면 null → 체크 생략).
 */
export type AppVersionInfo = { platform: "IOS" | "ANDROID" | "WEB"; version: string; build: string };

export async function currentAppVersion(webVersion?: string): Promise<AppVersionInfo | null> {
  if (isNativeApp()) {
    try {
      const info = await App.getInfo();
      if (!info.version) return null;
      return { platform: isIosApp() ? "IOS" : "ANDROID", version: info.version, build: info.build ?? "" };
    } catch {
      return null;
    }
  }
  return webVersion ? { platform: "WEB", version: webVersion, build: "" } : null;
}

/** 안내 업데이트에서 ‘나중에’를 누르면 그 버전은 7일 동안 다시 묻지 않는다. */
export const DISMISS_DAYS = 7;

/** 앱마다 저장 키(예: oneuldoit-app-update-dismissed)만 다르다. */
export function updateDismissal(storageKey: string) {
  return {
    isUpdateDismissed(latestVersion: string, now = Date.now()): boolean {
      try {
        const raw = JSON.parse(localStorage.getItem(storageKey) || "null") as { version?: unknown; until?: unknown } | null;
        return !!raw && raw.version === latestVersion && typeof raw.until === "number" && raw.until > now;
      } catch {
        return false;
      }
    },
    dismissUpdate(latestVersion: string, now = Date.now()): void {
      try {
        localStorage.setItem(storageKey, JSON.stringify({ version: latestVersion, until: now + DISMISS_DAYS * 864e5 }));
      } catch {
        /* 저장이 막힌 브라우저에서는 다음에 다시 보인다. */
      }
    },
  };
}
