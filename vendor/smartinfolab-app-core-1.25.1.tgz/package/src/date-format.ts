/*
 * 날짜·기간 표시(1.10.0, Intl 기반). 언어를 넘기지 않으면 app-core 화면 언어(기본 ko)를 따른다.
 * ko는 공통 지침의 한국어 표준을 그대로 낸다(기준: 달 리듬 utils/dateLabel.ts, 스피드 기간 표시 675081c).
 *  - 월·일: 올해면 11.02, 올해가 아니면 27.01.03
 *  - 기간(year:"always", 기본): 같은 해면 끝 날짜 연도를 뺀다 26.11.02 ~ 11.05, 해를 넘기면 26.12.28 ~ 27.01.03
 *  - 기간(year:"auto"): 11.02 ~ 11.05, 올해가 아니면 25.11.02 ~ 25.11.05, 해를 넘기면 양쪽 연도
 *  - 날짜·시각 기간: 2026-10-15 09:00 ~ 10-20 18:00
 * en은 Intl 형식(Nov 2 – 5, 2026), ja는 年月日 형식(2026年11月2日～5日, ICU 범위가 숫자 모양이라 직접 잇는다)이다.
 * 입력: "YYYY-MM-DD"(달력 날짜, 시간대와 무관), ISO 문자열, Date.
 */
import { getCoreLanguage, INTL_LOCALE, type Language } from "./locale.ts";

export type DateInput = string | number | Date;
export type DateFormatOptions = { lang?: Language; timeZone?: string; now?: DateInput };

const DATE_ONLY = /^(\d{4})-(\d{2})-(\d{2})$/;
type Point = { date: Date; tz: string | undefined };

function point(value: DateInput, timeZone?: string): Point {
  if (typeof value === "string") {
    const m = DATE_ONLY.exec(value);
    // 달력 날짜는 UTC 정오로 두고 UTC로 읽는다: 기기 시간대와 상관없이 같은 날짜다.
    if (m) return { date: new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], 12)), tz: "UTC" };
  }
  return { date: value instanceof Date ? value : new Date(value), tz: timeZone };
}

type Parts = { y: string; m: string; d: string; hh: string; mm: string };
function parts(p: Point): Parts {
  const f = new Intl.DateTimeFormat("en-US", { timeZone: p.tz, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
  const o: Record<string, string> = {};
  for (const x of f.formatToParts(p.date)) o[x.type] = x.value;
  return { y: o.year, m: o.month, d: o.day, hh: o.hour === "24" ? "00" : o.hour, mm: o.minute };
}

const thisYear = (o: DateFormatOptions, tz: string | undefined) => parts(point(o.now ?? new Date(), o.timeZone ?? (tz === "UTC" ? undefined : tz))).y;
const langOf = (o: DateFormatOptions) => o.lang ?? getCoreLanguage();
const withYear = (x: Parts) => `${x.y.slice(2)}.${x.m}.${x.d}`;
const noYear = (x: Parts) => `${x.m}.${x.d}`;

function intlDate(lang: Language, year: boolean, tz: string | undefined, extra: Intl.DateTimeFormatOptions = {}) {
  return new Intl.DateTimeFormat(INTL_LOCALE[lang], { timeZone: tz, month: lang === "en" ? "short" : "long", day: "numeric", ...(year ? { year: "numeric" } : {}), ...extra });
}

// ICU의 ja 범위 형식은 2026/11/02～2026/11/05처럼 숫자 모양이라, 날짜 하나와 같은 年月日 모양으로 직접 잇는다.
const jaDay = (x: Parts, year: boolean) => `${year ? `${x.y}年` : ""}${+x.m}月${+x.d}日`;
function jaRange(x: Parts, y: Parts, showYear: boolean): string {
  if (x.y !== y.y) return `${jaDay(x, true)}～${jaDay(y, true)}`;
  const tail = x.m === y.m ? `${+y.d}日` : `${+y.m}月${+y.d}日`;
  return `${jaDay(x, showYear)}～${tail}`;
}

export type YearMode = "auto" | "always" | "never";

/** 날짜 하나. year 기본 "auto"(올해가 아니면 연도). ko: 11.02 / 27.01.03, en: Nov 2 / Jan 3, 2027, ja: 11月2日 / 2027年1月3日 */
export function formatDate(value: DateInput, options: DateFormatOptions & { year?: YearMode } = {}): string {
  const p = point(value, options.timeZone), x = parts(p), lang = langOf(options);
  const showYear = options.year === "always" || (options.year !== "never" && x.y !== thisYear(options, p.tz));
  if (lang === "ko") return showYear ? withYear(x) : noYear(x);
  return intlDate(lang, showYear, p.tz).format(p.date);
}

/** 기간. year 기본 "always"(연도 한 번). 위 머리말 규칙. */
export function formatDateRange(start: DateInput, end: DateInput, options: DateFormatOptions & { year?: "always" | "auto" } = {}): string {
  const a = point(start, options.timeZone), b = point(end, options.timeZone);
  const x = parts(a), y = parts(b), lang = langOf(options);
  const sameYear = x.y === y.y;
  const auto = options.year === "auto";
  if (lang === "ko") {
    if (!auto) return `${withYear(x)} ~ ${sameYear ? noYear(y) : withYear(y)}`;
    if (!sameYear) return `${withYear(x)} ~ ${withYear(y)}`;
    const now = thisYear(options, a.tz);
    const md = (q: Parts) => (q.y === now ? noYear(q) : withYear(q));
    return `${md(x)} ~ ${md(y)}`;
  }
  const showYear = !auto || !sameYear || x.y !== thisYear(options, a.tz);
  if (lang === "ja") return jaRange(x, y, showYear);
  return intlDate(lang, showYear, a.tz).formatRange(a.date, b.date);
}

/** 날짜·시각. ko: 2026-10-15 09:00 */
export function formatDateTime(value: DateInput, options: DateFormatOptions = {}): string {
  const p = point(value, options.timeZone), x = parts(p), lang = langOf(options);
  if (lang === "ko") return `${x.y}-${x.m}-${x.d} ${x.hh}:${x.mm}`;
  return intlDate(lang, true, p.tz, { hour: "numeric", minute: "2-digit" }).format(p.date);
}

/** 날짜·시각 기간. ko: 같은 해면 끝의 연도를 뺀다 2026-10-15 09:00 ~ 10-20 18:00 */
export function formatDateTimeRange(start: DateInput, end: DateInput, options: DateFormatOptions = {}): string {
  const a = point(start, options.timeZone), b = point(end, options.timeZone), lang = langOf(options);
  if (lang === "ko") {
    const tail = formatDateTime(end, options);
    return `${formatDateTime(start, options)} ~ ${tail.slice(parts(a).y === parts(b).y ? 5 : 0)}`;
  }
  if (lang === "ja") {
    const x = parts(a), y = parts(b);
    return `${jaDay(x, true)} ${+x.hh}:${x.mm}～${jaDay(y, x.y !== y.y)} ${+y.hh}:${y.mm}`;
  }
  return intlDate(lang, true, a.tz, { hour: "numeric", minute: "2-digit" }).formatRange(a.date, b.date);
}

/** 월. 올해가 아니면 연도(year 기본 "auto"). ko: 10월 / 2025년 10월, en: October / October 2025, ja: 10月 / 2025年10月 */
export function formatMonth(value: DateInput, options: DateFormatOptions & { year?: YearMode } = {}): string {
  const p = point(value, options.timeZone), x = parts(p), lang = langOf(options);
  const showYear = options.year === "always" || (options.year !== "never" && x.y !== thisYear(options, p.tz));
  return new Intl.DateTimeFormat(INTL_LOCALE[lang], { timeZone: p.tz, month: "long", ...(showYear ? { year: "numeric" } : {}) }).format(p.date);
}

/** 요일. short(기본) ko: 월, en: Mon, ja: 月 / long ko: 월요일, en: Monday, ja: 月曜日 */
export function formatWeekday(value: DateInput, options: DateFormatOptions & { style?: "short" | "long" | "narrow" } = {}): string {
  const p = point(value, options.timeZone), lang = langOf(options);
  return new Intl.DateTimeFormat(INTL_LOCALE[lang], { timeZone: p.tz, weekday: options.style ?? "short" }).format(p.date);
}

/** 달력 머리 요일 이름 7개(일요일부터, short). */
export function weekdayNames(options: DateFormatOptions & { style?: "short" | "long" | "narrow" } = {}): string[] {
  // 2026-10-04는 일요일
  return Array.from({ length: 7 }, (_, i) => formatWeekday(`2026-10-${String(4 + i).padStart(2, "0")}`, options));
}

export { usesKoreanHolidays, koreanHoliday } from "./locale.ts";
