/*
 * 공통 다국어 기반(1.10.0) 중 의존성 없는 부분: 지원 언어, 언어 결정, app-core 문구 번역(coreT), 공통 오류 문구.
 * i18next를 설치하지 않은 앱도 이 파일만으로 동작한다. 언어를 정하지 않으면 늘 ko라 1.9.1과 화면이 같다.
 * createAppI18n(./i18n)을 쓰면 언어가 바뀔 때 setCoreLanguage가 함께 불려 app-core 화면 문구도 따라 바뀐다.
 */
import { ko } from "./locales/ko.ts";
import { en } from "./locales/en.ts";
import { ja } from "./locales/ja.ts";

export const LANGUAGES = ["ko", "en", "ja"] as const;
export type Language = (typeof LANGUAGES)[number];
/** 사용자가 고른 값. "system"은 기기 설정 따르기. */
export type LanguageChoice = Language | "system";
/** 언어 선택 화면에 보이는 이름(각 언어 자기 이름, 번역하지 않는다). */
export const LANGUAGE_NAMES: Record<Language, string> = { ko: "한국어", en: "English", ja: "日本語" };
/** Intl에 넘기는 지역 포함 이름. */
export const INTL_LOCALE: Record<Language, string> = { ko: "ko-KR", en: "en-US", ja: "ja-JP" };

/** app-core 내장 사전(common·appCore 네임스페이스). createAppI18n이 앱 사전과 합친다. */
export const coreResources = { ko, en, ja } as const;

export const isLanguage = (v: unknown): v is Language => typeof v === "string" && (LANGUAGES as readonly string[]).includes(v);

/**
 * 언어 결정: 고정 언어 > 저장된 선택 > 기기 언어(앞에서부터, 지역 무시) > fallback(기본 en).
 * fixed는 아직 번역이 없는 앱이 ko로 고정할 때 쓴다.
 */
export function resolveLanguage(input: {
  stored?: string | null;
  device?: string | readonly string[] | null;
  supported?: readonly Language[];
  fallback?: Language;
  fixed?: Language;
}): Language {
  const supported = input.supported?.length ? input.supported : LANGUAGES;
  if (input.fixed) return input.fixed;
  if (isLanguage(input.stored) && supported.includes(input.stored)) return input.stored;
  const device = typeof input.device === "string" ? [input.device] : input.device ?? [];
  for (const tag of device) {
    const base = String(tag).toLowerCase().split(/[-_]/)[0];
    if (isLanguage(base) && supported.includes(base)) return base;
  }
  const fallback = input.fallback ?? "en";
  return supported.includes(fallback) ? fallback : supported[0];
}

/** 브라우저·웹뷰 기기 언어 목록(설치형 앱 웹뷰도 기기 언어를 준다). */
export function deviceLanguages(): readonly string[] {
  if (typeof navigator === "undefined") return [];
  return navigator.languages?.length ? navigator.languages : navigator.language ? [navigator.language] : [];
}

// app-core 화면 언어. 앱이 바꾸지 않으면 ko다.
let current: Language = "ko";
const listeners = new Set<() => void>();
export const getCoreLanguage = (): Language => current;
export function setCoreLanguage(lang: Language): void {
  if (!isLanguage(lang) || lang === current) return;
  current = lang;
  for (const l of [...listeners]) l();
}
export function subscribeCoreLanguage(listener: () => void): () => void {
  listeners.add(listener);
  return () => { listeners.delete(listener); };
}

type Tree = { [k: string]: string | Tree };
function lookup(tree: Tree, key: string): string | undefined {
  let node: string | Tree | undefined = tree;
  for (const part of key.split(".")) {
    if (!node || typeof node === "string") return undefined;
    node = node[part];
  }
  return typeof node === "string" ? node : undefined;
}

/** {{이름}} 끼워 넣기(i18next와 같은 형식). */
export function interpolate(text: string, vars?: Record<string, string | number>): string {
  if (!vars) return text;
  return text.replace(/\{\{\s*([\w.]+)\s*\}\}/g, (all, name: string) => (name in vars ? String(vars[name]) : all));
}

/**
 * app-core 문구 번역. 키는 "네임스페이스.경로"(예: "common.save", "appCore.account.title").
 * 지금 언어에 없으면 en, en에도 없으면 ko, 둘 다 없으면 키를 돌려준다(app-core 사전은 세 언어가 모두 차 있다).
 */
export function coreT(key: string, vars?: Record<string, string | number>, lang: Language = current): string {
  const text = lookup(coreResources[lang] as unknown as Tree, key) ?? lookup(coreResources.en as unknown as Tree, key) ?? lookup(coreResources.ko as unknown as Tree, key) ?? key;
  return interpolate(text, vars);
}

/** 수단 이름(카카오·Apple·Google). 지금 언어를 따른다. */
export const providerName = (provider: "KAKAO" | "APPLE" | "GOOGLE", lang?: Language) => coreT(`appCore.provider.${provider}`, undefined, lang);

/** 이름 → 지금 언어 값으로 읽히는 객체(기존 공개 상수 providerLabel·LABEL 모양을 유지하려고 쓴다). */
export function liveRecord<K extends string>(keys: readonly K[], read: (k: K) => string): Record<K, string> {
  const out = {} as Record<K, string>;
  for (const k of keys) Object.defineProperty(out, k, { enumerable: true, get: () => read(k) });
  return out;
}

export type ErrorKind = "offline" | "network" | "timeout" | "invalid" | "unauthorized" | "forbidden" | "notFound" | "conflict" | "tooManyRequests" | "server" | "unknown";

type ErrorLike = { isAxiosError?: boolean; code?: unknown; response?: { status?: unknown; data?: { message?: unknown; detail?: unknown; code?: unknown } } } | null | undefined;

/** 오류 종류. axios 오류의 응답 유무·HTTP 상태와 기기 오프라인 여부로 나눈다. */
export function errorKind(error: unknown): ErrorKind {
  const e = error as ErrorLike;
  const status = typeof e?.response?.status === "number" ? e.response.status : undefined;
  if (e?.isAxiosError && !e.response) {
    if (typeof navigator !== "undefined" && navigator.onLine === false) return "offline";
    return e.code === "ECONNABORTED" || e.code === "ETIMEDOUT" ? "timeout" : "network";
  }
  if (status === undefined) return "unknown";
  if (status === 401) return "unauthorized";
  if (status === 403) return "forbidden";
  if (status === 404) return "notFound";
  if (status === 408) return "timeout";
  if (status === 409) return "conflict";
  if (status === 429) return "tooManyRequests";
  if (status === 400 || status === 422) return "invalid";
  if (status >= 500) return "server";
  return "unknown";
}

/** 서버가 준 안내(message·detail). 없으면 null. */
export function serverMessage(error: unknown): string | null {
  const data = (error as ErrorLike)?.response?.data;
  for (const v of [data?.message, data?.detail]) if (typeof v === "string" && v.trim()) return v;
  return null;
}

/** 서버 오류 응답의 code(예: LAST_LOGIN_METHOD). 없으면 null. */
export function serverErrorCode(error: unknown): string | null {
  const code = (error as ErrorLike)?.response?.data?.code;
  return typeof code === "string" && code ? code : null;
}

/** app-core가 아는 서버 code의 지금 언어 문구. 모르는 code면 null. */
export function serverCodeMessage(error: unknown, lang: Language = current): string | null {
  const code = serverErrorCode(error);
  if (!code || !/^[A-Z][A-Z0-9_]*$/.test(code)) return null;
  const key = `common.errorCode.${code}`;
  const text = coreT(key, undefined, lang);
  return text === key ? null : text;
}

/** 서버 안내(한국어)를 그대로 보여도 되는 언어인가. ko만 그렇다. */
export const showsServerText = (lang: Language = current): boolean => lang === "ko";

/**
 * 공통 오류 문구.
 * - ko: 서버 안내(message·detail)를 그대로 보이고(기존 accountErrorMessage와 같은 원칙), 없으면 오류 종류 문구.
 * - en·ja: 서버 안내는 한국어라 보이지 않는다. 서버 code를 app-core가 알면 그 문구, 모르면 오류 종류(HTTP 상태·연결) 문구.
 * server:false면 언어와 관계없이 서버 안내 대신 늘 종류 문구.
 */
export function commonErrorMessage(error: unknown, options: { server?: boolean; lang?: Language } = {}): string {
  const lang = options.lang ?? current;
  if (options.server !== false) {
    if (showsServerText(lang)) {
      const message = serverMessage(error);
      if (message) return message;
    } else {
      const coded = serverCodeMessage(error, lang);
      if (coded) return coded;
    }
  }
  return coreT(`common.error.${errorKind(error)}`, undefined, lang);
}

/**
 * en·ja 화면에서 서버 오류를 보일 때: 아는 code 문구 → 연결·시간 초과·요청 과다·서버 오류는 종류 문구 → 화면 고유 실패 문구(fallback) → 종류 문구.
 * ko 화면에는 쓰지 않는다(ko는 각 함수의 기존 규칙 그대로).
 */
export function localizedServerError(error: unknown, fallback?: string, lang: Language = current): string {
  const coded = serverCodeMessage(error, lang);
  if (coded) return coded;
  const kind = errorKind(error);
  if (fallback && !["offline", "network", "timeout", "tooManyRequests", "server"].includes(kind)) return fallback;
  return coreT(`common.error.${kind}`, undefined, lang);
}

/**
 * 한국 공휴일은 화면 언어가 ko일 때만 쓴다(공휴일 데이터는 앱에 있다).
 *   const name = koreanHoliday(ymd, (d) => HOLIDAYS[d]);  // ko가 아니면 undefined
 */
export const usesKoreanHolidays = (lang: Language = current): boolean => lang === "ko";
export function koreanHoliday<T, D = string>(date: D, find: (date: D) => T | undefined | null, lang: Language = current): T | undefined {
  if (!usesKoreanHolidays(lang)) return undefined;
  return find(date) ?? undefined;
}
