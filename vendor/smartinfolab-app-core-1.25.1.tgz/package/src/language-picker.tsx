import { useState } from "react";
import { Dialog, DialogActions, DialogContent, DialogTitle, FormControlLabel, Radio, RadioGroup, Button } from "@mui/material";
import { SettingsRow } from "./settings-list.tsx";
import { LANGUAGE_NAMES, LANGUAGES, type Language, type LanguageChoice } from "./locale.ts";
import { useCoreText } from "./use-core-text.ts";

/*
 * 언어 선택 부품(1.10.0). 설정 목록 한 줄(LanguageSettingsRow)을 누르면 대화상자(LanguageDialog)에서
 * 기기 설정 따르기 · 한국어 · English · 日本語 가운데 고른다. 고르면 바로 적용하고 닫는다.
 * 값은 createAppI18n의 choice()/setChoice()를 그대로 넘긴다.
 *
 *   const [choice, setChoice] = useLanguageChoice(appI18n);   // ./i18n
 *   <SettingsGroup><LanguageSettingsRow value={choice} onChange={setChoice} /></SettingsGroup>
 */
export type LanguagePickerProps = {
  value: LanguageChoice;
  onChange: (choice: LanguageChoice) => void | Promise<void>;
  /** 앱이 지원하는 언어(기본 ko·en·ja). */
  supported?: readonly Language[];
};

export function LanguageDialog({ open, onClose, value, onChange, supported = LANGUAGES }: LanguagePickerProps & { open: boolean; onClose: () => void }) {
  const t = useCoreText();
  const options: LanguageChoice[] = ["system", ...supported];
  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="xs">
      <DialogTitle>{t("appCore.language.title")}</DialogTitle>
      <DialogContent>
        <RadioGroup value={value} onChange={(e) => { void onChange(e.target.value as LanguageChoice); onClose(); }}>
          {options.map((o) => (
            <FormControlLabel key={o} value={o} control={<Radio />} sx={{ minHeight: 44 }}
              label={o === "system" ? t("appCore.language.system") : LANGUAGE_NAMES[o]}
              slotProps={{ typography: o === "system" ? undefined : { lang: o } }} />
          ))}
        </RadioGroup>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>{t("common.close")}</Button>
      </DialogActions>
    </Dialog>
  );
}

/** 설정 목록 한 줄: ‘언어  한국어 >’. SettingsGroup 안에 둔다. */
export function LanguageSettingsRow(props: LanguagePickerProps & { label?: string }) {
  const t = useCoreText();
  const [open, setOpen] = useState(false);
  const current = props.value === "system" ? t("appCore.language.system") : LANGUAGE_NAMES[props.value];
  return (
    <>
      <SettingsRow label={props.label ?? t("appCore.language.title")} value={current} onClick={() => setOpen(true)} />
      <LanguageDialog {...props} open={open} onClose={() => setOpen(false)} />
    </>
  );
}
