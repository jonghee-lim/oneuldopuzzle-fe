/**
 * 내 계정 공통 틀(account-layout)의 순수 계산. JSX 없이 단위 테스트한다.
 */
import type { AccountMethods, SocialProvider } from "./account-action.ts";
import { coreT, localizedServerError, showsServerText } from "./locale.ts";

/** 프로필 카드 둘째 줄 "이메일 · 카카오 · Google 로그인"의 앞부분. 조회 전에는 로그인 ID 앞붙임으로 짐작한다. */
export function loginMethodsText(data: Pick<AccountMethods, "local" | "kakao" | "apple" | "google"> | undefined, loginId?: string | null): string {
  const name = (k: string) => coreT(k === "email" ? "appCore.methods.email" : `appCore.provider.${k}`);
  if (data) return [data.local && name("email"), data.kakao && name("KAKAO"), data.apple && name("APPLE"), data.google && name("GOOGLE")].filter(Boolean).join(" · ");
  if (loginId == null) return "";
  if (loginId.startsWith("kakao_")) return name("KAKAO");
  if (loginId.startsWith("apple_")) return name("APPLE");
  if (loginId.startsWith("google_")) return name("GOOGLE");
  return name("email");
}

/** 소셜 로그인 기본 이름은 별명이 아니다(‘별명 없음’으로 보인다). */
export const DEFAULT_SOCIAL_NAMES = ["Apple 사용자", "카카오 사용자", "Google 사용자"] as const;
export function hasNickname(name?: string | null): boolean {
  return !!name?.trim() && !(DEFAULT_SOCIAL_NAMES as readonly string[]).includes(name);
}

/** 로그인 수단 행 오른쪽 값: 연결됨 / 연결하기 / 준비 중(지금 화면 언어). */
export function providerRowValue(row: { connected: boolean; available: boolean }): string {
  return coreT(row.connected ? "appCore.methods.connected" : row.available ? "appCore.methods.link" : "appCore.methods.preparing");
}

/**
 * 이메일/비밀번호 행 상태(docs/EMAIL-LOGIN-SETUP-DESIGN.md 3-1): 사용 중 / 설정(소셜 전용이고 설정할 수 있을 때) / 없음(관리 불가 등).
 * 설정일 때만 행을 눌러 이메일 로그인 설정 시트를 연다.
 */
export type LocalRowState = "inUse" | "removable" | "setup" | "none";
export function localRowState(input: { local: boolean; canSetup: boolean; canRemove?: boolean }): LocalRowState {
  if (input.local) return input.canRemove ? "removable" : "inUse";
  return input.canSetup ? "setup" : "none";
}
/** 행 오른쪽 글자. removable은 ‘사용 중’ 배지에 › 만 붙는다(1.25.0, 눌러서 이메일 로그인 해제 시트). */
export function localRowValue(state: LocalRowState): string {
  return coreT(state === "inUse" || state === "removable" ? "appCore.account.inUse" : state === "setup" ? "appCore.account.setup" : "appCore.account.none");
}

/**
 * 이메일 로그인을 해제할 수 있는 계정(1.25.0, _review/email-login-remove-design-2026-10-25.md): 앱이 password.remove를 넘겼고,
 * 이메일 계정이며, 관리 가능(자녀·학생 아님), 카카오·Apple·Google 중 하나라도 연결돼 있어야 한다(마지막 수단 보호).
 */
export function canRemoveEmailLogin(input: { hasApi: boolean; local?: boolean; manageable?: boolean; kakao?: boolean; apple?: boolean; google?: boolean }): boolean {
  if (!input.hasApi || input.local !== true || input.manageable === false) return false;
  return Boolean(input.kakao || input.apple || input.google);
}

/** 이메일 로그인이 유일한 수단인지(소셜 행의 isLastMethod와 같은 규칙). */
export function isLastLocal(data: Pick<AccountMethods, "local" | "kakao" | "apple" | "google">): boolean {
  return data.local && !data.kakao && !data.apple && !data.google;
}

/**
 * 이메일 행 둘째 줄: 사용 중·해제 가능이면 계정 이메일, 설정이면 ‘아직 설정하지 않았습니다’, 없음이면 빈 값.
 * 해제 API가 있는 앱에서 이메일이 유일한 수단이면(해제 불가) 소셜 행과 같은 ‘유일한 로그인 방법…’ 안내를 붙인다.
 */
export function localRowCaption(state: LocalRowState, input: { email?: string | null; hasRemoveApi: boolean; manageable?: boolean; last: boolean }): string {
  if (state === "setup") return coreT("appCore.account.notSet");
  if (state === "none") return "";
  const email = input.email || "";
  if (state === "inUse" && input.hasRemoveApi && input.manageable !== false && input.last) {
    return email ? `${email} · ${coreT("appCore.methods.lastShort")}` : coreT("appCore.methods.lastShort");
  }
  return email;
}

/** 해제 시트 안내에 넣는 남은 수단 이름(카카오·Apple·Google 순, ‘·’로 이음). */
export function remainingProvidersText(data: Pick<AccountMethods, "kakao" | "apple" | "google"> | undefined): string {
  if (!data) return "";
  return (["KAKAO", "APPLE", "GOOGLE"] as const)
    .filter((p) => (p === "KAKAO" ? data.kakao : p === "APPLE" ? data.apple : !!data.google))
    .map((p) => coreT(`appCore.provider.${p}`))
    .join("·");
}

/**
 * 이메일 로그인을 설정할 수 있는 계정: 앱이 password API를 넘겼고, 소셜 전용이며, 관리 가능(자녀·학생 아님).
 * 계정 이메일이 비어 있으면 ‘다른 이메일’(other)을 넘긴 앱에서만 설정할 수 있다.
 */
export function canSetupEmailLogin(input: { hasApi: boolean; hasOther: boolean; local?: boolean; email?: string | null; manageable?: boolean }): boolean {
  if (!input.hasApi || input.local !== false || input.manageable === false) return false;
  return Boolean(input.email) || input.hasOther;
}

/** 비밀번호 규칙 ✓ 목록(서버 validatePassword·passwordRuleError와 같은 규칙). 길이는 8~100자·UTF-8 72바이트. */
export function passwordChecks(password: string): { length: boolean; letter: boolean; digit: boolean; special: boolean } {
  return {
    length: password.length >= 8 && password.length <= 100 && new TextEncoder().encode(password).length <= 72,
    letter: /[A-Za-z]/.test(password),
    digit: /[0-9]/.test(password),
    special: /[!@#$%^&*?]/.test(password),
  };
}

/** 소셜 행 둘째 줄: 연결된 계정 이메일 → (없으면) ‘로그인에 사용 중’. 마지막 수단이면 해제 불가 안내를 붙인다. 연결 안 됨이면 연결 안내. */
export function providerRowCaption(row: { target: SocialProvider; connected: boolean; available: boolean; last: boolean }, accounts?: AccountMethods["accounts"]): string {
  const label = coreT(`appCore.provider.${row.target}`);
  if (!row.connected) return row.available ? coreT("appCore.methods.linkHint", { provider: label }) : "";
  const email = accounts?.[row.target.toLowerCase() as "kakao" | "apple" | "google"];
  if (row.last) return email ? `${email} · ${coreT("appCore.methods.lastShort")}` : coreT("appCore.methods.lastShort");
  // 연결 계정 이메일을 아직 모르면(DDL 이전 연결·Apple 두 번째 로그인 등) 행 높이를 맞추는 한 줄 안내.
  return email ?? coreT("appCore.methods.inUseCaption");
}

/** 프로필 카드의 로그인 방법 아이콘 줄에 보일 수단(이메일 → 카카오 → Apple → Google 순). */
export type MethodKind = "EMAIL" | SocialProvider;
export function loginMethodKinds(data: Pick<AccountMethods, "local" | "kakao" | "apple" | "google"> | undefined): MethodKind[] {
  if (!data) return [];
  const out: MethodKind[] = [];
  if (data.local) out.push("EMAIL");
  if (data.kakao) out.push("KAKAO");
  if (data.apple) out.push("APPLE");
  if (data.google) out.push("GOOGLE");
  return out;
}

/** 로그인 방법이 하나뿐이면 아래에 ‘둘 이상 두면 좋다’ 안내를 보인다. */
export function showsSingleMethodTip(data: Pick<AccountMethods, "local" | "kakao" | "apple" | "google"> | undefined): boolean {
  if (!data) return false;
  return [data.local, data.kakao, data.apple, data.google].filter(Boolean).length === 1;
}

/** 보일 소셜 행: 앱이 지원하는 수단(providers)만, Google은 서버 설정이 켜졌거나 이미 연결된 때만. */
export function visibleProviderRows<T extends { target: SocialProvider; connected: boolean; available: boolean }>(rows: T[], providers: readonly SocialProvider[]): T[] {
  return rows.filter((r) => providers.includes(r.target) && (r.target !== "GOOGLE" || r.available || r.connected));
}

export type AccountSection = "title" | "notices" | "profile" | "loginMethods" | "appSections" | "account" | "logout" | "withdrawal";

/** 섹션 순서(시안 2026-10-15): 제목 → 안내 → 프로필 → 로그인 수단 → 앱 칸 → 계정 → 로그아웃 → 회원 탈퇴. 비로그인은 프로필(계정 없이 사용) → 앱 칸만. */
export function accountSections(input: { signedIn: boolean; appSections?: unknown; notices?: unknown }): AccountSection[] {
  const out: AccountSection[] = ["title"];
  if (input.notices) out.push("notices");
  out.push("profile");
  if (input.signedIn) out.push("loginMethods");
  if (input.appSections) out.push("appSections");
  if (input.signedIn) out.push("account", "logout", "withdrawal");
  return out;
}

/** 공통 계정 복구(/api/auth/recovery/*) 요청 본문. 목적은 RESET(비밀번호 재설정, 기본)·FIND_ID(아이디 찾기). 새 비밀번호는 마지막 요청에만 싣는다. */
export function recoveryBody(step: "start" | "confirm" | "complete", input: { serviceCode: string; email: string; purpose?: "RESET" | "FIND_ID"; code?: string; verificationToken?: string; newPassword?: string }) {
  const base = { serviceCode: input.serviceCode, email: input.email.trim().toLowerCase() };
  const purpose = input.purpose ?? "RESET";
  if (step === "start") return { ...base, purpose };
  if (step === "confirm") return { ...base, purpose, code: input.code ?? "" };
  return { ...base, verificationToken: input.verificationToken ?? "", newPassword: input.newPassword ?? "" };
}

/** 아이디 찾기 결과 안내: ko는 서버 안내 그대로, en·ja는 찾은 아이디가 있는지에 따라 지금 언어 문구. */
export function findIdText(message: string | undefined, loginIds: readonly string[]): string {
  if (showsServerText()) return message ?? "";
  return coreT(loginIds.length ? "appCore.recovery.found" : "appCore.recovery.noIds");
}

/** 서버 공통 비밀번호 규칙과 같은 검사(CommonAuthService.validatePassword). 통과하면 빈 문자열. */
export function passwordRuleError(password: string): string {
  if (password.length < 8 || password.length > 100 || new TextEncoder().encode(password).length > 72 || !/[A-Za-z]/.test(password) || !/[0-9]/.test(password) || !/[!@#$%^&*?]/.test(password))
    return coreT("appCore.reset.passwordRule");
  return "";
}

/** 공통 API 오류 본문(detail·message)을 사용자 안내로. */
export function recoveryErrorMessage(error: unknown): string {
  // en·ja: 서버 안내(한국어) 대신 code·오류 종류 문구
  if (!showsServerText()) return localizedServerError(error, coreT("appCore.reset.failed"));
  const data = (error as { response?: { data?: { detail?: unknown; message?: unknown } } })?.response?.data;
  const message = data?.detail || data?.message;
  if (typeof message === "string" && message.trim()) return message;
  return coreT("appCore.reset.failed");
}

/** 비밀번호 재설정 성공 안내: ko는 서버 안내 그대로, en·ja는 서버가 안내를 보냈을 때 같은 뜻의 지금 언어 문구. */
export function recoveryServerText(message: string | undefined, step: "sent" | "confirmed" | "done"): string {
  if (showsServerText()) return message ?? "";
  return message ? coreT(`appCore.reset.${step}`) : "";
}
