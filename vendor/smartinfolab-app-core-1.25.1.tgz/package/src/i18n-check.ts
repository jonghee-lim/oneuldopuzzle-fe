/*
 * 빠진 번역 검사(1.10.0). 기준 사전(ko)과 다른 언어 사전을 비교해 빠진 키·남는 키·끼워 넣는 값({{이름}}) 차이를 찾는다.
 * app-core 사전 테스트에 쓰고, 앱도 자기 사전 테스트에서 그대로 쓴다.
 *
 *   const r = checkTranslations(ko, { en, ja });
 *   assert.deepEqual(r.problems, []);
 */
type Tree = { [key: string]: string | Tree };

/** 기준 사전과 모양이 같은 번역 사전 타입(값은 아무 문자열). */
export type Translation<T> = { [K in keyof T]: T[K] extends string ? string : Translation<T[K]> };

/** 중첩 사전을 "a.b.c" → 문자열로 편다. */
export function flattenKeys(tree: Tree, prefix = ""): Map<string, string> {
  const out = new Map<string, string>();
  for (const [k, v] of Object.entries(tree)) {
    const key = prefix ? `${prefix}.${k}` : k;
    if (typeof v === "string") out.set(key, v);
    else for (const [kk, vv] of flattenKeys(v, key)) out.set(kk, vv);
  }
  return out;
}

const vars = (s: string) => [...s.matchAll(/\{\{\s*([\w.]+)\s*\}\}/g)].map((m) => m[1]).sort().filter((v, i, a) => a.indexOf(v) === i).join(",");

/**
 * i18next 복수형 접미사(key_one·key_other 등)를 뗀 기준 키. en처럼 단수·복수를 나누는 언어는 `x_one`·`x_other`로 두고
 * ko·ja처럼 복수형이 하나인 언어는 `x` 하나만 둘 수 있으므로, 비교는 접미사를 뗀 키로 한다.
 */
export const pluralBaseKey = (key: string) => key.replace(/_(zero|one|two|few|many|other)$/, "");

/** 접미사를 뗀 키 → 끼워 넣는 값(모든 변형의 합집합). */
function byBase(flat: Map<string, string>): Map<string, Set<string>> {
  const out = new Map<string, Set<string>>();
  for (const [key, value] of flat) {
    const base = pluralBaseKey(key);
    const set = out.get(base) ?? new Set<string>();
    for (const v of vars(value).split(",").filter(Boolean)) set.add(v);
    out.set(base, set);
  }
  return out;
}

export type TranslationReport = {
  missing: Record<string, string[]>;
  extra: Record<string, string[]>;
  /** 끼워 넣는 값이 기준과 다른 키 */
  variables: Record<string, string[]>;
  empty: Record<string, string[]>;
  /** 사람이 읽는 한 줄씩. 비어 있으면 통과. */
  problems: string[];
};

export function checkTranslations(base: object, others: Record<string, object>): TranslationReport {
  const flatRef = flattenKeys(base as Tree);
  const ref = byBase(flatRef);
  const report: TranslationReport = { missing: {}, extra: {}, variables: {}, empty: {}, problems: [] };
  for (const [lang, dict] of Object.entries(others)) {
    const flatGot = flattenKeys(dict as Tree);
    const got = byBase(flatGot);
    const missing = [...ref.keys()].filter((k) => !got.has(k));
    const extra = [...got.keys()].filter((k) => !ref.has(k));
    const same = (a: Set<string>, b: Set<string>) => [...a].sort().join(",") === [...b].sort().join(",");
    const variables = [...ref.keys()].filter((k) => got.has(k) && !same(ref.get(k)!, got.get(k)!));
    const empty = [...flatGot.keys()].filter((k) => !flatGot.get(k)!.trim());
    report.missing[lang] = missing; report.extra[lang] = extra; report.variables[lang] = variables; report.empty[lang] = empty;
    for (const k of missing) report.problems.push(`${lang}: 빠진 키 ${k}`);
    for (const k of extra) report.problems.push(`${lang}: 남는 키 ${k}`);
    for (const k of variables) report.problems.push(`${lang}: 끼워 넣는 값 다름 ${k}`);
    for (const k of empty) report.problems.push(`${lang}: 빈 값 ${k}`);
  }
  return report;
}
