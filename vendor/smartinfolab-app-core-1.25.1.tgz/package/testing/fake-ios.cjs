/**
 * E2E(Playwright)에서 설치형 앱을 흉내 낸다: Capacitor 사용자 지정 플랫폼과 가짜 기기 브리지.
 * - platform: "ios"(기본, 키체인 로그인·앱 복귀까지) 또는 "android"(설치형 앱 화면 정책만, iOS 전용 기능은 꺼짐).
 * - window.Capacitor만 넣으면 @capacitor/core가 다시 만들어 덮으므로 CapacitorCustomPlatform으로 플랫폼을 알린다.
 * - 플러그인 머리글이 없으면 SecureStorage가 무한히 다시 부르므로 SecureStorage·App·Browser 머리글을 함께 넣는다.
 * - 키체인은 메모리(window.__keychain)이고 값은 JSON 문자열이어야 한다(아니면 invalidData로 지워진다).
 * - Browser.open으로 연 주소는 window.__openedUrl에 남는다.
 *
 * 사용: await context.addInitScript(fakeIos, { platform, keychain: [[키, 토큰]], installKey, appInfo })
 */
function fakeIos({ platform = "ios", keychain: entries = [], installKey, appInfo = {} } = {}) {
  window.CapacitorCustomPlatform = { name: platform, plugins: {} };
  const keychain = new Map(entries.map(([k, v]) => [k, JSON.stringify(v)]));
  if (installKey && entries.length) localStorage.setItem(installKey, "1");
  window.__keychain = keychain;
  const methods = ["setSynchronizeKeychain", "internalGetItem", "internalSetItem", "internalRemoveItem", "internalClearItemsWithPrefix", "internalGetPrefixedKeys"];
  const header = (name, list) => ({ name, methods: list.map((m) => ({ name: m, rtype: "promise" })) });
  window.Capacitor = {
    PluginHeaders: [header("SecureStorage", methods), header("App", ["getInfo", "getLaunchUrl"]), header("Browser", ["open", "close"])],
    nativePromise: async (plugin, method, o = {}) => {
      if (plugin === "App" && method === "getInfo") return { name: "", id: "", build: "1", version: "1.0.0", ...appInfo };
      if (plugin === "App" && method === "getLaunchUrl") return {};
      if (plugin === "Browser" && method === "open") { window.__openedUrl = o.url; return {}; }
      if (plugin === "Browser") return {};
      if (method === "internalGetItem") return { data: keychain.has(o.prefixedKey) ? keychain.get(o.prefixedKey) : null };
      if (method === "internalSetItem") { keychain.set(o.prefixedKey, o.data); return {}; }
      if (method === "internalRemoveItem") return { success: keychain.delete(o.prefixedKey) };
      if (method === "internalClearItemsWithPrefix") { for (const k of [...keychain.keys()]) if (k.startsWith(o.prefix)) keychain.delete(k); return {}; }
      if (method === "internalGetPrefixedKeys") return { keys: [...keychain.keys()].filter((k) => k.startsWith(o.prefix)) };
      return {};
    },
  };
}

module.exports = { fakeIos };
